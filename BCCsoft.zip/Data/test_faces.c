/* test face-based relations */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "relations.h"

int main(int argc, char ** argv)
{
  int p,q,r,s;
  struct CellStruct adj_faces[12];
  struct CellStruct inc_edges[6];
  struct CellStruct inc_verts[6];
  struct CellStruct aux[12];
  struct CellStruct f;
  struct CellStruct vox1, vox2;
  int i;
  int num_edges;
  int error_occurred = 0;
  
  if (argc!=5)
  {
    printf("Need 4 coords p q r s of a face\n");
    return 0;
  }
  sscanf(argv[1],"%d",&p);
  sscanf(argv[2],"%d",&q);
  sscanf(argv[3],"%d",&r);
  sscanf(argv[4],"%d",&s);
  FillCoord(&f, p,q,r,s);
  
  if (!IsCell(&f))
  {
    printf("Given coordinates are not a cell\n");
    return 0;
  }
  if (IsHexFace(&f)) num_edges=6; 
  else if (IsQuadFace(&f)) num_edges=4;
  else
  {
    printf("Given coordinates are not a face\n");
    return 0;
  }
  fprintf(stderr, "Relations of face ");

  fprintf(stderr, "(%d,%d,%d,%d)", p,q,r,s);
/*  PrintCellPtr(&f);*/
  printf("\n");
  
  printf("Incid voxels:\n");
  GetFaceVoxels(&f, &vox1, &vox2);
  printf("1) "); PrintPlainCellPtr(&vox1);
  printf("2) "); PrintPlainCellPtr(&vox2);
  GetCommonFace(&vox1, &vox2, &aux[0]);
  if (!AreSameCell(&f, &aux[0]))
  {  printf("ERR the 2 voxels have not this face, they have ");
     PrintPlainCellPtr(&aux[0]);
  }
  else printf("ok\n"); 
  
  printf("Adj hex faces:\n");
  GetAdjacentHexFaces(&f, adj_faces);
  error_occurred = 0;
  for (i=0; i<num_edges; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&adj_faces[i]);
    if (num_edges==4)
    {
      int q = GetAdjacentQuadFaces(&adj_faces[i], aux);
      if (!IsAmongCells(&f, q, aux))
      {  printf("ERR face is not adj to this one\n");
         error_occurred = 1;
      }
      
      printf("%d)", (i+4)); PrintPlainCellPtr(&adj_faces[i+4]);
      q = GetAdjacentQuadFaces(&adj_faces[i+4], aux);
      if (!IsAmongCells(&f, q, aux))
      {  printf("ERR face is not adj to this one\n");
         error_occurred = 1;
      }
    }
    else /* num_edges==6 */
    {
      int q = GetAdjacentHexFaces(&adj_faces[i], aux);
      if (!IsAmongCells(&f, q, aux))
      {  printf("ERR face is not adj to this one\n");
         error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;
  
  if (num_edges==6) /* hex face */
  {
    printf("Adj quad faces: ");
    GetAdjacentQuadFaces(&f, adj_faces);
    for (i=0; i<num_edges; i++)
    { 
       printf("%d)", i); PrintPlainCellPtr(&adj_faces[i]);  
       GetAdjacentHexFaces(&adj_faces[i], aux);
       if (!IsAmongCells(&f, 8, aux))
       {  printf("ERR face is not adj to this one\n");
          error_occurred = 1; 
       }
    } 
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;
  
  printf("Incid. edges:\n");
  GetFaceEdges(&f, inc_edges);
  for (i=0; i<num_edges; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_edges[i]);
    if (num_edges==4)
    {
      GetEdgeQuadFace(&inc_edges[i], &aux[0]);
      if (!AreSameCell(&aux[0], &f))
      {  printf("ERR edge is not on this face, but it is on ");
         PrintPlainCellPtr(&aux[0]);
         error_occurred = 1;
      } 
    }
    else /* num_edges==6 */
    {
      GetEdgeHexFaces(&inc_edges[i], &aux[0], &aux[1]);
      if (!IsAmongCells(&f, 2, aux))
      {  printf("ERR edge is not on this face, but it is on ");
         PrintPlainCellPtr(&aux[0]);
         printf(" and  ");
         PrintPlainCellPtr(&aux[1]);
         error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Vertices:\n");
  GetFaceVertices(&f, inc_verts);
  for (i=0; i<num_edges; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_verts[i]);
    GetVertexFaces(&inc_verts[i], aux);
    if (!IsAmongCells(&f, 6, aux))
    {   printf("ERR vertex is not on this face\n");
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of faces and edges:\n");
  GetAdjacentHexFaces(&f, adj_faces);
  printf("Hex-faces\n");
  for (i=0; i<num_edges; i++)
  {
    /* hex-face i shares edge i with this face */
    int q = GetFaceEdges(&adj_faces[i],aux);
    printf("%d)", i);
    if (!IsAmongCells(&inc_edges[i], q, aux))
    {   printf("ERR hex-face %d has not edge %d\n", i,i);
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;
  
  if (num_edges==4)
  {
    for (i=0; i<num_edges; i++)
    {
      /* also hex-face i+4 shares edge i with this face */
      int q = GetFaceEdges(&adj_faces[i+4],aux);
      printf("%d)", (i+4));
      if (!IsAmongCells(&inc_edges[i], q, aux))
      {   printf("ERR hex-face %d has not edge %d\n", (i+4),i);
         error_occurred = 1;
      }
    }
    if (!error_occurred) printf("ok\n");
    error_occurred = 0;
  }
  else /* num_edges==6 */
  {
    printf("Quad-faces\n");
    GetAdjacentQuadFaces(&f, adj_faces);
    for (i=0; i<num_edges; i++)
    {
      /* quad-face i shares edge i with this face */
      int q = GetFaceEdges(&adj_faces[i],aux);
      printf("%d)", i);
      if (!IsAmongCells(&inc_edges[i], q, aux))
      {   printf("ERR quad-face %d has not edge %d\n", i,i);
         error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;
  
  printf("Alignment of faces bis\n");
  if (num_edges==4)
  {
    GetAdjacentHexFaces(&f, adj_faces);
    for (i=0; i<num_edges; i++)
    {
      /* hex-faces i and i+4 have edge i as common edge */
      struct CellStruct ee;
      GetCommonEdge(&adj_faces[i], &adj_faces[i+4], &ee);
      if (!AreSameCell(&inc_edges[i],&ee))
      { printf("ERR hex-faces %d, %d have not edge %d, they have ",i,(i+4),i);
        PrintPlainCellPtr(&ee);
        error_occurred = 1;
      }
    }
  }
  else /* num_edges==6 */
  {
    GetAdjacentQuadFaces(&f, adj_faces);
    GetAdjacentHexFaces(&f, aux);
    for (i=0; i<num_edges; i++)
    {
      /* hex-face and quad-face i have edge i as common edge */
      struct CellStruct ee;
      GetCommonEdge(&adj_faces[i], &aux[i], &ee);
      if (!AreSameCell(&inc_edges[i],&ee))
      { printf("ERR hex- and quad- faces %d have not edge %d, they have ",i,i);
        PrintPlainCellPtr(&ee);
        error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of vertices and edges:\n");
  for (i=0; i<num_edges; i++)
  {
    /* vertex i is common to edges i and i+1 */
    struct CellStruct aux_v;
    printf("%d)", i);
    GetCommonVertex(&inc_edges[i], &inc_edges[(i+1)%num_edges], &aux_v);
    if (!AreSameCell(&inc_verts[i],&aux_v))
    {
      printf("ERR edges %d and %d do not have vertex %d, they have ",
         i, ((i+1)%num_edges), i);
      PrintPlainCellPtr(&aux_v);
      error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
}
