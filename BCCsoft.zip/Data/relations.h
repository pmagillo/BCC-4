#include <stddef.h>
#include <stdio.h>
#include "cells.h"

#ifndef RELAT_INCLUDED
#define RELAT_INCLUDED

/* ------------------------------------------------------------------------ */
/* CONNECTIVITY RELATIONS AMONG CELLS */
/* ------------------------------------------------------------------------ */

/* In all functions called "Get..." below, the last argument 
   (pointer or array) will contain the result. Pointers must point
   to allocated memory and arrays must be allocated with a sufficient
   number of elements. */
   
/* ------------------------------------------------------------------------ */
/* Relations for voxels. */
/* ------------------------------------------------------------------------ */

/* Given a reference octahedron, adjacent octahedra of the same type 
   (i.e., odd-odd or even-even) are in the six Cartesian directions. 
   There are six such octahedra, one for each (positive and negative)
   Cartesian direction. 
   For this reason, they are called six-adjacent tetrahedra.
   A Cartesian direction is the same as a diagonal octahedral direction
   composed of two positive and two negative octahedral directions. */

/* Given a reference octahedron, adjacent octahedra of the opposite type
   (i.e., odd-even or even-odd) are in the four octahedral
   directions,  positive or negative orientation.
   There are eight such octahedra, one for each (positive and negative)
   octahedral direction. 
   For this reason, they are called eight-adjacent tetrahedra. */

/* Given an octahedron and a Cartesian direction (name is one of
   'x','y','z' and sign is one of -1,1),
   return the octahedron adjacent to the given one in the given direction.
   A Cartesian direction is a diagonal octahedral direction
   composed of two positive and two negative octahedral directions.
   The coordinates of the output tetrahedron are obtained in this way:
   For each octahedral coordinate, if the corresponding direction
   is positive, then sum +4; if it is negative, then sum -4. */
extern void Get6AdjacentVoxelDir(CellPtr c, char dir_name, int sign,
                                 CellPtr adj);

/* Test if two octahedra are six-adjacent.
   If yes, return the corresponding Cartesian direction, i.e.,
   the direction such that c2 is six-adjacent to c1 in that direction.
   Consider corresponding coordinates in the two octahedra. 
   The difference of each such pair of coordinates must be =4 in
   absolute value, for each pair. The four signs give the direction. */
extern BOOLEAN Are6AdjacentVoxels(CellPtr c1, CellPtr c2,
                                  char *dir_name, int *sign);

/* Given an octahedron and an octahedral direction, return the 
   octahedron adjacent to the given one in the given direction
   (name is one of 'p','q','r','s' and sign is one of -1,1).
   The coordinates of the output tetrahedron are obtained in this way:
   If given direction is in positive orientation,
   then take the coordinate of the input octahedron in the given direction
   and sum +6, take the remaining three coordinates and sum −2 to each
   of them.
   If given direction is in negative orientation, then take the coordinate
   of the input octahedron in the given direction and sum −6, take the
   remaining three coordinates and sum +2 to each of them. */
extern void Get8AdjacentVoxelDir(CellPtr c, char dir_name, int sign,
                                 CellPtr adj);

/* Test if two octahedra are eight-adjacent.
   If yes, return the corresponding Octahedral direction, i.e.,
   the direction such that c2 is six-adjacent to c1 in that direction.
   Consider corresponding coordinates in the two octahedra. 
   The difference of each such pair of coordinates must be = 6 in
   absolute value for one pair, and = 2 for the other three,
   and the sign must be opposite. */
extern BOOLEAN Are8AdjacentVoxels(CellPtr c1, CellPtr c2,
                                  char *dir_name, int *sign);

/* Given two adjacent voxels, return their common face. */
extern void GetCommonFace (CellPtr c1, CellPtr c2, CellPtr fac);

/* Get all 6-adjacent voxels to the given one.
   First the ones lying in positive directions x,y,z from this
   voxel, then the ones lying in negative directions x,y,z. */
extern int Get6AdjacentVoxels(CellPtr c, CellPtr cell_array);

/* Get all 8-adjacent voxels to the given one.
   First the ones lying in positive directions p,q,r,s from this
   voxel, then the ones lying in negative directions p,q,r,s. */
extern int Get8AdjacentVoxels(CellPtr c, CellPtr cell_array);

/* Get all adjacent voxels to the given one, first 6-adjacent ones
   and then 8-adjacent ones. */
extern int GetAdjacentVoxels(CellPtr c, CellPtr cell_array);

/* Get the 6 incident square faces of the given voxel. */
extern int GetVoxelQuadFaces(CellPtr c, CellPtr cell_array);

/* Get the 8 incident hexagonal faces of the given voxel. */
extern int GetVoxelHexFaces(CellPtr c, CellPtr cell_array);

/* Get the 12 edges shared by hexagonal faces incident in the given voxel.
   Edges shared by a quad- and a hex-face are not returned by
   this function, they are returned by GetVoxelQuadEdges. Edges are
   3 for each hex-face, and are put in the array in this order:
   first the 3 edges of first hex-face, then the 3 edges of
   second hex-face, etc., only for hex-faces in positive 
   p,q,r,s direction. */
extern int GetVoxelHexEdges(CellPtr c, CellPtr cell_array);

/* Get the 24 edges of square faces incident in the given voxel:
   first the 4 edges of first quad-face, then the 4 edges of
   second quad-face, etc. */
extern int GetVoxelQuadEdges(CellPtr c, CellPtr cell_array);

/* Get the 24 vertices incident in the given voxel:
   first the 4 vertices of first quad-face, then the 4 vertices of
   second quad-face, etc.  */
extern int GetVoxelVertices(CellPtr c, CellPtr cell_array);

/* ------------------------------------------------------------------------ */
/* Relations for faces. */
/* ------------------------------------------------------------------------ */

/* Get the two incident voxels of a given face.
   Convention: first voxel is that voxel such that this face lies
   in a positive axis direction with respect to it 
   (x,y,z if face is quad-face, p,q,r,s id face is hex-face) */
extern int GetFaceVoxels(CellPtr c, CellPtr adj1, CellPtr adj2);

/* Get the four or six edges of a given face. 
   Convention: they are sorted in circular sequence. */
extern int GetFaceEdges(CellPtr c, CellPtr cell_array);

/* Get the four or six hexagonal faces adjacent to a given face. 
   Convention: they are sorted in such a way that the i-th
   face is adjacent to this one along the i-th edge. */
extern int GetAdjacentHexFaces(CellPtr c, CellPtr cell_array);

/* Get the four or six square faces adjacent to a given hex-face. 
   Convention: they are sorted in such a way that the i-th
   face is adjacent to this one along the i-th edge.
   Remark: quad-faces have no adjacent quand-faces. */
extern int GetAdjacentQuadFaces(CellPtr c, CellPtr cell_array);

/* Get all faces adjacent to the given one. 
   Face are sorted in such a way that, if they are 2k,
   faces in position i and i+k (for i=0..k-1) are adjacent
   to this face along the same edge; moreover faces
   in positions 0..k-1 and k..2k-1 are circular around this face. */
extern int GetAdjacentFaces(CellPtr c, CellPtr cell_array);

/* Get the four or six vertices of a given face. 
   Convention: they are sorted in circular sequence. */
extern int GetFaceVertices(CellPtr c, CellPtr cell_array);

/* Given two adjacent faces, return their common edge. */
extern void GetCommonEdge (CellPtr c1, CellPtr c2, CellPtr edg);

/* ------------------------------------------------------------------------ */
/* Relations for edges. */
/* ------------------------------------------------------------------------ */

/* Get the three voxels incident in the given edge.
   First the two voxels with the same parity as the edge
   (even voxels if even edge, odd voxels if odd edge),
   then the unique voxel with opposite parity. */
extern int GetEdgeVoxels(CellPtr c, CellPtr cell_array);

/* Get the unique voxel incident in the given edge, which is
   odd if the edge is even, and even if the edge is odd. */
extern int GetEdgeMainVoxel(CellPtr c, CellPtr adj);

/* Get the two hexagonal faces incident in the given edge. */
extern int GetEdgeHexFaces(CellPtr c, CellPtr f1, CellPtr f2);

/* Get the unique square face incident in the given edge. */
extern int GetEdgeQuadFace(CellPtr c, CellPtr f);

/* Get the two incident vertices of the given edge. */
extern int GetEdgeVertices(CellPtr edg, CellPtr p1, CellPtr p2);

/* Given two adjacent edges, return their common vertex. */
extern int GetCommonVertex (CellPtr c1, CellPtr c2, CellPtr vrt);

/* Test whether two edges are adjacent, i.e., they have a common vertex. */
extern BOOLEAN AreAdjacentEdges (CellPtr c1, CellPtr c2);

/* ------------------------------------------------------------------------ */
/* Relations for vertices */
/* ------------------------------------------------------------------------ */

/* Get the 4 incident voxels in this vertex.
   They are alternated: even, odd, even, odd. */
extern int GetVertexVoxels(CellPtr c, CellPtr cell_array);

/* Get the 6 incident faces in this vertex. 
   A vertex has 4 incident hexagonal faces, 2 incident quad-faces
   (one even, one odd). They are returned in this order: first the 4
   hex-faces and then the 2 quad-faces. */
extern int GetVertexFaces(CellPtr c, CellPtr cell_array);

/* Get the 4 incident edges of this vertex.
   They are alternated: even, odd, even, odd. */
extern int GetVertexEdges(CellPtr c, CellPtr cell_array);

/* ------------------------------------------------------------------------ */

#endif /* RELAT_INCLUDED */
