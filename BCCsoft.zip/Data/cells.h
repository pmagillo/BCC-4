#include <stddef.h>
#include <stdio.h>
#include "misc.h"

#ifndef CELLS_INCLUDED
#define CELLS_INCLUDED

/* ------------------------------------------------------------------------ */
/* CELLS (dimension-independent part) */
/* ------------------------------------------------------------------------ */

/* A cell is described by four coordinates (p,q,r,s). Valid cells are
   such that the sum of the four coordinates is zero (modulo 8). */
typedef struct CellStruct { int coord[4]; } * CellPtr;

/* Get each of the four coordinates of the cell. */
#define P_COORD(ptr) ((ptr)->coord[0])
#define Q_COORD(ptr) ((ptr)->coord[1])
#define R_COORD(ptr) ((ptr)->coord[2])
#define S_COORD(ptr) ((ptr)->coord[3])

/* Test if the given input is a cell, i.e., if
   the sum (modulo 8) of all coordinates is zero. */
extern BOOLEAN IsCell(CellPtr c);

/* Print a cell, notation with brackets and commas. */
extern void PrintCellPtr(CellPtr c);

/* Print a cell, notation with blank spaces. */
extern void PrintPlainCellPtr(CellPtr c);

/* Initialize a cell with the given four values (p,q,r,s). */
extern void FillCoord(CellPtr c, int p, int q, int r, int s);

/* Initialize a cell by copying coordinated from source cell. */
extern void CopyCoordFrom(CellPtr c, CellPtr source_c);

/* Test if two cells are the same.
   The four coordinates (p,q,r,s) must be equal. */
extern BOOLEAN AreSameCell (CellPtr c1, CellPtr c2);

/* Test if given cell coordinates are equal to values. */
extern BOOLEAN CellHasCoords (CellPtr c, int p, int q, int r, int s);

/* Test if a cell is among the ones in given array of n cells. */
extern BOOLEAN IsAmongCells(CellPtr c, int n, CellPtr cell_array);

/* Given coord_name one of 'p','q','r','s', add value to 
   corresponding coordinate of cell. */
extern void AddValueToCoord(CellPtr c, char coord_name, int value_to_add);

/* Given an array of 4 coordinate names containing a permulation of
   "pqrs" add the given four values to corresponding coordinate of cell,
   in that order. */
extern void AddValuesToCoords(CellPtr c, char * names, 
                              int v1, int v2, int v3, int v4);

/* Put the sum of coordinates c1-2 into cell res. */
extern void SumCells(CellPtr c1, CellPtr c2, CellPtr res);

/* Put the sum of given cell and coordinates into cell res. */
extern void SumCoordinates(CellPtr c, int p, int q, int r, int s,
                           CellPtr res);

/* Put the difference of coordinates c1-c2 into cell res. */
extern void DiffCells(CellPtr c1, CellPtr c2, CellPtr res);

/* Put the difference of coordinates c1-c2 into given variables. */
extern void DiffCoordinates(CellPtr c1, CellPtr c2, 
                            int *p, int *q, int *r, int *s);

/* ------------------------------------------------------------------------ */
/* OCTAHEDRA (VOXEL CELLS) */
/* ------------------------------------------------------------------------ */

/* There are two interlaced grids of octahedral cells, called even and
   odd voxels. Constraints for coordinates (p, q, r, s) representing
   voxels are as follows.
   For even voxel: p, q, r, s = 0 or = 4 mod 8.
   For odd voxel: p, q, r, s = 2 or = 6 mod 8  */

/* Test if the given cell is an even voxel. That is, if
   its coordinates are all =0 or all =4 (modulo 8). */
extern BOOLEAN IsEvenVoxel (CellPtr c);
extern BOOLEAN IsEvenVoxelPQRS(int p, int q, int r, int s);

/* Test if the given cell is an odd voxel. That is, if
   its coordinates are all =2 or all =6 (modulo 8). */
extern BOOLEAN IsOddVoxel (CellPtr c);
extern BOOLEAN IsOddVoxelPQRS(int p, int q, int r, int s);

/* Test if the given cell is an (even or odd) voxel. */
extern BOOLEAN IsVoxel (CellPtr c);

/* Given the (p,q,r,s) coordinates of a voxel, compute the Cartesian
   coordinates of the center of the voxel */
extern void VoxelCenterXYZfromPQRS(int p, int q, int r, int s,
                            int *x, int *y, int *z);
extern void VoxelCenterXYZ(CellPtr voxel_c, int *x, int *y, int *z);

/* ------------------------------------------------------------------------ */
/* FACES (2D CELLS) */
/* ------------------------------------------------------------------------ */

/* We have hexagonal faces (joining two voxels of opposite type),
   and quadrangular faces (joining two voxels of same type).
   The face has coordinates equal to the average of the two voxels
   sharing it. */

/* A hex-face is shared by an even and an odd voxel.
   The values modulo 8 of the four coordinates of a hex-face are:
   either three =1 and one =5, or three =5 and one =1,
   or three =3 and one =7, or three =7 and one =3. */
   
/* A quad-face  is shared by two even voxels (even quad-face), 
   or by two odd voxels (odd quad-face).
   The values modulo 8 of the four coordinates of an even quad-face 
   are two =2 and two=6.
   The values modulo 8 of the four coordinates of an odd quad-face 
   are two =0 and two=4. */

/* Test if the given cell is a hex-face. That is, if its coordinates
   either three =1 and one =5, or three =5 and one =1,
   or three =3 and one =7, or three =7 and one =3. */
extern BOOLEAN IsHexFace(CellPtr c);

/* Test if the given cell is an even quad-face. That is, if 
   the values modulo 8 of the four coordinates are two =2 and two=6. */
extern BOOLEAN IsEvenQuadFace(CellPtr c);

/* Test if the given cell is an odd quad-face. That is, if 
   the values modulo 8 of the four coordinates are are two =0 and two=4. */
extern BOOLEAN IsOddQuadFace(CellPtr c);

/* Test if the given cell is an even quad-face. */
extern BOOLEAN IsQuadFace(CellPtr c);

/* ------------------------------------------------------------------------ */
/* EDGES (1D CELLS) */
/* ------------------------------------------------------------------------ */

/* Each edge is shared by three faces: one quad-face and two hex-faces.
   The quad-face is either even or odd, so we have even and odd edges.
   Equivalently, each edge is shared by three voxels: either
   one odd and two even voxels (even edge), or vice-versa (odd edge). */

/* An even edge has two coordinates both =2 or both =6 (modulo 8),
   and the other two coordinates are one =0 and one =4 (modulo 8). */

/* An odd edge has two coordinates both =0 or both =4 (modulo 8), 
   and the other two coordinates are one =2 and one =6 (modulo 8). */

/* Test if the given cell is an even edge. */
extern BOOLEAN IsEvenEdge(CellPtr c);

/* Test if the given cell is an odd edge. */
extern BOOLEAN IsOddEdge(CellPtr c);

/* Test if the given cell is an edge (even or odd). */
extern BOOLEAN IsEdge(CellPtr c);

/* ------------------------------------------------------------------------ */
/* VERTICES
/* ------------------------------------------------------------------------ */

/* The coordinates of a vertex are one =1, one =3, one =5, and one =7
   (modulo 8). */

/* Test if the given cell is a vertex. */
extern BOOLEAN IsVertex(CellPtr c);

/* ------------------------------------------------------------------------ */

#endif /* CELLS_INCLUDED */
