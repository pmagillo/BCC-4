/* template program */

#include <stdio.h>
#include "relations.h"

int main(int argc, char ** argv)
{
  struct CellStruct cell;

  printf("Hello world \n");
  
  FillCoord(&cell, 0,0,0,0);
  PrintCellPtr(&cell);
  
  printf("\nIs this a cell? ");
  PrintBoolean(IsCell(&cell));
  printf("\n");

  return 0;
}
