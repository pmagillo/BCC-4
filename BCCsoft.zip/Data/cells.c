#include <stddef.h>
#include <stdio.h>
#include "cells.h"

/* This file contains implementation, see header file for comments. */

/* ------------------------------------------------------------------------ */
/* CELLS (dimension-independent part) */
/* ------------------------------------------------------------------------ */

void PrintCellPtr(CellPtr c)
{ printf("(%d,%d,%d,%d)", P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c)); }

/* Print a cell, notation with blank spaces. */
void PrintPlainCellPtr(CellPtr c)
{ printf("%d %d %d %d\n", P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c)); }

BOOLEAN IsCell(CellPtr c)
{
  /* Sum of all coordinates is zero. */
  return ((P_COORD(c)+Q_COORD(c)+R_COORD(c)+S_COORD(c))==0);
}

void FillCoord(CellPtr c, int p, int q, int r, int s)
{
  P_COORD(c) = p;
  Q_COORD(c) = q;
  R_COORD(c) = r;
  S_COORD(c) = s;
}

void CopyCoordFrom(CellPtr c, CellPtr source_c)
{
  P_COORD(c) = P_COORD(source_c);
  Q_COORD(c) = Q_COORD(source_c);
  R_COORD(c) = R_COORD(source_c);
  S_COORD(c) = S_COORD(source_c);
}

BOOLEAN AreSameCell (CellPtr c1, CellPtr c2)
{
  return ( (P_COORD(c1)==P_COORD(c2)) && (Q_COORD(c1)==Q_COORD(c2)) && 
           (R_COORD(c1)==R_COORD(c2)) && (S_COORD(c1)==S_COORD(c2)) );
}

BOOLEAN CellHasCoords (CellPtr c, int p, int q, int r, int s)
{
  return ( (P_COORD(c)==p) && (Q_COORD(c)==q) && 
           (R_COORD(c)==r) && (S_COORD(c)==s) );
}

BOOLEAN IsAmongCells(CellPtr c, int n, CellPtr cell_array)
{
  int i;
  for (i=0; i<n; i++)
    if (AreSameCell(c,&cell_array[i])) return 1;
  return 0;
}

void AddValueToCoord(CellPtr c, char coord_name, int value_to_add)
{
  switch (coord_name)
  {
    case 'p': P_COORD(c) += value_to_add; break;
    case 'q': Q_COORD(c) += value_to_add; break;
    case 'r': R_COORD(c) += value_to_add; break;
    case 's': S_COORD(c) += value_to_add; break;
  }
}

void AddValuesToCoords(CellPtr c, char * names, 
                      int v1, int v2, int v3, int v4)
{
  AddValueToCoord(c,names[0],v1);
  AddValueToCoord(c,names[1],v2);
  AddValueToCoord(c,names[2],v3);
  AddValueToCoord(c,names[3],v4);
}

void SumCells(CellPtr c1, CellPtr c2, CellPtr res)
{
  P_COORD(res) = P_COORD(c1) + P_COORD(c2);
  Q_COORD(res) = Q_COORD(c1) + Q_COORD(c2);
  R_COORD(res) = R_COORD(c1) + R_COORD(c2);
  S_COORD(res) = S_COORD(c1) + S_COORD(c2);
}
 
void SumCoordinates(CellPtr c, int p, int q, int r, int s, CellPtr res)
{
  P_COORD(res) = P_COORD(c) + p;
  Q_COORD(res) = Q_COORD(c) + q;
  R_COORD(res) = R_COORD(c) + r;
  S_COORD(res) = S_COORD(c) + s;
}

void DiffCells(CellPtr c1, CellPtr c2, CellPtr res)
{
  P_COORD(res) = P_COORD(c1)-P_COORD(c2);
  Q_COORD(res) = Q_COORD(c1)-Q_COORD(c2);
  R_COORD(res) = R_COORD(c1)-R_COORD(c2);
  S_COORD(res) = S_COORD(c1)-S_COORD(c2);
}

void DiffCoordinates(CellPtr c1, CellPtr c2, 
                     int *p, int *q, int *r, int *s)
{
  (*p) = P_COORD(c1)-P_COORD(c2);
  (*q) = Q_COORD(c1)-Q_COORD(c2);
  (*r) = R_COORD(c1)-R_COORD(c2);
  (*s) = S_COORD(c1)-S_COORD(c2);
}

/* ------------------------------------------------------------------------ */
/* OCTAHEDRA (VOXEL CELLS) */
/* ------------------------------------------------------------------------ */

BOOLEAN IsEvenVoxel (CellPtr c)
{
  /* Assume that it is a cell. Taking each coordinate mod 8,
     they are all ==0 or all ==4. */
  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  return ( (BUCKET_ARRAY[0]==4) || (BUCKET_ARRAY[4]==4) );
}

BOOLEAN IsEvenVoxelPQRS(int p, int q, int r, int s)
{
  CountValuesMod8(p,q,r,s);
  return ( (BUCKET_ARRAY[0]==4) || (BUCKET_ARRAY[4]==4) );
}

BOOLEAN IsOddVoxel (CellPtr c)
{
  /* Assume that it is a cell. Taking each coordinate mod 8,
     they are all ==2 or all ==6. */
  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  return ( (BUCKET_ARRAY[2]==4) || (BUCKET_ARRAY[6]==4) );
}

BOOLEAN IsOddVoxelPQRS(int p, int q, int r, int s)
{
  CountValuesMod8(p,q,r,s);
  return ( (BUCKET_ARRAY[2]==4) || (BUCKET_ARRAY[6]==4) );
}

BOOLEAN IsVoxel (CellPtr c)
{  return (IsEvenVoxel(c) || IsOddVoxel(c));  }

void VoxelCenterXYZfromPQRS(int p, int q, int r, int s,
                            int *x, int *y, int *z)
{
  (*x) = (q+s)/4;
  (*y) = (s+p)/4;
  (*z) = (p+q)/4; 
}

void VoxelCenterXYZ(CellPtr c, int *x, int *y, int *z)
{
  VoxelCenterXYZfromPQRS(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c),
                         x,y,z);
}

/* ------------------------------------------------------------------------ */
/* FACES (2D CELLS) */
/* ------------------------------------------------------------------------ */

BOOLEAN IsHexFace(CellPtr c)
{
  /* Assume that it is a cell. Taking each coordinate mod 8,
     either three are ==1 and one is ==5, or vice versa,
     or three are ==3 and one is ==7, or vice versa. */
  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  return  ( ((BUCKET_ARRAY[1]==3)&&(BUCKET_ARRAY[5]==1)) ||
            ((BUCKET_ARRAY[1]==1)&&(BUCKET_ARRAY[5]==3)) ||
            ((BUCKET_ARRAY[7]==3)&&(BUCKET_ARRAY[3]==1)) ||
            ((BUCKET_ARRAY[7]==1)&&(BUCKET_ARRAY[3]==3)) );
}

BOOLEAN IsEvenQuadFace(CellPtr c)
{
  /* Assume that it is a cell. Taking each coordinate mod 8,
     two are ==2 and two are ==6. */
  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  return  ((BUCKET_ARRAY[2]==2)&&(BUCKET_ARRAY[6]==2));
}

BOOLEAN IsOddQuadFace(CellPtr c)
{
  /* Assume that it is a cell. Taking each coordinate mod 8,
     two are ==0 and two are ==4. */
  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  return  ((BUCKET_ARRAY[0]==2)&&(BUCKET_ARRAY[4]==2));
}

BOOLEAN IsQuadFace(CellPtr c)
{
  return (IsEvenQuadFace(c) || IsOddQuadFace(c));
}

BOOLEAN IsFace(CellPtr c)
{
  return(IsEvenQuadFace(c) || IsOddQuadFace(c) || IsHexFace(c));
}

/* ------------------------------------------------------------------------ */
/* EDGES (1D CELLS) */
/* ------------------------------------------------------------------------ */

BOOLEAN IsEvenEdge(CellPtr c)
{
  /* Assume that it is a cell. Taking each coordinate mod 8,
     two are ==2 or ==6, one is ==0, one is ==4. */
  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  return ((BUCKET_ARRAY[2]==2)||(BUCKET_ARRAY[6]==2)) &&
          (BUCKET_ARRAY[0]==1)&&(BUCKET_ARRAY[4]==1);
}

BOOLEAN IsOddEdge(CellPtr c)
{
  /* Assume that it is a cell. Taking each coordinate mod 8,
     two are ==0 or ==4, one is ==2, one is ==6. */
  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  return ((BUCKET_ARRAY[0]==2)||(BUCKET_ARRAY[4]==2)) &&
          (BUCKET_ARRAY[2]==1)&&(BUCKET_ARRAY[6]==1);
}

BOOLEAN IsEdge(CellPtr c)
{  return (IsEvenEdge(c) || IsOddEdge(c));  }

/* ------------------------------------------------------------------------ */
/* VERTICES
/* ------------------------------------------------------------------------ */

BOOLEAN IsVertex(CellPtr c)
{
  /* Assume that it is a cell. Taking each coordinate mod 8,
     one is ==1, one ==3, one ==5 and one ==7. */
  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  return ((BUCKET_ARRAY[1]==1)&&(BUCKET_ARRAY[3]==1)&&
          (BUCKET_ARRAY[5]==1)&&(BUCKET_ARRAY[7]==1));  
}

/* ------------------------------------------------------------------------ */
