#ifndef CHECKING_INCLUDED
#define CHECKING_INCLUDED

#ifdef CONTROLLA
#include "cells.h"
extern int CHECK(int test, char * msg);
extern int CHECK_ALL_VERTICES(CellPtr array, int n, char * msg);
extern int CHECK_ALL_EDGES(CellPtr array, int n, char * msg);
extern int CHECK_ALL_FACES(CellPtr array, int n, char * msg);
#else
#define CHECK(x,y) {}
#define CHECK_ALL_VERTICES(x,y,z) {}
#define CHECK_ALL_EDGES(x,y,z) {}
#define CHECK_ALL_FACES(x,y,z) {}
#endif

#endif /* CHECKING_INCLUDED */
