#include <stdio.h>
#include "cells.h"
#include "checking.h"
#ifdef CONTROLLA

/* this is a different function just to allow detecting
   errors by setting a breakpoint inside it */
void CHECK_ERROR(char * msg)
{  printf("ERR: %s", msg);  }

int CHECK(int test, char * msg)
{  if (!test)  CHECK_ERROR(msg);  }

int CHECK_ALL_VERTICES(CellPtr array, int n, char * msg)
{
  int i;
  for (i=0; i<n; i++)
      CHECK( (IsCell(&array[i])&&IsVertex(&array[i])), msg);
}
int CHECK_ALL_EDGES(CellPtr array, int n, char * msg)
{
  int i;
  for (i=0; i<n; i++)
      CHECK( (IsCell(&array[i])&&IsEdge(&array[i])), msg);
}
int CHECK_ALL_FACES(CellPtr array, int n, char * msg)
{
  int i;
  for (i=0; i<n; i++)
  {
    BOOLEAN t = IsCell(&array[i]) &&
      (IsQuadFace(&array[i])||IsHexFace(&array[i]));
    CHECK(t, msg);
  }
}
#endif /* CONTROLLA */
