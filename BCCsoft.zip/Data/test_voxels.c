/* test voxel-based relations */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "relations.h"

int main(int argc, char ** argv)
{
  int p,q,r,s;
  struct CellStruct adj_voxels[24];
  struct CellStruct inc_faces[24];
  struct CellStruct inc_edges[24];
  struct CellStruct inc_verts[24];
  struct CellStruct aux[24];
  struct CellStruct vox;
  int i, j;
  int error_occurred = 0;
  
  if (argc!=5)
  {
    printf("Need 4 coords p q r s of a voxel\n");
    return 0;
  }
  sscanf(argv[1],"%d",&p);
  sscanf(argv[2],"%d",&q);
  sscanf(argv[3],"%d",&r);
  sscanf(argv[4],"%d",&s);
  FillCoord(&vox, p,q,r,s);
  
  if (!IsCell(&vox))
  {
    printf("Given coordinates are not a cell\n");
    return 0;
  }
  if (!IsVoxel(&vox))
  {
    printf("Given coordinates are not a voxel\n");
    return 0;
  }
  fprintf(stderr, "Relations of voxel ");

  fprintf(stderr, "(%d,%d,%d,%d)", p,q,r,s);
/*  PrintCellPtr(&vox);*/
  printf("\n");
  
  printf("Adj voxels:\n");
  printf("at the 6 square faces:\n");
  error_occurred = 0;
  Get6AdjacentVoxels(&vox, adj_voxels);
  for (i=0; i<6; i++)
  {
    printf("%d) ", i); PrintPlainCellPtr(&adj_voxels[i]);
    Get6AdjacentVoxels(&adj_voxels[i], aux);
    if (!IsAmongCells(&vox, 6, aux))
    {  printf("ERR voxel is not adj to this one\n");
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");

  printf("at the 8 hexagonal faces:\n");
  error_occurred = 0;
  Get8AdjacentVoxels(&vox, adj_voxels);
  for (i=0; i<8; i++)
  {
    printf("%d) ", i); PrintPlainCellPtr(&adj_voxels[i]);
    Get8AdjacentVoxels(&adj_voxels[i], aux);
    if (!IsAmongCells(&vox, 8, aux))
    {  printf("ERR voxel is not adj to this one\n");
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Incid hex faces:\n");
  GetVoxelHexFaces(&vox, inc_faces);
  for (i=0; i<8; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_faces[i]);
    GetFaceVoxels(&inc_faces[i], &aux[0], &aux[1]);
    if (!IsAmongCells(&vox, 2, aux))
    {  printf("ERR face has not this voxel, it has ");
         PrintPlainCellPtr(&aux[0]);
         printf(" and ");
         PrintPlainCellPtr(&aux[2]);
         error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Incid quad faces:\n");
  GetVoxelQuadFaces(&vox, inc_faces);
  for (i=0; i<6; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_faces[i]);
    GetFaceVoxels(&inc_faces[i], &aux[0], &aux[1]);
    if (!IsAmongCells(&vox, 2, aux))
    {  printf("ERR face has not this voxel, it has ");
         PrintPlainCellPtr(&aux[0]);
         printf(" and ");
         PrintPlainCellPtr(&aux[2]);
         error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Incid. edges:\n");
  printf("edges of quad faces\n");
  GetVoxelQuadEdges(&vox, inc_edges);
  for (i=0; i<24; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_edges[i]);
    GetEdgeVoxels(&inc_edges[i], aux);
    if (!IsAmongCells(&vox, 3, aux))    
    {  printf("ERR edge is not on this voxel, but it is on ");
       PrintPlainCellPtr(&aux[0]);
       printf(", ");
       PrintPlainCellPtr(&aux[1]);
       printf(", ");
       PrintPlainCellPtr(&aux[2]);
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("edges of hexagonal faces\n");
  GetVoxelHexEdges(&vox, inc_edges);
  for (i=0; i<12; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_edges[i]);
    GetEdgeVoxels(&inc_edges[i], aux);
    if (!IsAmongCells(&vox, 3, aux))
    {  printf("ERR edge is not on this voxel, but it is on ");
       PrintPlainCellPtr(&aux[0]);
       printf(", ");
       PrintPlainCellPtr(&aux[1]);
       printf(", ");
       PrintPlainCellPtr(&aux[2]);
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Vertices:\n");
  GetVoxelVertices(&vox, inc_verts);
  for (i=0; i<24; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_verts[i]);
    GetVertexVoxels(&inc_verts[i], aux);
    if (!IsAmongCells(&vox, 4, aux))
    {  printf("ERR vertex is not on this voxel, but it is on ");
       PrintPlainCellPtr(&aux[0]);
       printf(", ");
       PrintPlainCellPtr(&aux[1]);
       printf(", ");
       PrintPlainCellPtr(&aux[2]);
       printf(", ");
       PrintPlainCellPtr(&aux[3]);
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of voxels and faces\n");
  printf("at square faces\n");
  Get6AdjacentVoxels(&vox, adj_voxels);
  GetVoxelQuadFaces(&vox, inc_faces);
  /* quad-face i is common to this voxel and 6-adjacent voxel i */
  for (i=0; i<6; i++)
  {
    int q = -1;
    GetFaceVoxels(&inc_faces[i], &aux[0], &aux[1]);
    if (AreSameCell(&vox,&aux[0])) q = 1;
    else if (AreSameCell(&vox,&aux[1])) q = 0;
    else
    {
      printf("ERR face %d has not this voxel\n", i);
      error_occurred = 1;
    }
    if (q!=-1)
    {
      if (!AreSameCell(&adj_voxels[i],&aux[q]))
      {
        printf("ERR face %d has not voxel %i\n", i, i);
        error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("at hex faces\n");
  Get8AdjacentVoxels(&vox, adj_voxels);
  GetVoxelHexFaces(&vox, inc_faces);
  /* hex-face i is common to this voxel and 8-adjacent voxel i */
  for (i=0; i<8; i++)
  {
    int q = -1;
    GetFaceVoxels(&inc_faces[i], &aux[0], &aux[1]);
    if (AreSameCell(&vox,&aux[0])) q = 1;
    else if (AreSameCell(&vox,&aux[1])) q = 0;
    else
    {
      printf("ERR face %d has not this voxel\n", i);
      error_occurred = 1;
    }
    if (q!=-1)
    {
      if (!AreSameCell(&adj_voxels[i],&aux[q]))
      {
        printf("ERR face %d has not voxel %i\n", i, i);
        error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of square faces and their edges:\n");
  GetVoxelQuadFaces(&vox, inc_faces);
  GetVoxelQuadEdges(&vox, inc_edges);
  i=0;
  for (i=0; i<3; i++)
  {
    /* first 4 quad-edges belong to quad-face 0, etc. */
    GetFaceEdges(&inc_faces[i], aux);
    for (j=0; j<4; j++)
    {
      if (!IsAmongCells(&inc_edges[4*i+j],4,aux))
      {  printf("ERR edge %d is not in face %i\n", (4*i+j), i);
         printf("i=%d j=%d\n", i,j);
         error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of hex faces and other edges:\n");
/* QUESTO L'UNICO CHE ANCORA NON VA */
  GetVoxelHexFaces(&vox, inc_faces);
  GetVoxelHexEdges(&vox, inc_edges);
  i=0;
  for (i=0; i<4; i++)
  {
    struct CellStruct vv;
    GetFaceEdges(&inc_faces[i], aux);
    for (j=0; j<3; j++)
    {
      if (!IsAmongCells(&inc_edges[3*i+j],6,aux))
      {  printf("ERR edge %d is not in face %i\n", (3*i+j), i);
         printf("i=%d j=%d\n", i,j);
         error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("%d) ok\n", i);
  else printf("%d) ERR\n", i);
  error_occurred = 0;

  printf("Alignment of quad faces and vertices:\n");
  i =0;
  GetVoxelQuadFaces(&vox, inc_faces);
  for (i=0; i<6; i++)
  {
    GetFaceVertices(&inc_faces[i], aux);
    for (j=0; j<4; j++)
    {
      if (!IsAmongCells(&inc_verts[4*i+j], 4, aux))
      {  printf("ERR vertex %d is not in face %i\n", (4*i+j), i);
         printf("i=%d j=%d\n", i,j);
         error_occurred = 1;
      }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;
}
