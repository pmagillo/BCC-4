#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include "cells.h"
#include "marks.h"

/*
#define PRINTING
#define PRINTING2
*/

/* ------------------------------------------------------------------------ */
/* ARRAYS FOR MARKING VOXELS AND FACES */
/* ------------------------------------------------------------------------ */

/* This file contains implementation, see header file for other comments. */

/* ------------------------------------------------------------------------ */
/* MANIPULATION OF THE VALUE STORED FOR A VOXEL                           */
/* ------------------------------------------------------------------------ */

/* The same char stores the information for the voxel in its right-most
   bit (0/1 = empty/full) and the information for the 7 faces having that
   voxel as their reference voxel in the other 7 bits (for each face,
   0/1 = not visited/visited). */

/*typedef unsigned char MY_CHAR;*/
typedef unsigned char MY_CHAR;

/* Get i-th bit (counted from least to most meaningful) of char c. */
int GetBit(MY_CHAR c, int i)
{
  int mask = 1;
  mask = mask << i; /* mask = 2^i */
#ifdef PRINTING
printf("  Get %d-th bit of char: c=%x, mask=%x, AND=%x\n",
i,c,mask, (c & mask));
#endif
  return (c & mask);
}

/* Set i-th bit (counted from least to most meaningful) of char c
   to value 1. */
MY_CHAR raiseBit(MY_CHAR c, int i)
{
  int mask = 1;
  mask = mask << i; /* mask = 2^i */
#ifdef PRINTING
printf("  raise %d-th bit of char: c=%x, mask=%x, OR=%x\n",
i, ((int)c),mask,(mask | c));
#endif
  return (MY_CHAR)(mask | c);
}

/* Set i-th bit (counted from least to most meaningful) of char c
   to value 0. */
MY_CHAR clearBit(MY_CHAR c, int i)
{
  int mask = 1;
  mask = mask << i; /* mask = 2^i */
#ifdef PRINTING
printf("  clear %d-th bit of char: c=%x, mask=%x, OR=%x\n",
i, (int)c,mask,(c & (!mask)));
#endif
  return (MY_CHAR)(c & (!mask));
}

/* Get the voxel status from the char as the value of the right-most 
   bit (least meaningful one). */
int VoxelStatusFromChar(MY_CHAR c)
{  return GetBit(c,0);  }

/* Get the face status from the char as the value of the bit
   number 1+face index (bits counted from least meaningful one). */
int FaceStatusFromChar(MY_CHAR c, int face_ind)
{  return GetBit(c,1+face_ind);  }

/* Set the voxel status into the char as the value of the right-most 
   bit (least meaningful one). */
MY_CHAR SetVoxelStatusInChar(MY_CHAR c, int st)
{  if (st) return raiseBit(c,0);
   else return clearBit(c,0);
}

/* Set the face into the char as the value of the bit
   number 1+face index (bits counted from least meaningful one). */
MY_CHAR SetFaceStatusInChar(MY_CHAR c, int face_ind, int st)
{  if (st) return raiseBit(c,1+face_ind);
   else return clearBit(c,1+face_ind);
}

/* ------------------------------------------------------------------------ */
/* Array for marking full and empty voxels, and for marking faces */
/* ------------------------------------------------------------------------ */

/* The arrays are indexed on the Cartesian coordinates
   of the centers of the voxels. We have two arrays: one for even voxels
   where the indexes are (coordinate value/2), and one for odd
   voxels where indexes are (coordinate value -1)/2.  */

/* The arrays for marking are global */
struct 
{
  MY_CHAR *** mark_array[2];
  int range_x; int range_y; int range_z;
  int base_x; int base_y; int base_z;
  int default_mark;
} marking;

#define MARK_IND_X(i) ((i)+marking.base_x)
#define MARK_IND_Y(i) ((i)+marking.base_y)
#define MARK_IND_Z(i) ((i)+marking.base_z)

int indexOutOfRange(int a, int b, int c, int d)
{
/*Aprile*/if(((d<0)||(d>=2)) ||
           ((MARK_IND_Z(c)<0)||(MARK_IND_Z(c)>=marking.range_z)) ||
           ((MARK_IND_Y(b)<0)||(MARK_IND_Y(b)>=marking.range_y)) ||
           ((MARK_IND_X(a)<0)||(MARK_IND_X(a)>=marking.range_x)))
if(0){printf("Questo ");
printf("sconfina\n");/*non arriva mai qui????*/
}
  return   ((d<0)||(d>=2)) ||
           ((MARK_IND_Z(c)<0)||(MARK_IND_Z(c)>=marking.range_z)) ||
           ((MARK_IND_Y(b)<0)||(MARK_IND_Y(b)>=marking.range_y)) ||
           ((MARK_IND_X(a)<0)||(MARK_IND_X(a)>=marking.range_x));
}

#ifdef CONTROLLA_INDICI
int CONTROLLA_IND(CellPtr voxel_c, int a, int b, int c, int d, char *msg)
{
  int errore = indexOutOfRange(a,b,c,d);
  if (errore)
  { printf("ERR: %s(", msg);
    PrintCellPtr(voxel_c);
    printf("):");
    printf("  d=%d\n",d);
    printf("  c=%d in [%d,%d], accedo %d in [%d,%d]\n",
        c, -marking.base_z,(-marking.base_z+marking.range_z-1),
        MARK_IND_Z(c), 0,marking.range_z-1);
    printf("  b=%d in [%d,%d], accedo %d in [%d,%d]\n",
        b, -marking.base_y,(-marking.base_y+marking.range_y-1),
        MARK_IND_Y(b), 0,marking.range_y-1);
    printf("  a=%d in [%d,%d], accedo %d in [%d,%d]\n",
        a, -marking.base_x,(-marking.base_x+marking.range_x-1),
        MARK_IND_X(a), 0,marking.range_x-1);
    return 0;
  }
  else return 1;
}
#else 
#define CONTROLLA_IND(v,a,b,c,d,m) {}
#endif

void SetDefaultStatus(int st) {  marking.default_mark = st;  }
int GetDefaultStatus() {  return marking.default_mark;  }

/* ------------------------------------------------------------------------ */
/* Allocation of marking arrays */
/* ------------------------------------------------------------------------ */


/* n=number to be divided may be <0, d=divisor must be >0 */
static DivideBy(int n, int d)
{  if (n>=0) return (n/d); else return ((n-1)/d);  }

/* Allocation after base and range have been set. Return the
   number of allocated bytes. */
static int AllocArray()
{
  int i,j,k,h;
  /* correction of computed limits if too small */
  if (marking.range_x<3)
  {  marking.range_x = 3;  marking.base_x += 1;  }
  if (marking.range_y<3)
  {  marking.range_y = 3;  marking.base_y += 1;  }
  if (marking.range_z<3)
  {  marking.range_z = 3;  marking.base_z += 1;  }
#ifdef PARLA
printf("MARK ARRAY HAS RANGE=%d, BASE=%d (x)\n", marking.range_x, marking.base_x);
printf("MARK ARRAY HAS RANGE=%d, BASE=%d (y)\n", marking.range_y, marking.base_y);
printf("MARK ARRAY HAS RANGE=%d, BASE=%d (z)\n", marking.range_z, marking.base_z);
#endif

  for (i=0; i<2; i++)
  {
    marking.mark_array[i] =
            (MY_CHAR ***) malloc(marking.range_z*sizeof(MY_CHAR **));
    for (j=0; j<marking.range_z; j++) 
    {
      marking.mark_array[i][j] =
              (MY_CHAR **) malloc(marking.range_y*sizeof(MY_CHAR *));
      for (k=0; k<marking.range_y; k++)
      {
        marking.mark_array[i][j][k] =
                (MY_CHAR *) malloc(marking.range_x*sizeof(MY_CHAR));
        for (h=0; h<marking.range_x; h++)
          marking.mark_array[i][j][k][h] = (MY_CHAR)0;
      }
    }
  }
#ifdef PRINTING2
printf("MARK ARRAY HAS SIZE %d\n", (2*marking.range_x*marking.range_y*marking.range_z));
#endif
  marking.default_mark = 0;
  /* return the total size of allocated arrays */
  return (2*marking.range_x*marking.range_y*marking.range_z);

}

static GetBaseAndRange(int min_v, int max_v, int *base, int *range)
{
/*printf("GetBaseAndRange min=%d max=%d : ",min_v,max_v);*/
  (*base) = (-min_v)/4;
  (*range) = (-min_v+max_v)/4;
/*printf("   base=%d  range=%d\n", (*base), (*range));*/
}

static GetBaseAndRangeXYZ(int min_v, int max_v, int *base, int *range)
{
  if ((min_v %2)==1) min_v--;
  if ((max_v %2)==1) max_v++;
  (*base) = (-min_v)/2 +2;
  (*range) =(-min_v+max_v)/2 +4;
#ifdef PARLA
  printf("GetBaseAndRangeXYZ min=%d max=%d\n", min_v, max_v);
  printf("   base=%d  range=%d\n", (*base), (*range));
#endif
}

/* Note: min values are <=0, max values are >=0 */
int InitMarkArrayXYZ(int min_x, int min_y, int min_z,
                     int max_x, int max_y, int max_z)
{
  int i,j,k,h;
  GetBaseAndRangeXYZ(min_x, max_x, &marking.base_x, &marking.range_x);
  GetBaseAndRangeXYZ(min_y, max_y, &marking.base_y, &marking.range_y);
  GetBaseAndRangeXYZ(min_z, max_z, &marking.base_z, &marking.range_z);
  return AllocArray();
}


void ResetAllMarks()
{
  int i,j,k,h;
  for (i=0; i<2; i++)
  for (j=0; j<marking.range_z; j++)
  for (k=0; k<marking.range_y; k++)
  for (h=0; h<marking.range_x; h++)
    marking.mark_array[i][j][k][h] = (MY_CHAR)0;
}

/* ------------------------------------------------------------------------ */
/* Index conversions and array access for voxels */
/* ------------------------------------------------------------------------ */

/* Indexes (i0,i1,i2) are from Cartesian coordinates of voxel center,
   index i3 is 0 for even and 1 for odd voxels. */
static void IndexesFromVoxel(CellPtr voxel_c,
                             int *i0, int *i1, int *i2, int *i3)
{
  if (IsEvenVoxel(voxel_c))
  {
    *i0 = (Q_COORD(voxel_c)+S_COORD(voxel_c))/8;
    *i1 = (P_COORD(voxel_c)+S_COORD(voxel_c))/8;
    *i2 = (P_COORD(voxel_c)+Q_COORD(voxel_c))/8;
    *i3 = 0;
#ifdef PRINTING
{int x,y,z; printf("Voxel pari "); PrintCellPtr(voxel_c); 
VoxelCenterXYZ(voxel_c,&x,&y,&z);
printf(" ha centro (%d %d %d) e ", x,y,z); 
printf("ha indici (%d=%d %d=%d %d=%d) %d\n", 
*i0, (x/2), *i1, (y/2), *i2, (z/2), *i3);}
#endif
  }
  else /* IsOddVoxel(c) */
  {
    *i0 = ((Q_COORD(voxel_c)+S_COORD(voxel_c))/4-1)/2;
    *i1 = ((P_COORD(voxel_c)+S_COORD(voxel_c))/4-1)/2;
    *i2 = ((P_COORD(voxel_c)+Q_COORD(voxel_c))/4-1)/2;
    *i3 = 1;
#ifdef PRINTING
{int x,y,z; printf("Voxel dispari "); PrintCellPtr(voxel_c); 
VoxelCenterXYZ(voxel_c,&x,&y,&z);
printf(" ha centro (%d %d %d) e ", x,y,z);
printf("ha indici (%d=%d %d=%d %d=%d) %d\n",
*i0, (x/2), *i1, (y/2), *i2, (z/2), *i3);}
#endif
  }
} 

int GetVoxelStatus(CellPtr voxel_c)
{
  int a,b,c, d;
  IndexesFromVoxel(voxel_c,&a,&b,&c, &d);
  CONTROLLA_IND(voxel_c,a,b,c,d,"GetVoxelStatus");
  
/**  if (indexOutOfRange(a,b,c,d)) 
{printf("voxel che sconfina: ");PrintCellPtr(voxel_c); }**/
  if (indexOutOfRange(a,b,c,d)) return marking.default_mark;
  return VoxelStatusFromChar(marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)]);
}

void SetVoxelStatus(CellPtr voxel_c, int st)
{
  int a,b,c, d;
  IndexesFromVoxel(voxel_c,&a,&b,&c,&d);
  CONTROLLA_IND(voxel_c,a,b,c,d,"SetVoxelStatus");
#ifdef PRINTING2
if (st)
{
  printf("Per voxel "); PrintCellPtr(voxel_c); 
  printf("Set status: array[%d][%d][%d][%d] passa da %x",d,MARK_IND_Z(c),MARK_IND_Y(b),MARK_IND_X(a),
  marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)]);
}
#endif
  marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)] =
          SetVoxelStatusInChar(marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)], st);
#ifdef PRINTING2
if (st){ printf(" a %x\n", marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)]); }
#endif
}

void ResetVoxelStatus()
{
  int i,j,k,h;
  for (i=0; i<2; i++)
  for (j=0; j<marking.range_z; j++) 
  for (k=0; k<marking.range_y; k++)
  for (h=0; h<marking.range_x; h++)
      marking.mark_array[i][j][k][h] =
        SetVoxelStatusInChar(marking.mark_array[i][j][k][h], 0);
}

/*int CountVoxelStatus(int val)
{
  int count = 0;
  int i,j,k,h;
  for (i=0; i<2; i++)
  for (j=0; j<marking.range; j++) 
  for (k=0; k<marking.range; k++)
  for (h=0; h<marking.range; h++)
      if (VoxelStatusFromChar(marking.mark_array[i][j][k][h])==val)
         count++;
  return count;
}*/

/* ------------------------------------------------------------------------ */
/* Arrays for marking visited faces */
/* ------------------------------------------------------------------------ */

/* Faces are marked by using the same arrays used to mark voxels. */

/* Each face has a reference voxel.
   The arrays for marking faces are indexed on the Cartesian coordinates
   of the centers of the reference voxels of the face and on the face 
   index of the face (number in 0...6) within that voxel.
   Indeed this last index is not explicit, simply we keep for each voxel
   a single number which encodes the status of all faces.
   Each bit (0/1) of the number refers to a face.
   As for voxels, we have two arrays for faces whose reference voxel is
   even or odd, respectively.  */

/* Indexes (i0,i1,i2) are from Cartesian coordinates of reference
   voxel center, index i3 is 0 for even and 1 for odd voxels,
   index i4 is the face index within the reference voxel. */
static void IndexesFromFace(CellPtr face_c, 
                            int *i0, int *i1, int *i2, int *i3, int *i4)
{
#ifdef PRINTING
printf("IndexesFromFace ");PrintCellPtr(face_c);printf("\n");
#endif
  struct CellStruct adj1, adj2;
  GetFaceVoxels(face_c, &adj1, &adj2);
  /* the first one, adj1, is the reference voxel for the face */
  IndexesFromVoxel(&adj1, i0, i1, i2, i3);
  CONTROLLA_IND(&adj1,*i0,*i1,*i2,*i3,"IndexesFromFace");
#ifdef PRINTING
printf("  Ref. voxel: ");PrintCellPtr(&adj1);
printf(" ha indici (%d %d %d) %d\n", *i0, *i1, *i2, *i3);
#endif
  if (IsQuadFace(face_c))
  {
    /* index is 0,1,2 depending on whether face is in positive
       direction along x,y,z axis from adj1 */
    if ((P_COORD(face_c)-P_COORD((&adj1)))<0) (*i4) = 0;
    else if ((Q_COORD(face_c)-Q_COORD((&adj1)))<0) (*i4) = 1;
    else if ((R_COORD(face_c)-R_COORD((&adj1)))<0) (*i4) = 2;
#ifdef PRINTING
printf("  Faccia e' quad, ultimo ind=%d\n",*i4);
#endif
  }
  else /* IsHexFace(face_c) */
  {
    /* index is 3,4,5,6 depending on whether face is in positive
       direction along p,q,r,s axis from adj1 */
    if ((P_COORD(face_c)-P_COORD((&adj1)))>0) (*i4) = 3;
    else if ((Q_COORD(face_c)-Q_COORD((&adj1)))>0) (*i4) = 4;
    else if ((R_COORD(face_c)-R_COORD((&adj1)))>0) (*i4) = 5;
    else if ((S_COORD(face_c)-S_COORD((&adj1)))>0) (*i4) = 6;
#ifdef PRINTING
printf("  Faccia e' hex, ultimo ind=%d\n",*i4);
#endif
  }
}


int GetFaceStatus(CellPtr face_c)
{
  int a,b,c,d, e;
  int stored_value;
  IndexesFromFace(face_c,&a,&b,&c,&d, &e);
/*printf("GetFaceStatus per (%d,%d,%d,%d) accede array[%d][%d][%d][%d] bit %d\n",
P_COORD(face_c),Q_COORD(face_c),R_COORD(face_c),S_COORD(face_c), d,MARK_IND_Z(c),MARK_IND_Y(b),MARK_IND_X(a),e);
printf("   nel numero %x\n",marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)]);*/
  CONTROLLA_IND(face_c,a,b,c,d,"GetFaceStatus");
  if (indexOutOfRange(a,b,c,d)) return marking.default_mark;
  return FaceStatusFromChar(marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)], e);
}

void SetFaceStatus(CellPtr face_c, int st)
{
  int a,b,c,d, e;
  int stored_value;
  IndexesFromFace(face_c,&a,&b,&c,&d, &e);
  CONTROLLA_IND(face_c,a,b,c,d,"SetFaceStatus");
#ifdef PRINTING2
if (st)
{
 printf("SetFaceStatus per (%d,%d,%d,%d) array[%d][%d][%d][%d] bit %d passa da %x",
 P_COORD(face_c),Q_COORD(face_c),R_COORD(face_c),S_COORD(face_c), d,MARK_IND_Z(c),MARK_IND_Y(b),MARK_IND_X(a),(e+1),
 marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)]);
}
#endif
  marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)] = 
          SetFaceStatusInChar(marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)], e, st);
#ifdef PRINTING2
if (st) { printf(" a %x\n",marking.mark_array[d][MARK_IND_Z(c)][MARK_IND_Y(b)][MARK_IND_X(a)]); }
#endif
}

void ResetFaceStatus()
{
  int i,j,k,h;
  int val;
  for (i=0; i<2; i++)
  for (j=0; j<marking.range_z; j++) 
  for (k=0; k<marking.range_y; k++)
  for (h=0; h<marking.range_x; h++)
  {
    val = VoxelStatusFromChar(marking.mark_array[i][j][k][h]);
    marking.mark_array[i][j][k][h] = (MY_CHAR)0;
/*printf("ResetFaceStatus ho %x, metto stato del voxel=%d, ",marking.mark_array[i][j][k][h],val);*/
    marking.mark_array[i][j][k][h] =
      SetVoxelStatusInChar(marking.mark_array[i][j][k][h], val);
/*printf(" e viene %x\n", marking.mark_array[i][j][k][h]);*/
  }
}
