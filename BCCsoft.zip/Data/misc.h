#include <stddef.h>
#include <stdio.h>

#ifndef MISC_INCLUDED
#define MISC_INCLUDED

/* ------------------------------------------------------------------------ */
/* MISCELLANEA */
/* ------------------------------------------------------------------------ */

/* Boolean type is the same as integer, with the usual convention that
   zero is false and different from zero is true. */
typedef int BOOLEAN;

/* Print "true" or "false" depending on b different or equal to zero. */
extern void PrintBoolean(BOOLEAN b);

/* Get the modulo of the number divided by divisor. */
extern int GetMod(int number, int divisor);

/* Get the ratio of the number divided by divisor. */
extern int GetDiv(int number, int divisor);

#define INT_MOD4(num) GetMod(num,4)
#define INT_MOD8(num) GetMod(num,8)
#define INT_DIV8(num) GetDiv(num,8)

/* Test if the two numbers are equal to each other (modulo 4). */
extern BOOLEAN AreEqualMod4(int n1, int n2);

/* Test if the two numbers are equal to each other (modulo 8). */
extern BOOLEAN AreEqualMod8(int n1, int n2);

/* Test if the four numbers are equal to each other (modulo 8). */
extern BOOLEAN AreAllEqualMod8(int p, int q, int r, int s);

/* Assuming that three of the given numbers are equal and one is
   different, return the index (0,1,2,3) of the different one. */
extern int FindWhichDifferent(int p, int q, int r, int s);

extern int BUCKET_ARRAY[8];

/* Count how many of the given four (p,q,r,s) coordinates are equal to
   0,1,...,7 (modulo 8) and put the results in BUCKET_ARRAY[0...7]. */
extern void CountValuesMod8(int p, int q, int r, int s);

/* Count how many of the given four (p,q,r,s) coordinates are equal to
   the given number. */
extern int CountValues(int p, int q, int r, int s, int val);

extern char POSIT_ARRAY[4];

/* Sort coordinates p,q,r,s, in ascending order of their value mod 8,
   and put the resulting sequence of characters 'p', 'q', etc, in
   array POSIT_ARRAY[0..3]. */
extern void SortValuesMod8(int p, int q, int r, int s);

/* ------------------------------------------------------------------------ */

#endif /* MISC_INCLUDED */
