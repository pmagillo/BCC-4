#include <stddef.h>
#include <stdio.h>
#include "misc.h"

/* ------------------------------------------------------------------------ */
/* MISCELLANEA */
/* ------------------------------------------------------------------------ */

/* This file contains implementation, see header file for comments. */

int BUCKET_ARRAY[8];
char POSIT_ARRAY[4];

void PrintBoolean(BOOLEAN b)
{  if (b) printf("true"); else printf("false");  }

int GetMod(int number, int divisor)
{
  if (number>=0) return (number%divisor);
  else 
  {
/*int old_num = number;*/
    int mult = abs(number) / divisor;
    number += (mult+1)*divisor;
/*if ( (number%divisor) != (old_num%divisor) )
printf("---- MOD: diversi moduli di %d(=%d) %d(=%d)\n", 
number, (number%divisor), old_num, (old_num%divisor) );*/
    return (number%divisor);
  }
}

int GetDiv(int number, int divisor)
{
  if (number>=0) return (number/divisor);
  else 
  {
/*printf("---- DIV(%d): return %d\n", number,(-1-(abs(number+1)/8)));*/
    return -1-(abs(number+1)/divisor);
  }
}

BOOLEAN AreEqualMod4(int n1, int n2)
{
  return (INT_MOD4(n1)==INT_MOD4(n2));
}

BOOLEAN AreEqualMod8(int n1, int n2)
{
  return (INT_MOD8(n1)==INT_MOD8(n2));
}

BOOLEAN AreAllEqualMod8(int p, int q, int r, int s)
{
  return ( (INT_MOD8(p)==INT_MOD8(q)) && (INT_MOD8(p)==INT_MOD8(r)) &&
           (INT_MOD8(p)==INT_MOD8(s)) );
}

int FindWhichDifferent(int p, int q, int r, int s)
{
  if (INT_MOD8(p)==INT_MOD8(q))
  {
    if (INT_MOD8(p)==INT_MOD8(r)) return 3; /* s */
    else return 2; /* r */
  }
  else if (INT_MOD8(p)==INT_MOD8(r))
  {
    return 1; /* q */
  }
  else return 0; /* p */
}

void CountValuesMod8(int p, int q, int r, int s)
{
  int i;
  for (i=0; i<8; i++) BUCKET_ARRAY[i] = 0;
  BUCKET_ARRAY[INT_MOD8(p)]++;
  BUCKET_ARRAY[INT_MOD8(q)]++;
  BUCKET_ARRAY[INT_MOD8(r)]++;
  BUCKET_ARRAY[INT_MOD8(s)]++;
}

void SortValuesMod8(int p, int q, int r, int s)
{
  int i = 0, m = 0;
  while (i<4)
  {
    if (INT_MOD8(p)==m) POSIT_ARRAY[i++] = 'p';
    if (INT_MOD8(q)==m) POSIT_ARRAY[i++] = 'q';
    if (INT_MOD8(r)==m) POSIT_ARRAY[i++] = 'r';
    if (INT_MOD8(s)==m) POSIT_ARRAY[i++] = 's';
    m++;
  }
}

BOOLEAN InRange(int val, int min_v, int max_v)
{  return (val>=min_v)&&(val<=max_v);  }

int CountValues(int p, int q, int r, int s, int val)
{
  int i = 0;
  if (p==val) i++;
  if (q==val) i++;
  if (r==val) i++;
  if (s==val) i++;
  return i;
}



/* ------------------------------------------------------------------------ */
