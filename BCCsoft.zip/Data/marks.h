#include <stddef.h>
#include <stdio.h>
#include "cells.h"

#ifndef MARKS_INCLUDED
#define MARKS_INCLUDED

/* ------------------------------------------------------------------------ */
/* ARRAYS FOR MARKING VOXELS AND FACES */
/* ------------------------------------------------------------------------ */

/* This file contains only exported functions, see corresponding source 
   file for implementation details. */

/* The status of voxels and faces is a Boolean: 0 for empty voxels 
   and unvisited faces, 1 for full voxels and visited faces.
   The status is stored in an array whose dimensions depend on the
   range of coordinates of voxels.
   The same array element (an unsigned char = 1 byte) stores the mark for
   a voxel and for the 7 faces having that voxel as their reference 
   voxel. */

/* Allocate marking array sufficient to mark voxels whose coordinates
   (Cartesian coordinates of the voxel center) are in given range,
   and their faces. Return number of allocated bytes. */
extern int InitMarkArrayXYZ(int min_x, int min_y, int min_z,
                            int max_x, int max_y, int max_z);

/* Reset all marks to zero. */
extern void ResetAllMarks();

/* Define how to consider the status of voxels that happen to fall outside
   the limits of marking array. */
extern void SetDefaultStatus(int st);

/* Get the default value used as the status of voxels that fall outside
   the limits of marking array. */
extern int GetDefaultStatus();

/* ------------------------------------------------------------------------ */
/* Marking full and empty voxels */
/* ------------------------------------------------------------------------ */

extern int GetVoxelStatus(CellPtr voxel_c);

extern void SetVoxelStatus(CellPtr voxel_c, int status);

extern void ResetVoxelStatus();

/*extern int CountVoxelStatus(int val);*/

/* ------------------------------------------------------------------------ */
/* Array for marking visited faces */
/* ------------------------------------------------------------------------ */

/*
Many faces are represented on the same integer, where each bit 
corresponds to a face.
*/

extern BOOLEAN GetFaceStatus(CellPtr face_c);

/* Set face status, argument can be 0 or 1. */
extern void SetFaceStatus(CellPtr face_c, int st);

/* Reset the status of all faces to 0. */
extern void ResetFaceStatus();

/* ------------------------------------------------------------------------ */

#endif /* MARKS_INCLUDED */
