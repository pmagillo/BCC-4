/* test edge-based relations */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "relations.h"

int main(int argc, char ** argv)
{
  int p,q,r,s;
  struct CellStruct inc_voxels[3];
  struct CellStruct inc_faces[2]; 
  struct CellStruct inc_verts[2];
  struct CellStruct aux[24];
  struct CellStruct e;
  struct CellStruct vox;
  int i,j, m;
  int error_occurred = 0;
  
  if (argc!=5)
  {
    printf("Need 4 coords p q r s of an edge\n");
    return 0;
  }
  sscanf(argv[1],"%d",&p);
  sscanf(argv[2],"%d",&q);
  sscanf(argv[3],"%d",&r);
  sscanf(argv[4],"%d",&s);
  FillCoord(&e, p,q,r,s);
  
  if (!IsCell(&e))
  {
    printf("Given coordinates are not a cell\n");
    return 0;
  }
  if (!IsEdge(&e))
  {
    printf("Given coordinates are not an edge\n");
    return 0;
  }
  
  fprintf(stderr, "Relations of edge ");

  fprintf(stderr, "(%d,%d,%d,%d)", p,q,r,s);
/*  PrintCellPtr(&e);*/
  printf("\n");
  
  printf("Incid voxels:\n");
  error_occurred = 0;
  GetEdgeVoxels(&e, inc_voxels);
  for (i=0; i<3; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_voxels[i]);
    if ( (IsEvenEdge(&e)&&IsEvenVoxel(&inc_voxels[i])) ||
         (IsOddEdge(&e)&&IsOddVoxel(&inc_voxels[i])) )
      m = GetVoxelQuadEdges(&inc_voxels[i], aux);
    else
      m = GetVoxelHexEdges(&inc_voxels[i], aux);
    if (!IsAmongCells(&e, m, aux))
    {  printf("ERR voxel has not this edge\n");
       error_occurred = 1;
    }
  }
  GetEdgeMainVoxel(&e, &vox);
  if (!AreSameCell(&vox, &inc_voxels[2]))
  {  printf("ERR main voxel is not voxel 2, it is ");
     PrintCellPtr(&vox);
     error_occurred = 1;
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Incid quad-face:\n");
  GetEdgeQuadFace(&e, &inc_faces[0]);
  PrintPlainCellPtr(&inc_faces[0]);
  GetFaceEdges(&inc_faces[0], aux);
  if (!IsAmongCells(&e, 4, aux))
    printf("ERR face has not this edge\n");
  else printf("ok\n");

  error_occurred = 0;
  printf("Incid hex-faces:\n");
  GetEdgeHexFaces(&e, &inc_faces[0], &inc_faces[1]);
  for (i=0; i<2; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_faces[i]);
    m = GetFaceEdges(&inc_faces[i], aux);
    if (!IsAmongCells(&e, m, aux))
    {  printf("ERR face has not this edge\n");
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Incid vertices:\n");
  GetEdgeVertices(&e, &inc_verts[0], &inc_verts[1]);
  for (i=0; i<2; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_verts[i]);
    m = GetVertexEdges(&inc_verts[i], aux);
    if (!IsAmongCells(&e, m, aux))
    {  printf("ERR vertex has not this edge\n");
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

#ifdef AAAAA
  printf("Alignment of voxels and hex-faces:\n");
  for (i=0; i<4; i++)
  {
    int a,b; 
    /* hex-faces i and i+1 have voxels (i+2) */
    m = (i+2)%4;
    GetFaceVoxels(&inc_faces[i], &aux[0], &aux[1]);
    a = AreSameCell(&aux[0],&inc_voxels[m])||
        AreSameCell(&aux[1],&inc_voxels[m]);
    if (!a)
    {  printf("ERR hex-face %d has not voxel %d, it has\n", i, m);
       PrintPlainCellPtr(&aux[0]); printf(" and ");
       PrintPlainCellPtr(&aux[1]);
    }
    GetFaceVoxels(&inc_faces[(i+1)%4], &aux[0], &aux[1]);
    b = AreSameCell(&aux[0],&inc_voxels[m])||
        AreSameCell(&aux[1],&inc_voxels[m]);
    if (!b)
    {  printf("ERR hex-face %d has not voxel %d, it has\n", ((i+1)%4), m);
       PrintPlainCellPtr(&aux[0]); printf(" and ");
       PrintPlainCellPtr(&aux[1]);
    }
    error_occurred =!(a&&b);
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of voxels and quad-faces:\n");
  for (i=0; i<2; i++)
  {
    int a,b;
    /* quad-face i+4 has voxels i+1 and i+3 */
    GetFaceVoxels(&inc_faces[i+4], &aux[0], &aux[1]);
    a = AreSameCell(&aux[0],&inc_voxels[i+1])||
        AreSameCell(&aux[1],&inc_voxels[i+1]);
    if (!a)
    {  printf("ERR quad-face %d has not voxel %d, it has\n", (i+4), (i+1));
       PrintPlainCellPtr(&aux[0]); printf(" and ");
       PrintPlainCellPtr(&aux[1]);
    }
    GetFaceVoxels(&inc_faces[i+4], &aux[0], &aux[1]);
    b = AreSameCell(&aux[0],&inc_voxels[(i+3)%4])||
        AreSameCell(&aux[1],&inc_voxels[(i+3)%4]);
    if (!b)
    {  printf("ERR quad-face %d has not voxel %d, it has\n", (i+4), ((i+3)%4));
       PrintPlainCellPtr(&aux[0]); printf(" and ");
       PrintPlainCellPtr(&aux[1]);
    }
    error_occurred =!(a&&b);
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of voxels and edges:\n");
  for (i=0; i<4; i++)
  {
    /* edge i is on all voxels except i */
    m = GetEdgeVoxels(&inc_edges[i], aux);
    for (j=0; j<4; j++)
    {
      if (i!=j)
        if (!IsAmongCells(&inc_voxels[j], m, aux))
        {  printf("ERR edge %d is not on voxel %d\n", i,j);
           error_occurred = 1;
        }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of hex- faces and edges:\n");
  for (i=0; i<4; i++)
  {
    /* hex-faces i and i+1 share edge i */
    GetCommonEdge(&inc_faces[i], &inc_faces[(i+1)%4], &aux[0]);
    if (!AreSameCell(&inc_edges[i],&aux[0])) 
    {  printf(" common edge of faces %d and %d is ", i, ((i+1)%4));
       PrintPlainCellPtr(&aux[0]);
       printf(" and it should be edge %d =", i);
       PrintPlainCellPtr(&inc_edges[i]);
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of quad- faces and edges:\n");
  for (i=0; i<2; i++)
  {
    /* quad-face i+1 shares edges i and 2+i */
    GetFaceEdges(&inc_faces[i+4], aux);
    if (!(IsAmongCells(&inc_edges[i],4,aux)&&
          IsAmongCells(&inc_edges[2+i],4,aux)))
    {  printf("ERR quad-face %d has not edges %d and %d\n",(i+4),i, (2+i));
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;
#endif
}
