#include <stddef.h>
#include <stdio.h>
#include "relations.h"
#include "checking.h"

/* #define CONTROLLA This is just for debugging, then comment this line */

#ifdef CONTA
/* count calls to GetVertexFaces, GetFaceVoxels */
int calledPF, calledFV = 0;
#endif

/* ------------------------------------------------------------------------ */
/* CONNECTIVITY RELATIONS AMONG CELLS */
/* ------------------------------------------------------------------------ */

/* This file contains implementation, see header file for comments. */

/* ------------------------------------------------------------------------ */
/* Adjacency relations for voxels. */
/* ------------------------------------------------------------------------ */

void Get6AdjacentVoxelDir(CellPtr c, char dir_name, int sign, CellPtr adj)
{
  CHECK(IsVoxel(c), "Get6AdjacentVoxelDir, c is not voxel\n");
  switch (dir_name)
  {
    case 'x':
      if (sign==1) SumCoordinates(c, -4, 4, -4, 4, adj);
      else   SumCoordinates(c, 4, -4, 4, -4, adj);
    break;
    case 'y':
      if (sign==1) SumCoordinates(c, 4, -4, -4, 4, adj);
      else   SumCoordinates(c, -4, 4, 4, -4, adj);
    break;
    case 'z':
      if (sign==1) SumCoordinates(c, 4, 4, -4, -4, adj);
      else   SumCoordinates(c, -4, -4, 4, 4, adj);
    break;
  }
}

BOOLEAN Are6AdjacentVoxels (CellPtr c1, CellPtr c2, char *dir_name, int *sign)
{
  struct CellStruct aux;
  CHECK(IsVoxel(c1), "Get6AdjacentVoxel, c1 is not voxel\n");
  CHECK(IsVoxel(c2), "Get6AdjacentVoxel, c2 is not voxel\n");
  DiffCells(c2,c1, &aux);  
  if (CellHasCoords(&aux, -4, 4, -4, 4)) 
  {  (*dir_name) = 'x'; (*sign) = 1; }
  else if (CellHasCoords(&aux, 4, -4, 4, -4)) 
  {  (*dir_name) = 'x'; (*sign) = -1; }
  else if (CellHasCoords(&aux, 4, -4, -4, 4))
  {  (*dir_name) = 'y'; (*sign) = 1; }
  else if (CellHasCoords(&aux, -4, 4, 4, -4))
  {  (*dir_name) = 'y'; (*sign) = -1; }
  else if (CellHasCoords(&aux, 4, 4, -4, -4))
  {  (*dir_name) = 'z'; (*sign) = 1; }
  else if (CellHasCoords(&aux, -4, -4, 4, 4))
  {  (*dir_name) = 'z'; (*sign) = -1; }
  else return 0;
  return 1;
}

void Get8AdjacentVoxelDir (CellPtr c, char dir_name, int sign, CellPtr adj)
{
  CHECK(IsVoxel(c), "Get8AdjacentVoxel, c is not voxel\n");
  switch (dir_name)
  {
    case 'p':
      if (sign==1)  SumCoordinates(c, 6, -2, -2, -2, adj);
      else   SumCoordinates(c, -6, 2, 2, 2, adj);
      break;
    case 'q':
      if (sign==1)  SumCoordinates(c, -2, 6, -2, -2, adj);
      else   SumCoordinates(c, 2, -6, 2, 2, adj);
      break;
    case 'r':
      if (sign==1)  SumCoordinates(c, -2, -2, 6, -2, adj);
      else   SumCoordinates(c, 2, 2, -6, 2, adj);
      break;
    case 's':
      if (sign==1)  SumCoordinates(c, -2, -2, -2, 6, adj);
      else  SumCoordinates(c, 2, 2, 2, -6, adj);
      break;
  }
}

BOOLEAN Are8AdjacentVoxels (CellPtr c1, CellPtr c2, char *dir_name, int *sign)
{
  struct CellStruct aux;
  CHECK(IsVoxel(c1), "Get8AdjacentVoxel, c1 is not voxel\n");
  CHECK(IsVoxel(c2), "Get8AdjacentVoxel, c2 is not voxel\n");
  DiffCells(c2,c1, &aux);  
  if (CellHasCoords(&aux, 6, -2, -2, -2))
  {  (*dir_name) = 'p'; (*sign) = 1; }
  else if (CellHasCoords(&aux, -6, 2, 2, 2))
  {  (*dir_name) = 'p'; (*sign) = -1; }
  else if (CellHasCoords(&aux, -2, 6, -2, -2))
  {  (*dir_name) = 'q'; (*sign) = 1; }
  else if (CellHasCoords(&aux, 2, -6, 2, 2))
  {  (*dir_name) = 'q'; (*sign) = -1; }
  else if (CellHasCoords(&aux, -2, -2, 6, -2))
  {  (*dir_name) = 'r'; (*sign) = 1; }
  else if (CellHasCoords(&aux, 2, 2, -6, 2))
  {  (*dir_name) = 'r'; (*sign) = -1; }
  else if (CellHasCoords(&aux, -2, -2, -2, 6))
  {  (*dir_name) = 's'; (*sign) = 1; }
  else if (CellHasCoords(&aux, 2, 2, 2, -6))
  {  (*dir_name) = 's'; (*sign) = -1; }
  else return 0;
  return 1;
}

/* Assume c1, c2 voxels and mutually adjacent. Do not check. */
void GetCommonFace (CellPtr c1, CellPtr c2, CellPtr fac)
{
  CHECK(IsVoxel(c1), "GetCommonFace, c1 is not voxel\n");
  CHECK(IsVoxel(c2), "GetCommonFace, c2 is not voxel\n");
  P_COORD(fac) = (P_COORD(c1) + P_COORD(c2)) / 2;
  Q_COORD(fac) = (Q_COORD(c1) + Q_COORD(c2)) / 2;
  R_COORD(fac) = (R_COORD(c1) + R_COORD(c2)) / 2;
  S_COORD(fac) = (S_COORD(c1) + S_COORD(c2)) / 2;
}

int Get6AdjacentVoxels(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVoxel(c), "Get6AdjacentVoxels, c is not voxel\n");
  /* voxels in positive direction of x,y,z */
  SumCoordinates(c, -4, 4, -4, 4, &cell_array[0]); 
  SumCoordinates(c, 4, -4, -4, 4, &cell_array[1]);
  SumCoordinates(c, 4, 4, -4, -4, &cell_array[2]);
  /* voxels in negative direction of x,y,z */
  SumCoordinates(c, 4, -4, 4, -4, &cell_array[3]);
  SumCoordinates(c, -4, 4, 4, -4, &cell_array[4]);
  SumCoordinates(c, -4, -4, 4, 4, &cell_array[5]);
  return 6;
}

int Get8AdjacentVoxels(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVoxel(c), "Get8AdjacentVoxels, c is not voxel\n");
  /* voxels in positive direction of p,q,r,s */
  SumCoordinates(c, 6, -2, -2, -2, &cell_array[0]); 
  SumCoordinates(c, -2, 6, -2, -2, &cell_array[1]); 
  SumCoordinates(c, -2, -2, 6, -2, &cell_array[2]); 
  SumCoordinates(c, -2, -2, -2, 6, &cell_array[3]); 
  /* voxels in negative direction of p,q,r,s */
  SumCoordinates(c, -6, 2, 2, 2, &cell_array[4]); 
  SumCoordinates(c, 2, -6, 2, 2, &cell_array[5]); 
  SumCoordinates(c, 2, 2, -6, 2, &cell_array[6]); 
  SumCoordinates(c, 2, 2, 2, -6, &cell_array[7]); 
  return 8;
}

int GetVoxelQuadFaces(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVoxel(c), "GetVoxelQuadFaces, c is not voxel\n");
  /* quad-faces in positive direction of x,y,z */
  SumCoordinates(c, -2, 2, -2, 2, &cell_array[0]); 
  SumCoordinates(c, 2, -2, -2, 2, &cell_array[1]);
  SumCoordinates(c, 2, 2, -2, -2, &cell_array[2]);
  /* quad-faces in negative direction of x,y,z */
  SumCoordinates(c, 2, -2, 2, -2, &cell_array[3]);
  SumCoordinates(c, -2, 2, 2, -2, &cell_array[4]);
  SumCoordinates(c, -2, -2, 2, 2, &cell_array[5]);
  return 6;
}

int GetVoxelHexFaces(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVoxel(c), "GetVoxelHexFaces, c is not voxel\n");
  /* hex-faces in positive direction of p,q,r,s */
  SumCoordinates(c, 3, -1, -1, -1, &cell_array[0]); 
  SumCoordinates(c, -1, 3, -1, -1, &cell_array[1]); 
  SumCoordinates(c, -1, -1, 3, -1, &cell_array[2]); 
  SumCoordinates(c, -1, -1, -1, 3, &cell_array[3]); 
  /* hex-faces in negative direction of p,q,r,s */
  SumCoordinates(c, -3, 1, 1, 1, &cell_array[4]); 
  SumCoordinates(c, 1, -3, 1, 1, &cell_array[5]); 
  SumCoordinates(c, 1, 1, -3, 1, &cell_array[6]); 
  SumCoordinates(c, 1, 1, 1, -3, &cell_array[7]); 
  return 8;
}

int GetAdjacentVoxels(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVoxel(c), "GetAdjacentVoxels, c is not voxel\n");
  /* voxels in positive direction of x,y,z */
  SumCoordinates(c, -4, 4, -4, 4, &cell_array[0]); 
  SumCoordinates(c, 4, -4, -4, 4, &cell_array[1]);
  SumCoordinates(c, 4, 4, -4, -4, &cell_array[2]);
  /* voxels in negative direction of x,y,z */
  SumCoordinates(c, 4, -4, 4, -4, &cell_array[3]);
  SumCoordinates(c, -4, 4, 4, -4, &cell_array[4]);
  SumCoordinates(c, -4, -4, 4, 4, &cell_array[5]);
  /* voxels in positive direction of p,q,r,s */
  SumCoordinates(c, 6, -2, -2, -2, &cell_array[6]); 
  SumCoordinates(c, -2, 6, -2, -2, &cell_array[7]); 
  SumCoordinates(c, -2, -2, 6, -2, &cell_array[8]); 
  SumCoordinates(c, -2, -2, -2, 6, &cell_array[9]); 
  /* voxels in negative direction of p,q,r,s */
  SumCoordinates(c, -6, 2, 2, 2, &cell_array[10]); 
  SumCoordinates(c, 2, -6, 2, 2, &cell_array[11]); 
  SumCoordinates(c, 2, 2, -6, 2, &cell_array[12]); 
  SumCoordinates(c, 2, 2, 2, -6, &cell_array[13]); 
  return 14;
}

int GetVoxelHexEdges(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVoxel(c), "GetVoxelHexEdges, c is not voxel\n");
  /* edges of hex-face (+3, -1, -1, -1) in positive p-direction */
  SumCoordinates(c, 2,  0,  0, -2, &cell_array[0]); 
  SumCoordinates(c, 2, -2,  0,  0, &cell_array[1]); 
  SumCoordinates(c, 2,  0, -2,  0, &cell_array[2]); 
  /* edges of hex-face (-1, +3, -1, -1) in positive q-direction */
  SumCoordinates(c,  0, 2,  0, -2, &cell_array[3]); 
  SumCoordinates(c, -2, 2,  0,  0, &cell_array[4]); 
  SumCoordinates(c,  0, 2, -2,  0, &cell_array[5]); 
  /* edges of hex-face (-1, -1, +3, -1) in positive r-direction */
  SumCoordinates(c, -2,  0, 2,  0, &cell_array[6]);
  SumCoordinates(c,  0,  0, 2, -2, &cell_array[7]);
  SumCoordinates(c,  0, -2, 2,  0, &cell_array[8]);
  /* edges of hex-face (-1, -1, -1, +3) in positive s-direction */
  SumCoordinates(c,  0, -2,  0, 2, &cell_array[9]); 
  SumCoordinates(c,  0,  0, -2, 2, &cell_array[10]);
  SumCoordinates(c, -2,  0,  0, 2, &cell_array[11]);
  return 12;
}

int GetVoxelQuadEdges(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVoxel(c), "GetVoxelQuadEdges, c is not voxel\n");
  /* edges of quad-face (-2, +2, -2, +2) in positive x-direction */
  SumCoordinates(c,  0, 2, -4, 2, &cell_array[0]); 
  SumCoordinates(c, -2, 0, -2, 4, &cell_array[1]);
  SumCoordinates(c, -4, 2,  0, 2, &cell_array[2]);
  SumCoordinates(c, -2, 4, -2, 0, &cell_array[3]);
  /* edges of quad-face (+2, -2, -2, +2) in positive y-direction */
  SumCoordinates(c, 4, -2, -2, 0, &cell_array[4]); 
  SumCoordinates(c, 2,  0, -4, 2, &cell_array[5]);
  SumCoordinates(c, 0, -2, -2, 4, &cell_array[6]);
  SumCoordinates(c, 2, -4,  0, 2, &cell_array[7]);
  /* edges of quad-face (+2, +2, -2, -2) in positive z-direction */
  SumCoordinates(c, 4, 0, -2, -2, &cell_array[8]);
  SumCoordinates(c, 2, 2, -4,  0, &cell_array[9]);
  SumCoordinates(c, 0, 4, -2, -2, &cell_array[10]);
  SumCoordinates(c, 2, 2,  0, -4, &cell_array[11]);
  /* edges of quad-face (+2, -2, +2, -2) in negative x-direction */
  SumCoordinates(c, 4, -2, 0, -2, &cell_array[12]);
  SumCoordinates(c, 2, -4, 2,  0, &cell_array[13]);
  SumCoordinates(c, 0, -2, 4, -2, &cell_array[14]);
  SumCoordinates(c, 2,  0, 2, -4, &cell_array[15]);
  /* edges of quad-face (-2, +2, +2, -2) in negative y-direction */
  SumCoordinates(c,  0, 2, 2, -4, &cell_array[16]);
  SumCoordinates(c, -2, 4, 0, -2, &cell_array[17]);
  SumCoordinates(c, -4, 2, 2,  0, &cell_array[18]);
  SumCoordinates(c, -2, 0, 4, -2, &cell_array[19]);
  /* edges of quad-face (-2, -2, +2, +2) in negative z-direction */
  SumCoordinates(c,  0, -4, 2, 2, &cell_array[20]);
  SumCoordinates(c, -2, -2, 0, 4, &cell_array[21]);
  SumCoordinates(c, -4,  0, 2, 2, &cell_array[22]);
  SumCoordinates(c, -2, -2, 4, 0, &cell_array[23]);
  return 24;
}

int GetVoxelVertices(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVoxel(c), "GetVoxelVertices, c is not voxel\n");
  /* vertices of quad-face (-2, +2, -2, +2) in positive x-direction */
  SumCoordinates(c, -1, 1, -3, 3, &cell_array[0]); 
  SumCoordinates(c, -3, 1, -1, 3, &cell_array[1]);
  SumCoordinates(c, -3, 3, -1, 1, &cell_array[2]);
  SumCoordinates(c, -1, 3, -3, 1, &cell_array[3]);
  /* vertices of quad-face (+2, -2, -2, +2) in positive y-direction */
  SumCoordinates(c, 3, -1, -3, 1, &cell_array[4]); 
  SumCoordinates(c, 1, -1, -3, 3, &cell_array[5]);
  SumCoordinates(c, 1, -3, -1, 3, &cell_array[6]);
  SumCoordinates(c, 3, -3, -1, 1, &cell_array[7]);
  /* vertices of quad-face (+2, +2, -2, -2) in positive z-direction */
  SumCoordinates(c, 3, 1, -3, -1, &cell_array[8]);
  SumCoordinates(c, 1, 3, -3, -1, &cell_array[9]);
  SumCoordinates(c, 1, 3, -1, -3, &cell_array[10]);
  SumCoordinates(c, 3, 1, -1, -3, &cell_array[11]);
  /* vertices of quad-face (+2, -2, +2, -2) in negative x-direction */
  SumCoordinates(c, 3, -3, 1, -1, &cell_array[12]);
  SumCoordinates(c, 1, -3, 3, -1, &cell_array[13]);
  SumCoordinates(c, 1, -1, 3, -3, &cell_array[14]); 
  SumCoordinates(c, 3, -1, 1, -3, &cell_array[15]);
  /* vertices of quad-face (-2, +2, +2, -2) in negative y-direction */
  SumCoordinates(c, -1, 3, 1, -3, &cell_array[16]);
  SumCoordinates(c, -3, 3, 1, -1, &cell_array[17]);
  SumCoordinates(c, -3, 1, 3, -1, &cell_array[18]);
  SumCoordinates(c, -1, 1, 3, -3, &cell_array[19]);
  /* vertices of quad-face (-2, -2, +2, +2) in negative z-direction */
  SumCoordinates(c, -1, -3, 1, 3, &cell_array[20]);
  SumCoordinates(c, -3, -1, 1, 3, &cell_array[21]);
  SumCoordinates(c, -3, -1, 3, 1, &cell_array[22]);
  SumCoordinates(c, -1, -3, 3, 1, &cell_array[23]);
  return 24;
}

/* ------------------------------------------------------------------------ */
/* Relations for a face. */
/* ------------------------------------------------------------------------ */

/* Check is the face is perpendicular to X axis. It assumes a quad-face,
   i.e., face has two pairs of equal coordinates (mod 8).
   True iff P=R (mod 8). In a quad-face, this implies Q=S (mod 8). */
BOOLEAN IsFaceX(CellPtr c)
{
  CHECK(IsQuadFace(c), "IsFaceX, c is not quad-face\n");
  return AreEqualMod8(P_COORD(c),R_COORD(c));
}

/* Check is the face is perpendicular to Y axis. It assumes a quad-face,
   i.e., face has one different and three equal coordinates (mod 8).
   True iff P=S (mod 8). In a quad-face, this implies Q=R (mod 8). */
BOOLEAN IsFaceY(CellPtr c)
{
  CHECK(IsQuadFace(c), "IsFaceY, c is not quad-face\n");
  return AreEqualMod8(P_COORD(c),S_COORD(c));
}

/* Check is the face is perpendicular to Z axis. It assumes a quad-face.
   True iff P=Q (mod 8). In a quad-face, this implies R=S (mod 8). */
BOOLEAN IsFaceZ(CellPtr c)
{
  CHECK(IsQuadFace(c), "IsFaceZ, c is not quad-face\n");
  return AreEqualMod8(P_COORD(c),Q_COORD(c));
}
/* Check is the face is perpendicular to P axis. It assumes hex-face. 
   True iff the different coordinate (mod 8) is P. */
BOOLEAN IsFaceP(CellPtr c)
{
  CHECK(IsHexFace(c), "IsFaceP, c is not hex-face\n");
  return AreEqualMod8(Q_COORD(c),R_COORD(c))&&
         AreEqualMod8(Q_COORD(c),S_COORD(c));
}

/* Check is the face is perpendicular to Q axis. It assumes hex-face. 
   True iff the different coordinate (mod 8) is Q. */
BOOLEAN IsFaceQ(CellPtr c)
{
  CHECK(IsHexFace(c), "IsFaceQ, c is not hex-face\n");
  return AreEqualMod8(P_COORD(c),R_COORD(c))&&
         AreEqualMod8(P_COORD(c),S_COORD(c));
}

/* Check is the face is perpendicular to R axis. It assumes hex-face. 
   True iff the different coordinate (mod 8) is R. */
BOOLEAN IsFaceR(CellPtr c)
{
  CHECK(IsHexFace(c), "IsFaceR, c is not hex-face\n");
  return AreEqualMod8(P_COORD(c),Q_COORD(c))&&
         AreEqualMod8(P_COORD(c),S_COORD(c));
}

/* Check is the face is perpendicular to S axis. It assumes hex-face. 
   True iff the different coordinate (mod 8) is S. */
BOOLEAN IsFaceS(CellPtr c)
{
  CHECK(IsHexFace(c), "IsFaceS, c is not hex-face\n");
  return AreEqualMod8(P_COORD(c),Q_COORD(c))&&
          AreEqualMod8(P_COORD(c),R_COORD(c));
}

/* ------------------------------------------------------------------------ */


int GetFaceVoxels(CellPtr c, CellPtr adj1, CellPtr adj2)
{
#ifdef CONTA
calledFV++;
#endif
  CHECK((IsHexFace(c)||IsQuadFace(c)), "GetFaceVoxels, c is not face\n");
  int i;
  if (IsHexFace(c))
  { 
    if (IsFaceS(c))
    { 
      SumCoordinates(c, -1, -1, -1, 3, adj2);
      SumCoordinates(c, 1, 1, 1, -3, adj1);
      return 2;
    }
    else if (IsFaceR(c))
    { 
      SumCoordinates(c, -1, -1, 3, -1, adj2);
      SumCoordinates(c, 1, 1, -3, 1, adj1);
      return 2;
    }
    else if (IsFaceQ(c))
    { 
      SumCoordinates(c, -1, 3, -1, -1, adj2);
      SumCoordinates(c, 1, -3, 1, 1, adj1);
      return 2;
    }
    else /* IsFaceP(c) */
    { 
      SumCoordinates(c, 3, -1, -1, -1, adj2);
      SumCoordinates(c, -3, 1, 1, 1, adj1);
      return 2;
    }
  }
  else /* IsEvenQuadFace(c) or IsOddQuadFace(c) */
  { 
    if (IsFaceZ(c))
    { 
      SumCoordinates(c, 2, 2, -2, -2, adj2);
      SumCoordinates(c, -2, -2, 2, 2, adj1);
      return 2;
    }
    else  if (IsFaceX(c))
    { 
      SumCoordinates(c, 2, -2, 2, -2, adj1);
      SumCoordinates(c, -2, 2, -2, 2, adj2);
      return 2;
    }
    else /* IsFace(y) */
    { 
      SumCoordinates(c, 2, -2, -2, 2, adj2);
      SumCoordinates(c, -2, 2, 2, -2, adj1);
      return 2;
    }
  }
}

int GetFaceEdges(CellPtr c, CellPtr cell_array)
{
  CHECK((IsHexFace(c)||IsQuadFace(c)), "GetFaceEdges, c is not face\n");
  if (IsHexFace(c))
  {
    if (IsFaceS(c))
    { 
      SumCoordinates(c, -1, 1, 1, -1, &cell_array[0]);
      SumCoordinates(c, -1, 1, -1, 1, &cell_array[1]);
      SumCoordinates(c, 1, 1, -1, -1, &cell_array[2]);
      SumCoordinates(c, 1, -1, -1, 1, &cell_array[3]);
      SumCoordinates(c, 1, -1, 1, -1, &cell_array[4]);
      SumCoordinates(c, -1, -1, 1, 1, &cell_array[5]);
    }
    else if (IsFaceR(c))
    { 
      SumCoordinates(c, -1, 1, 1, -1, &cell_array[0]);
      SumCoordinates(c, -1, 1, -1, 1, &cell_array[1]);
      SumCoordinates(c, -1, -1, 1, 1, &cell_array[2]);
      SumCoordinates(c, 1, -1, -1, 1, &cell_array[3]);
      SumCoordinates(c, 1, -1, 1, -1, &cell_array[4]);
      SumCoordinates(c, 1, 1, -1, -1, &cell_array[5]);
    }
    else if (IsFaceQ(c))
    {
      SumCoordinates(c, 1, -1, 1, -1, &cell_array[0]);
      SumCoordinates(c, -1, 1, 1, -1, &cell_array[1]);
      SumCoordinates(c, -1, -1, 1, 1, &cell_array[2]);
      SumCoordinates(c, -1, 1, -1, 1, &cell_array[3]);
      SumCoordinates(c, 1, -1, -1, 1, &cell_array[4]);
      SumCoordinates(c, 1, 1, -1, -1, &cell_array[5]);
    }
    else /* IsFaceP(c) */
    {
      SumCoordinates(c, -1, 1, 1, -1, &cell_array[0]);
      SumCoordinates(c, 1, -1, 1, -1, &cell_array[1]);
      SumCoordinates(c, -1, -1, 1, 1, &cell_array[2]);
      SumCoordinates(c, 1, -1, -1, 1, &cell_array[3]);
      SumCoordinates(c, -1, 1, -1, 1, &cell_array[4]);
      SumCoordinates(c, 1, 1, -1, -1, &cell_array[5]);
    }
    CHECK_ALL_EDGES(cell_array, 6, "GetFaceEdges, result for hex-face");
    return 6;
  }
  else /* quad-face */
  {
    if (IsFaceZ(c))
    {
      SumCoordinates(c, 2, -2, 0, 0, &cell_array[0]);
      SumCoordinates(c, 0, 0, -2, 2, &cell_array[1]);
      SumCoordinates(c, -2, 2, 0, 0, &cell_array[2]);
      SumCoordinates(c, 0, 0, 2, -2, &cell_array[3]);
    }
    else if (IsFaceX(c))
    {
      SumCoordinates(c, 2, 0, -2, 0, &cell_array[0]);
      SumCoordinates(c, 0, -2, 0, 2, &cell_array[1]);
      SumCoordinates(c, -2, 0, 2, 0, &cell_array[2]);
      SumCoordinates(c, 0, 2, 0, -2, &cell_array[3]);
    }
    else if (IsFaceY(c))
    {
      SumCoordinates(c, 2, 0, 0, -2, &cell_array[0]);
      SumCoordinates(c, 0, 2, -2, 0, &cell_array[1]);
      SumCoordinates(c, -2, 0, 0, 2, &cell_array[2]);
      SumCoordinates(c, 0, -2, 2, 0, &cell_array[3]);
    }
    CHECK_ALL_EDGES(cell_array, 4, "GetFaceEdges, result for quad-face");
    return 4;
  }
}

int GetAdjacentHexFaces(CellPtr c, CellPtr cell_array)
{
  CHECK((IsHexFace(c)||IsQuadFace(c)), "GetAdjacentHexFaces, c is not face\n");
  if (IsHexFace(c))
  {
    if (IsFaceS(c))
    {
      SumCoordinates(c, -2, 2, 2, -2, &cell_array[0]);
      SumCoordinates(c, -2, 2, -2, 2, &cell_array[1]);
      SumCoordinates(c, 2, 2, -2, -2, &cell_array[2]);
      SumCoordinates(c, 2, -2, -2, 2, &cell_array[3]);
      SumCoordinates(c, 2, -2, 2, -2, &cell_array[4]);
      SumCoordinates(c, -2, -2, 2, 2, &cell_array[5]);
    }
    else if (IsFaceR(c))
    {
      SumCoordinates(c, -2, 2, 2, -2, &cell_array[0]);
      SumCoordinates(c, -2, 2, -2, 2, &cell_array[1]);
      SumCoordinates(c, -2, -2, 2, 2, &cell_array[2]);
      SumCoordinates(c, 2, -2, -2, 2, &cell_array[3]);
      SumCoordinates(c, 2, -2, 2, -2, &cell_array[4]);
      SumCoordinates(c, 2, 2, -2, -2, &cell_array[5]);
    }
    else if (IsFaceQ(c))
    {
      SumCoordinates(c, 2, -2, 2, -2, &cell_array[0]);
      SumCoordinates(c, -2, 2, 2, -2, &cell_array[1]);
      SumCoordinates(c, -2, -2, 2, 2, &cell_array[2]);
      SumCoordinates(c, -2, 2, -2, 2, &cell_array[3]);
      SumCoordinates(c, 2, -2, -2, 2, &cell_array[4]);
      SumCoordinates(c, 2, 2, -2, -2, &cell_array[5]);
    }
    else /* IsFaceP(c) */
    {
      SumCoordinates(c, -2, 2, 2, -2, &cell_array[0]);
      SumCoordinates(c, 2, -2, 2, -2, &cell_array[1]);
      SumCoordinates(c, -2, -2, 2, 2, &cell_array[2]);
      SumCoordinates(c, 2, -2, -2, 2, &cell_array[3]);
      SumCoordinates(c, -2, 2, -2, 2, &cell_array[4]);
      SumCoordinates(c, 2, 2, -2, -2, &cell_array[5]);
    }
    CHECK_ALL_FACES(cell_array, 6, "GetAdjacentHexFaces, result for hex-face");
    return 6;
  }
  else /* quad-face */
  {
    if (IsFaceZ(c))
    {
      SumCoordinates(c, 3, -1, -1, -1, &cell_array[0]);
      SumCoordinates(c, 1, 1, -3, 1, &cell_array[1]);
      SumCoordinates(c, -1, 3, -1, -1, &cell_array[2]);
      SumCoordinates(c, 1, 1, 1, -3, &cell_array[3]);
      SumCoordinates(c, 1, -3, 1, 1, &cell_array[4]);
      SumCoordinates(c, -1, -1, -1, 3, &cell_array[5]);
      SumCoordinates(c, -3, 1, 1, 1, &cell_array[6]);
      SumCoordinates(c, -1, -1, 3, -1, &cell_array[7]);
    }
    else if (IsFaceX(c))
    {
      SumCoordinates(c, 3, -1, -1, -1, &cell_array[0]);
      SumCoordinates(c, 1, -3, 1, 1, &cell_array[1]);
      SumCoordinates(c, -1, -1, 3, -1, &cell_array[2]);
      SumCoordinates(c, 1, 1, 1, -3, &cell_array[3]);
      SumCoordinates(c, 1, 1, -3, 1, &cell_array[4]);
      SumCoordinates(c, -1, -1, -1, 3, &cell_array[5]);
      SumCoordinates(c, -3, 1, 1, 1, &cell_array[6]);
      SumCoordinates(c, -1, 3, -1, -1, &cell_array[7]);

    }
    else /* IsFaceY(c) */
    {
      SumCoordinates(c, 3, -1, -1, -1, &cell_array[0]);
      SumCoordinates(c, 1, 1, -3, 1, &cell_array[1]);
      SumCoordinates(c, -1, -1, -1, 3, &cell_array[2]);
      SumCoordinates(c, 1, -3, 1, 1, &cell_array[3]);
      SumCoordinates(c, 1, 1, 1, -3, &cell_array[4]);
      SumCoordinates(c, -1, 3, -1, -1, &cell_array[5]);
      SumCoordinates(c, -3, 1, 1, 1, &cell_array[6]);
      SumCoordinates(c, -1, -1, 3, -1, &cell_array[7]);
    }
    CHECK_ALL_FACES(cell_array, 8, "GetAdjacentHexFaces, result for quad-face");
    return 8;
  }
}

int GetAdjacentQuadFaces(CellPtr c, CellPtr cell_array)
{
  CHECK(IsHexFace(c), "GetAdjacentQuadFaces, c is not hex-face\n");
  if (IsHexFace(c))
  {
    if (IsFaceS(c))
    {
      SumCoordinates(c, -3, 1, 1, 1, &cell_array[0]);
      SumCoordinates(c, -1, 3, -1, -1, &cell_array[1]);
      SumCoordinates(c, 1, 1, -3, 1, &cell_array[2]);
      SumCoordinates(c, 3, -1, -1, -1, &cell_array[3]);
      SumCoordinates(c, 1, -3, 1, 1, &cell_array[4]);
      SumCoordinates(c, -1, -1, 3, -1, &cell_array[5]);
    }
    else if (IsFaceR(c))
    { 
      SumCoordinates(c, -1, 3, -1, -1, &cell_array[0]);
      SumCoordinates(c, -3, 1, 1, 1, &cell_array[1]);
      SumCoordinates(c, -1, -1, -1, 3, &cell_array[2]);
      SumCoordinates(c, 1, -3, 1, 1, &cell_array[3]);
      SumCoordinates(c, 3, -1, -1, -1, &cell_array[4]);
      SumCoordinates(c, 1, 1, 1, -3, &cell_array[5]);
    }
    else if (IsFaceQ(c))
    { 
      SumCoordinates(c, 1, 1, 1, -3, &cell_array[0]);
      SumCoordinates(c, -1, -1, 3, -1, &cell_array[1]);
      SumCoordinates(c, -3, 1, 1, 1, &cell_array[2]);
      SumCoordinates(c, -1, -1, -1, 3, &cell_array[3]);
      SumCoordinates(c, 1, 1, -3, 1, &cell_array[4]);
      SumCoordinates(c, 3, -1, -1, -1, &cell_array[5]);
    }
    else /* IsFaceP(c) */
    {
      SumCoordinates(c, 1, 1, 1, -3, &cell_array[0]);
      SumCoordinates(c, -1, -1, 3, -1, &cell_array[1]);
      SumCoordinates(c, 1, -3, 1, 1, &cell_array[2]);
      SumCoordinates(c, -1, -1, -1, 3, &cell_array[3]);
      SumCoordinates(c, 1, 1, -3, 1, &cell_array[4]);
      SumCoordinates(c, -1, 3, -1, -1, &cell_array[5]);
    }
    CHECK_ALL_FACES(cell_array, 6, "GetAdjacentQuadFaces, result");
    return 6;
  }
  /* else: quad-face has no square adjacents */
  CHECK(1, "GetAdjacentQuadFaces, called for quad-face\n");
  return 0;
}

/* Face are sorted in such a way that, if they are 2k,
   faces in position i and i+k (for i=0..k-1) are adjacent
   to this face along the same edge; moreover faces
   in positions 0..k-1 and k..2k-1 are circular around thi face. */
int GetAdjacentFaces(CellPtr c, CellPtr cell_array)
{
  CHECK((IsHexFace(c)||IsQuadFace(c)), "GetAdjacentFaces, c is not face\n");
  if (IsHexFace(c))
  { 
    GetAdjacentHexFaces(c, cell_array); /* 6 faces */
    GetAdjacentQuadFaces(c, cell_array+6); /* 6 faces */
    return 12;
  }
  else /* IsQuadFace(c) */
  { 
    GetAdjacentHexFaces(c, cell_array); /* 8 faces */
    return 8;
  }
}

int GetFaceVertices(CellPtr c, CellPtr cell_array)
{
  CHECK((IsHexFace(c)||IsQuadFace(c)), "GetFaceVertices, c is not face\n");
  if (IsHexFace(c))
  {
    if (IsFaceS(c))
    { 
      SumCoordinates(c, -2,  2,  0, 0, &cell_array[0]);
      SumCoordinates(c,  0,  2, -2, 0, &cell_array[1]);
      SumCoordinates(c,  2,  0, -2, 0, &cell_array[2]);
      SumCoordinates(c,  2, -2,  0, 0, &cell_array[3]);
      SumCoordinates(c,  0, -2,  2, 0, &cell_array[4]);
      SumCoordinates(c, -2,  0,  2, 0, &cell_array[5]);
    }
    else if (IsFaceR(c))
    { 
      SumCoordinates(c, -2,  2, 0,  0, &cell_array[0]);
      SumCoordinates(c, -2,  0, 0,  2, &cell_array[1]);
      SumCoordinates(c,  0, -2, 0,  2, &cell_array[2]);
      SumCoordinates(c,  2, -2, 0,  0, &cell_array[3]);
      SumCoordinates(c,  2,  0, 0, -2, &cell_array[4]);
      SumCoordinates(c,  0,  2, 0, -2, &cell_array[5]);
    }
    else if (IsFaceQ(c))
    {
      SumCoordinates(c,  0, 0,  2, -2, &cell_array[0]);
      SumCoordinates(c, -2, 0,  2,  0, &cell_array[1]);
      SumCoordinates(c, -2, 0,  0,  2, &cell_array[2]);
      SumCoordinates(c,  0, 0, -2,  2, &cell_array[3]);
      SumCoordinates(c,  2, 0, -2,  0, &cell_array[4]);
      SumCoordinates(c,  2, 0,  0, -2, &cell_array[5]);
    }
    else /* IsFaceP(c) */
    {
      SumCoordinates(c, 0,  0,  2, -2, &cell_array[0]);
      SumCoordinates(c, 0, -2,  2,  0, &cell_array[1]);
      SumCoordinates(c, 0, -2,  0,  2, &cell_array[2]);
      SumCoordinates(c, 0,  0, -2,  2, &cell_array[3]);
      SumCoordinates(c, 0,  2, -2,  0, &cell_array[4]);
      SumCoordinates(c, 0,  2,  0, -2, &cell_array[5]);
    }
    return 6;
  }
  else /* quad-face */
  {
    if (IsFaceZ(c))
    {
      SumCoordinates(c,  1, -1, -1,  1, &cell_array[0]);
      SumCoordinates(c, -1,  1, -1,  1, &cell_array[1]);
      SumCoordinates(c, -1,  1,  1, -1, &cell_array[2]);
      SumCoordinates(c,  1, -1,  1, -1, &cell_array[3]);
    }
    else if (IsFaceX(c))
    {
      SumCoordinates(c,  1, -1, -1,  1, &cell_array[0]);
      SumCoordinates(c, -1, -1,  1,  1, &cell_array[1]);
      SumCoordinates(c, -1,  1,  1, -1, &cell_array[2]);
      SumCoordinates(c,  1,  1, -1, -1, &cell_array[3]);
    }
    else if (IsFaceY(c))
    {
      SumCoordinates(c,  1,  1, -1, -1, &cell_array[0]);
      SumCoordinates(c, -1,  1, -1,  1, &cell_array[1]);
      SumCoordinates(c, -1, -1,  1,  1, &cell_array[2]);
      SumCoordinates(c,  1, -1,  1, -1, &cell_array[3]);
    }
    return 4;
  }
}




/* Assume c1,c2 faces and mutually adjacent. Do not check. */
void GetCommonEdge (CellPtr c1, CellPtr c2, CellPtr edg)
{
  CHECK((IsHexFace(c1)||IsQuadFace(c1)), "GetCommonEdge, c1 is not face\n");
  CHECK((IsHexFace(c2)||IsQuadFace(c2)), "GetCommonEdge, c2 is not face\n");
  /* common edge of 2 faces. */
  if (IsHexFace(c1)&&IsHexFace(c2))
  {  P_COORD(edg) = (P_COORD(c1) + P_COORD(c2)) / 2;
     Q_COORD(edg) = (Q_COORD(c1) + Q_COORD(c2)) / 2;
     R_COORD(edg) = (R_COORD(c1) + R_COORD(c2)) / 2;
     S_COORD(edg) = (S_COORD(c1) + S_COORD(c2)) / 2;
  }
  else /* one quad and one hex, find the other hex */
  {
    struct CellStruct a[8];
    int i, m = -1;
    if (IsQuadFace(c1))
    {
       GetAdjacentHexFaces(c1, a);
       for (i=0; (i<4)&&(m==-1); i++)
       {
         if (AreSameCell(c2, &a[i])) m = i+4;
         else if (AreSameCell(c2, &a[i+4])) m = i; 
      }
      GetCommonEdge(c2,&a[m],edg);
    }
    else /* IsQuadFace(c2) */
    {
      GetAdjacentHexFaces(c2, a);
       for (i=0; (i<4)&&(m==-1); i++)
       {
         if (AreSameCell(c1, &a[i])) m = i+4;
         else if (AreSameCell(c1, &a[i+4])) m = i; 
      }
      GetCommonEdge(c1,&a[m],edg);
    }
  }
  CHECK(IsEdge(edg), "GetCommonEdge, result is not edge\n");
}

int AreAdjacentFaces(CellPtr c1, CellPtr c2)
{
  int p,q,r,s;
  int diff_p1, diff_m1;
  int diff_p2, diff_m2;
  int diff_p3, diff_m3;

  CHECK((IsHexFace(c1)||IsQuadFace(c1)), "AreAdjacentFaces, c1 is not face\n");
  CHECK((IsHexFace(c2)||IsQuadFace(c2)), "AreAdjacentFaces, c2 is not face\n");
  DiffCoordinates(c1, c2, &p, &q, &r, &s);
  /* case c1 and c2 are hex-faces:
  difference must have two +2 and two -2 */
  if (IsHexFace(c1)&&IsHexFace(c2))
  {
    diff_p2 = CountValues(p,q,r,s, 2);
    diff_m2 = CountValues(p,q,r,s, -2);
    return ((diff_p2==2) && (diff_m2==2));
  }
  /* case one of c1, c2 is hex-face and the other one is quad-face:
  difference must have three +1 and one -3, or three -1 and one +3 */
  diff_p1 = CountValues(p,q,r,s, 1);
  if (diff_p1==3)
  {
    diff_m3 = CountValues(p,q,r,s, -3);
    return (diff_m3==1);
  }
  diff_m1 = CountValues(p,q,r,s, -1);
  if (diff_m1==3)
  {
    diff_p3 = CountValues(p,q,r,s, 3);
    return (diff_p3==1);
  }
  /* other values in the difference: not adjacent */
  return 0;
}

/* ------------------------------------------------------------------------ */
/* Relations for an edge. */
/* ------------------------------------------------------------------------ */

int GetEdgeVoxels(CellPtr c, CellPtr cell_array)
{
  int val2_mod8; /* two coords are equal to this value mod 8*/
  CHECK(IsEdge(c), "GetEdgeVoxel, cell is not edge\n");

  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  if (BUCKET_ARRAY[0]==2) val2_mod8 = 0;
  else if (BUCKET_ARRAY[2]==2) val2_mod8 = 2;
  else if (BUCKET_ARRAY[4]==2) val2_mod8 = 4;
  else if (BUCKET_ARRAY[6]==2) val2_mod8 = 6;
  SortValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));

  CopyCoordFrom(&cell_array[0], c);
  CopyCoordFrom(&cell_array[1], c);
  CopyCoordFrom(&cell_array[2], c);
  switch (val2_mod8)
  {
    case 0: 
      /* odd edge, POSIT_ARRAY must correspond to mod = 0 0 2 6 */
      AddValuesToCoords(&cell_array[0], POSIT_ARRAY, 2,2,0,-4);
      AddValuesToCoords(&cell_array[1], POSIT_ARRAY, -2,-2,4,0);
      AddValuesToCoords(&cell_array[2], POSIT_ARRAY, 0,0,-2,2);
      break;
    case 2:
      /* even edge, POSIT_ARRAY must correspond to mod = 0 2 2 4 */
      AddValuesToCoords(&cell_array[0], POSIT_ARRAY, -4,2,2,0);
      AddValuesToCoords(&cell_array[1], POSIT_ARRAY, 0,-2,-2,4);
      AddValuesToCoords(&cell_array[2], POSIT_ARRAY, 2,0,0,-2);
      break;
    case 4:
      /* odd edge, POSIT_ARRAY must correspond to mod =  2 4 4 6 */
      AddValuesToCoords(&cell_array[0], POSIT_ARRAY, -4,2,2,0);
      AddValuesToCoords(&cell_array[1], POSIT_ARRAY, 0,-2,-2,4);
      AddValuesToCoords(&cell_array[2], POSIT_ARRAY, 2,0,0,-2);
      break;
   case 6:
      /* even edge, POSIT_ARRAY must correspond to mod = 0 4 6 6 */
      AddValuesToCoords(&cell_array[0], POSIT_ARRAY, 0,-4,2,2);
      AddValuesToCoords(&cell_array[1], POSIT_ARRAY, 4,0,-2,-2);
      AddValuesToCoords(&cell_array[2], POSIT_ARRAY, -2,2,0,0);
      break;
   }
  return 3;
}

int GetEdgeMainVoxel(CellPtr c, CellPtr adj)
{
  int val2_mod8; /* two coords are equal to this value mod 8*/
  CHECK(IsEdge(c), "GetEdgeVoxel, cell is not edge\n");

  CountValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  if (BUCKET_ARRAY[0]==2) val2_mod8 = 0;
  else if (BUCKET_ARRAY[2]==2) val2_mod8 = 2;
  else if (BUCKET_ARRAY[4]==2) val2_mod8 = 4;
  else if (BUCKET_ARRAY[6]==2) val2_mod8 = 6;
  SortValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));

  CopyCoordFrom(adj, c);
  switch (val2_mod8)
  {
    case 0:
      /* odd edge, POSIT_ARRAY must correspond to mod = 0 0 2 6 */
      /* add 0 0 -2 2 */
      AddValueToCoord(adj, POSIT_ARRAY[2], -2);
      AddValueToCoord(adj, POSIT_ARRAY[3], 2);
      break;
    case 2:
      /* even edge, POSIT_ARRAY must correspond to mod = 0 2 2 4 */
      /* add 2 0 0 -2 */
      AddValueToCoord(adj, POSIT_ARRAY[0], 2);
      AddValueToCoord(adj, POSIT_ARRAY[3], -2); 
      break;
    case 4:
      /* odd edge, POSIT_ARRAY must correspond to mod =  2 4 4 6 */
      /* add 2 0 0 -2 */
      AddValueToCoord(adj, POSIT_ARRAY[0], 2);
      AddValueToCoord(adj, POSIT_ARRAY[3], -2);
      break;
    case 6: /* even edge, POSIT_ARRAY must correspond to mod = 0 4 6 6 */
      /* add -2 2 0 0 */
      AddValueToCoord(adj, POSIT_ARRAY[0], -2);
      AddValueToCoord(adj, POSIT_ARRAY[1], 2); 
      break;
  }
  return 1;
}

int GetEdgeHexFaces(CellPtr c, CellPtr f1, CellPtr f2)
{
  CHECK(IsEdge(c), "GetEdgeHexFaces, c is not edge\n");
  /* add +1 (-1) to the two equal coordinates, 
     add -1 (+1) to the other two coordinates. */
  CopyCoordFrom(f1, c);
  CopyCoordFrom(f2, c);
  CountValuesMod8(P_COORD(c),Q_COORD(c),R_COORD(c),S_COORD(c));
  SortValuesMod8(P_COORD(c),Q_COORD(c),R_COORD(c),S_COORD(c));
  
  if (BUCKET_ARRAY[0]==2) 
  {
    /* odd edge, POSIT_ARRAY must correspond to mod = 0 0 2 6 */
    AddValuesToCoords(f1, POSIT_ARRAY, 1,1,  -1,-1);
    AddValuesToCoords(f2, POSIT_ARRAY, -1,-1,  1,1);
  }
  else if (BUCKET_ARRAY[2]==2) 
  {
    /* even edge, POSIT_ARRAY must correspond to mod = 0 2 2 4 */
    AddValuesToCoords(f1, POSIT_ARRAY, -1,  1,1,  -1);
    AddValuesToCoords(f2, POSIT_ARRAY, 1,  -1,-1,  1);
  }
  else if (BUCKET_ARRAY[4]==2) 
  {
    /* odd edge, POSIT_ARRAY must correspond to mod =  2 4 4 6 */
    AddValuesToCoords(f1, POSIT_ARRAY, -1,  1,1,  -1);
    AddValuesToCoords(f2, POSIT_ARRAY, 1,  -1,-1,  1);
  }
  else if (BUCKET_ARRAY[6]==2) 
  {
    /* even edge, POSIT_ARRAY must correspond to mod = 0 4 6 6 */
    AddValuesToCoords(f1, POSIT_ARRAY, -1,-1,  1,1);
    AddValuesToCoords(f2, POSIT_ARRAY, 1,1,  -1,-1);
  }
  CHECK(IsHexFace(f1), "GetEdgeHexFaces, result f1 is not hex-face\n");
  CHECK(IsHexFace(f2), "GetEdgeHexFaces, result f2 is not hex-face\n");
  return 2;
}

int GetEdgeQuadFace(CellPtr c, CellPtr f)
{
  /* even edge: leave the pair of equal coordinates unchanged; 
     If they are ==2, add +2 to the coord. ==4 and -2 to the coord. ==0.
     If they are ==6, add +2 to the coord. ==0 and -2 to the coord. ==4.
     odd edge:  leave the pair of equal coordinates unchanged;
     If they are ==0, add +2 to the coord. ==2 and -2 to the coord. ==6.
     If they are ==4, add +2 to the coord. ==6 and -2 to the coord. ==2.
  */
  CHECK(IsEdge(c), "GetEdgeQuadFace, c is not edge\n");
  CopyCoordFrom(f, c);
  CountValuesMod8(P_COORD(c),Q_COORD(c),R_COORD(c),S_COORD(c));
  SortValuesMod8(P_COORD(c),Q_COORD(c),R_COORD(c),S_COORD(c));
  if (BUCKET_ARRAY[0]==2) 
  {
    /* odd edge, POSIT_ARRAY must correspond to mod = 0 0 2 6 */
    AddValueToCoord(f, POSIT_ARRAY[2], 2);
    AddValueToCoord(f, POSIT_ARRAY[3],-2);
    
  }
  else if (BUCKET_ARRAY[2]==2) 
  {
    /* even edge, POSIT_ARRAY must correspond to mod = 0 2 2 4 */
    AddValueToCoord(f, POSIT_ARRAY[0],-2);
    AddValueToCoord(f, POSIT_ARRAY[3], 2);
  }
  else if (BUCKET_ARRAY[4]==2) 
  {
    /* odd edge, POSIT_ARRAY must correspond to mod =  2 4 4 6 */
    AddValueToCoord(f, POSIT_ARRAY[0],-2);
    AddValueToCoord(f, POSIT_ARRAY[3], 2);
  }
  else if (BUCKET_ARRAY[6]==2) 
  {
    /* even edge, POSIT_ARRAY must correspond to mod = 0 4 6 6 */
    AddValueToCoord(f, POSIT_ARRAY[0], 2);
    AddValueToCoord(f, POSIT_ARRAY[1],-2);
  }
  CHECK(IsQuadFace(f), "GetEdgeQuadFace, result f1 is not quad-face\n");
  return 1;
}


int GetEdgeVertices(CellPtr edg, CellPtr p1, CellPtr p2)
{
 /* add +1 and −1 to the two equal coordinates;
    if they were equal to
    0: add −1 to the coordinate =6 and +1 to the coordinate =2
    2: add −1 to the coordinate =0 and +1 to the coordinate =4
    4: add −1 to the coordinate =2 and +1 to the coordinate =6
    6: add −1 to the coordinate =4 and +1 to the coordinate =0
 */
  int val2_mod8; /* two coords are equal to this value mod 8*/
  CHECK(IsEdge(edg), "GetEdgeVertices, edg is not edge\n");

  CountValuesMod8(P_COORD(edg), Q_COORD(edg), R_COORD(edg), S_COORD(edg));
  if (BUCKET_ARRAY[0]==2) val2_mod8 = 0;
  else if (BUCKET_ARRAY[2]==2) val2_mod8 = 2;
  else if (BUCKET_ARRAY[4]==2) val2_mod8 = 4;
  else if (BUCKET_ARRAY[6]==2) val2_mod8 = 6;
  SortValuesMod8(P_COORD(edg), Q_COORD(edg), R_COORD(edg), S_COORD(edg));
  CopyCoordFrom(p1, edg);
  CopyCoordFrom(p2, edg);
  if (BUCKET_ARRAY[0]==2) 
  { /* odd edge, POSIT_ARRAY must correspond to mod = 0 0 2 6 */
    /* add 1 -1, 1 -1 and -1 1, 1 -1 */
    AddValuesToCoords(p1, POSIT_ARRAY,  1,-1, 1,-1);
    AddValuesToCoords(p2, POSIT_ARRAY, -1, 1, 1,-1);
  }
  else if (BUCKET_ARRAY[2]==2) 
  { /* even edge, POSIT_ARRAY must correspond to mod = 0 2 2 4 */
    /* add -1, 1 -1, 1 and -1, -1 1, 1 */
    AddValuesToCoords(p1, POSIT_ARRAY, -1,  1,-1,  1);
    AddValuesToCoords(p2, POSIT_ARRAY, -1, -1, 1, 1);
  }
  else if (BUCKET_ARRAY[4]==2) 
  { /* odd edge, POSIT_ARRAY must correspond to mod =  2 4 4 6 */
    /* add -1, 1 -1, 1 and -1, -1 1, 1 */
    AddValuesToCoords(p1, POSIT_ARRAY, -1,  1,-1, 1);
    AddValuesToCoords(p2, POSIT_ARRAY, -1, -1, 1, 1);
  }
  else /* BUCKET_ARRAY[6]==2 */
  { /* even edge, POSIT_ARRAY must correspond to mod = 0 4 6 6 */
    /* add 1 -1, 1 -1 and 1 -1, 1 -1 */
    AddValuesToCoords(p1, POSIT_ARRAY, 1,-1,  1,-1);
    AddValuesToCoords(p2, POSIT_ARRAY, 1,-1, -1, 1);
  }
  CHECK(IsVertex(p1), "GetEdgeVertices, result p1 is not vertex\n");
  CHECK(IsVertex(p2), "GetEdgeVertices, result p2 is not vertex\n");
  return 2;
}

int GetCommonVertex(CellPtr c1, CellPtr c2, CellPtr vrt)
{
  struct CellStruct p1, p2, p3, p4;
  GetEdgeVertices(c1, &p1, &p2);
  GetEdgeVertices(c2, &p3, &p4);
  if (AreSameCell(&p1,&p3) || AreSameCell(&p1,&p4)) 
     CopyCoordFrom(vrt, &p1);
  else if (AreSameCell(&p2,&p3) || AreSameCell(&p2,&p4))
     CopyCoordFrom(vrt, &p2);
  else return 0;
  return 1;
}

BOOLEAN AreAdjacentEdges(CellPtr c1, CellPtr c2)
{
  struct CellStruct p1, p2, p3, p4;
  GetEdgeVertices(c1, &p1, &p2);
  GetEdgeVertices(c2, &p3, &p4);
  if (AreSameCell(&p1,&p3) || AreSameCell(&p1,&p4)) return 1;
  if (AreSameCell(&p2,&p3) || AreSameCell(&p2,&p4)) return 1;
  return 0;
}


/* ------------------------------------------------------------------------ */
/* Relations for a vertex
/* ------------------------------------------------------------------------ */

int GetVertexVoxels(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVertex(c), "GetVertexVoxels, cell is not vertex\n");
  /*
  2 incident even voxels:
  add -1 and +1 (+3 and -3) to the two coordinates equal to 1 and 7; 
  add -3 and +3 (+1 and -1) to the two coordinates equal to 3 and 5.
  2 incident odd voxels:
  add +1 and -1 (-3 and +3) to the two coordinates equal to 1 and 3;
  add -3 and +3 (+1 and -1) to the two coordinates equal to 5 and 7.
  */
  SortValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  /* POSIT_ARRAY must correspond to mod = 1 3 5 7 */
  CopyCoordFrom(&cell_array[0], c);
  CopyCoordFrom(&cell_array[1], c);
  CopyCoordFrom(&cell_array[2], c);
  CopyCoordFrom(&cell_array[3], c);
  /* add -1 -3 3 1 */
  AddValueToCoord(&cell_array[0], POSIT_ARRAY[0], -1);
  AddValueToCoord(&cell_array[0], POSIT_ARRAY[1], -3);
  AddValueToCoord(&cell_array[0], POSIT_ARRAY[2], 3);
  AddValueToCoord(&cell_array[0], POSIT_ARRAY[3], 1);
  /* add 3 1 -1 -3 */
  AddValueToCoord(&cell_array[2], POSIT_ARRAY[0], 3);
  AddValueToCoord(&cell_array[2], POSIT_ARRAY[1], 1);
  AddValueToCoord(&cell_array[2], POSIT_ARRAY[2], -1);
  AddValueToCoord(&cell_array[2], POSIT_ARRAY[3], -3);
  /* add 1 -1 -3 3 */
  AddValueToCoord(&cell_array[3], POSIT_ARRAY[0], 1);
  AddValueToCoord(&cell_array[3], POSIT_ARRAY[1], -1);
  AddValueToCoord(&cell_array[3], POSIT_ARRAY[2], -3);
  AddValueToCoord(&cell_array[3], POSIT_ARRAY[3], 3);
  /* add -3 3 1 -1 */
  AddValueToCoord(&cell_array[1], POSIT_ARRAY[0], -3);
  AddValueToCoord(&cell_array[1], POSIT_ARRAY[1], 3);
  AddValueToCoord(&cell_array[1], POSIT_ARRAY[2], 1);
  AddValueToCoord(&cell_array[1], POSIT_ARRAY[3], -1);
  return 4;
}

int GetVertexFaces(CellPtr vert, CellPtr cell_array)
{
#ifdef CONTA
calledPF++;
#endif
/* 4 incident hexagonal faces:
    leave two vertex coordinates that are equal 
    to 1 and 5, or to 3 and 7 (mod 8),
    add 2 and -2 to the other two coordinates */
  /* 1 even square face: 
    add +1 to coordinates equal to 1 and 5;
    add -1 to the other two coordinates. */  
  /* 1 odd square face: 
    add -1 to coordinates equal to 1 and 5;
    add +1 to the other two coordinates. */
  CHECK(IsVertex(vert), "GetVertexFaces, vert is not vertex\n");
  SortValuesMod8(P_COORD(vert), Q_COORD(vert), R_COORD(vert), S_COORD(vert));

  CopyCoordFrom(&cell_array[0], vert);
  CopyCoordFrom(&cell_array[1], vert);
  CopyCoordFrom(&cell_array[2], vert);
  CopyCoordFrom(&cell_array[3], vert);
  CopyCoordFrom(&cell_array[4], vert);
  CopyCoordFrom(&cell_array[5], vert);

  AddValuesToCoords(&cell_array[0], POSIT_ARRAY, -0, 2, 0, -2);
  AddValuesToCoords(&cell_array[1], POSIT_ARRAY, 2, 0, -2, 0);
  AddValuesToCoords(&cell_array[2], POSIT_ARRAY, 0, -2, 0, 2);
  AddValuesToCoords(&cell_array[3], POSIT_ARRAY, -2, 0, 2, 0);
  AddValuesToCoords(&cell_array[4], POSIT_ARRAY, -1, 1, -1, 1);
  AddValuesToCoords(&cell_array[5], POSIT_ARRAY, 1, -1, 1, -1);
  CHECK_ALL_FACES(cell_array, 6, "GetVertexFaces, result");
  return 6;
}


int GetVertexEdges(CellPtr c, CellPtr cell_array)
{
  CHECK(IsVertex(c), "GetVertexEdges, cell is not vertex\n");
  /* Considering coordinates modulo 8, 
     2 incident even edges:
     add +1 (-1) to the ones ==1 and ==7; add -1 (+1) to the others.
     2 incident odd edges:
     add +1 (-1) to the ones ==1 and ==3; add -1 (+1) to the others. */
  SortValuesMod8(P_COORD(c), Q_COORD(c), R_COORD(c), S_COORD(c));
  /* POSIT_ARRAY must correspond to mod = 1 3 5 7 */
  CopyCoordFrom(&cell_array[0], c);
  CopyCoordFrom(&cell_array[1], c);
  CopyCoordFrom(&cell_array[2], c);
  CopyCoordFrom(&cell_array[3], c);
  /* even edge */
  AddValuesToCoords(&cell_array[3], POSIT_ARRAY, -1,1,1,-1);
  /* odd edge */
  AddValuesToCoords(&cell_array[2], POSIT_ARRAY, -1,-1,1,1);
  /* even edge */
  AddValuesToCoords(&cell_array[1], POSIT_ARRAY, 1,-1,-1,1);
  /* odd edge */
  AddValuesToCoords(&cell_array[0], POSIT_ARRAY, 1,1,-1,-1);
  return 4;
}

/* ------------------------------------------------------------------------ */
