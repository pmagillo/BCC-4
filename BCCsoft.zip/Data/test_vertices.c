/* test vertex-based relations */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "relations.h"

int main(int argc, char ** argv)
{
  int p,q,r,s;
  struct CellStruct inc_voxels[4]; /* 4 */
  struct CellStruct inc_faces[6]; /* 6 */
  struct CellStruct inc_edges[4]; /* 4 */
  struct CellStruct adj_verts[4];
  struct CellStruct aux[24];
  struct CellStruct v;
  int i,j, m;
  int error_occurred = 0;
  
  if (argc!=5)
  {
    printf("Need 4 coords p q r s of a vertex\n");
    return 0;
  }
  sscanf(argv[1],"%d",&p);
  sscanf(argv[2],"%d",&q);
  sscanf(argv[3],"%d",&r);
  sscanf(argv[4],"%d",&s);
  FillCoord(&v, p,q,r,s);
  
  if (!IsCell(&v))
  {
    printf("Given coordinates are not a cell\n");
    return 0;
  }
  if (!IsVertex(&v))
  {
    printf("Given coordinates are not a vertex\n");
    return 0;
  }
  
  fprintf(stderr, "Relations of vertex ");

  fprintf(stderr, "(%d,%d,%d,%d)", p,q,r,s);
/*  PrintCellPtr(&v);*/
  printf("\n");
  
  printf("Incid voxels:\n");
  error_occurred = 0;
  GetVertexVoxels(&v, inc_voxels);
  for (i=0; i<4; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_voxels[i]);
    GetVoxelVertices(&inc_voxels[i], aux);
    if (!IsAmongCells(&v, 24, aux))
    {  printf("ERR voxel has not this vertex\n");
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Incid faces:\n");
  GetVertexFaces(&v, inc_faces);
  for (i=0; i<6; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_faces[i]);
    m = GetFaceVertices(&inc_faces[i], aux);
    if (!IsAmongCells(&v, m, aux))
    {  printf("ERR face has not this vertex\n");
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Incid edges:\n");
  GetVertexEdges(&v, inc_edges);
  for (i=0; i<4; i++)
  {
    printf("%d)", i); PrintPlainCellPtr(&inc_edges[i]);
    q = GetEdgeVertices(&inc_edges[i], &aux[0], &aux[1]);
    if (!AreSameCell(&v, &aux[0])&&!AreSameCell(&v, &aux[1]))
    {  printf("ERR edge has not this vertex\n");
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of voxels and hex-faces:\n");
  for (i=0; i<4; i++)
  {
    int a,b; 
    /* hex-faces i and i+1 have voxels (i+2) */
    m = (i+2)%4;
    GetFaceVoxels(&inc_faces[i], &aux[0], &aux[1]);
    a = AreSameCell(&aux[0],&inc_voxels[m])||
        AreSameCell(&aux[1],&inc_voxels[m]);
    if (!a)
    {  printf("ERR hex-face %d has not voxel %d, it has\n", i, m);
       PrintPlainCellPtr(&aux[0]); printf(" and ");
       PrintPlainCellPtr(&aux[1]);
    }
    GetFaceVoxels(&inc_faces[(i+1)%4], &aux[0], &aux[1]);
    b = AreSameCell(&aux[0],&inc_voxels[m])||
        AreSameCell(&aux[1],&inc_voxels[m]);
    if (!b)
    {  printf("ERR hex-face %d has not voxel %d, it has\n", ((i+1)%4), m);
       PrintPlainCellPtr(&aux[0]); printf(" and ");
       PrintPlainCellPtr(&aux[1]);
    }
    error_occurred =!(a&&b);
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of voxels and quad-faces:\n");
  for (i=0; i<2; i++)
  {
    int a,b;
    /* quad-face i+4 has voxels i+1 and i+3 */
    GetFaceVoxels(&inc_faces[i+4], &aux[0], &aux[1]);
    a = AreSameCell(&aux[0],&inc_voxels[i+1])||
        AreSameCell(&aux[1],&inc_voxels[i+1]);
    if (!a)
    {  printf("ERR quad-face %d has not voxel %d, it has\n", (i+4), (i+1));
       PrintPlainCellPtr(&aux[0]); printf(" and ");
       PrintPlainCellPtr(&aux[1]);
    }
    GetFaceVoxels(&inc_faces[i+4], &aux[0], &aux[1]);
    b = AreSameCell(&aux[0],&inc_voxels[(i+3)%4])||
        AreSameCell(&aux[1],&inc_voxels[(i+3)%4]);
    if (!b)
    {  printf("ERR quad-face %d has not voxel %d, it has\n", (i+4), ((i+3)%4));
       PrintPlainCellPtr(&aux[0]); printf(" and ");
       PrintPlainCellPtr(&aux[1]);
    }
    error_occurred =!(a&&b);
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of voxels and edges:\n");
  for (i=0; i<4; i++)
  {
    /* edge i is on all voxels except i */
    m = GetEdgeVoxels(&inc_edges[i], aux);
    for (j=0; j<4; j++)
    {
      if (i!=j)
        if (!IsAmongCells(&inc_voxels[j], m, aux))
        {  printf("ERR edge %d is not on voxel %d\n", i,j);
           error_occurred = 1;
        }
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of hex- faces and edges:\n");
  for (i=0; i<4; i++)
  {
    /* hex-faces i and i+1 share edge i */
    GetCommonEdge(&inc_faces[i], &inc_faces[(i+1)%4], &aux[0]);
    if (!AreSameCell(&inc_edges[i],&aux[0])) 
    {  printf(" common edge of faces %d and %d is ", i, ((i+1)%4));
       PrintPlainCellPtr(&aux[0]);
       printf(" and it should be edge %d =", i);
       PrintPlainCellPtr(&inc_edges[i]);
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

  printf("Alignment of quad- faces and edges:\n");
  for (i=0; i<2; i++)
  {
    /* quad-face i+4 shares edges i and 2+i */
    GetFaceEdges(&inc_faces[i+4], aux);
    if (!(IsAmongCells(&inc_edges[i],4,aux)&&
          IsAmongCells(&inc_edges[2+i],4,aux)))
    {  printf("ERR quad-face %d has not edges %d and %d\n",(i+4),i, (2+i));
       error_occurred = 1;
    }
  }
  if (!error_occurred) printf("ok\n");
  error_occurred = 0;

}
