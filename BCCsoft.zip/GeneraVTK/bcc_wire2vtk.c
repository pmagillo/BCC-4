#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include "vtk_bcc.h"
#include "cells.h"
#include "relations.h"

/* Given a set of voxel coordinates in the system using 4 coordinates,
   write the set of arcs (segments) connecting their centers,
   in vtk format. */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

/* file containing the list of voxels */
char input_name[255] = "pippo.txt";
char out_name[255] = "the_arcs.vtk";

/* For associating a voxel with its name (=number in file) */
int *** odd_voxel_names = NULL, *** even_voxel_names = NULL;
int base_names = 0;

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

/* allocate names of voxels and set all zero */
void AllocNames(int min_c, int max_c)
{
  int i,j;
  int size_names = max_c-min_c+4;
  base_names = -min_c+1;
/*printf("min=%d, max=%d : ", min_c,max_c);  
printf("base = %d, size = %d\n", base_names, size_names);*/
  odd_voxel_names = (int ***) calloc(size_names, sizeof(int **));
  even_voxel_names = (int ***) calloc(size_names, sizeof(int **));
  for (i=0; i<size_names; i++)
  {
    odd_voxel_names[i] = (int **) calloc(size_names, sizeof(int *));
    even_voxel_names[i] = (int **) calloc(size_names, sizeof(int *));
    for (j=0; j<size_names; j++)
    {
      odd_voxel_names[i][j] = (int *) calloc(size_names, sizeof(int));
      even_voxel_names[i][j] = (int *) calloc(size_names, sizeof(int)); 
    }
  }
}

/* set and get voxel names */
void SetName(CellPtr c, int name)
{
  int x,y,z;
  VoxelCenterXYZ(c, &x, &y, &z);
/*printf("SetName c= ");PrintCellPtr(c); printf(" centro=%d,%d,%d\n",x,y,z);*/
  if (IsOddVoxel(c))
    odd_voxel_names[x+base_names][y+base_names][z+base_names] = name;
  else if (IsEvenVoxel(c))
    even_voxel_names[x+base_names][y+base_names][z+base_names] = name;
  else { fprintf(stderr, "ERR: Cell ");
         CellPtr(c); fprintf(stderr, " is not a voxel\n"); }
}
int GetName(CellPtr c)
{
  int x,y,z;
  VoxelCenterXYZ(c, &x, &y, &z);
/*printf("GetName c= ");PrintCellPtr(c); printf(" centro=%d,%d,%d\n",x,y,z);*/
  if (IsOddVoxel(c))
    return odd_voxel_names[x+base_names][y+base_names][z+base_names];
  else if (IsEvenVoxel(c))
    return even_voxel_names[x+base_names][y+base_names][z+base_names];
  else { fprintf(stderr, "ERR: Cell ");
         CellPtr(c); fprintf(stderr, " is not a voxel\n"); }
}

/* process ser parameters from command-line and update 
   default values of global variables as required */
void processUserData(int argc, char ** argv)
{
  /* The user can overwrite input file name */
    char name[255];
    float aux1;
    if (argc>1)
    {  strcpy(input_name, argv[1]);  }
  /* The user can overwrite shrink_factor only with a positive value
     smaller or equal to 1, otherwise user specification is ignored. */
    if (argc>2)
    {  if (sscanf(argv[2],"%f", &aux1)==1) 
       {
         if ((aux1>0)&&(aux1<=1)) shrink_factor = aux1;
       }
       else 
       {
         if (argc==3) strcpy(out_name, argv[2]); 
       }
    }
    if (argc>3)
    {  strcpy(out_name, argv[3]);  }
}

/* read input file and count voxels */
int countVoxelsFromFile(char * name, int *min_coord, int *max_coord)
{
  FILE * fd = fopen(name, "r");
  int p,q,r,s;
  int x,y,z;
  int count = 0;
  if (fd==NULL)
  {
      fprintf(stderr, "Cannot open input file %s\n", name);
      return 0;
  }
  while (fscanf(fd, "%d %d %d %d", &p, &q, &r, &s)==4)
  {
    count++;
    VoxelCenterXYZfromPQRS(p,q,r,s, &x, &y, &z);
    if (x>(*max_coord))   (*max_coord) = x; 
    if (y>(*max_coord))   (*max_coord) = y; 
    if (z>(*max_coord))   (*max_coord) = z; 
    if (x<(*min_coord))   (*min_coord) = x; 
    if (y<(*min_coord))   (*min_coord) = y; 
    if (z<(*min_coord))   (*min_coord) = z; 
  }
  fclose(fd);
  return count;
}

void writeVTK_Arc(FILE * fd, CellPtr c1, CellPtr c2)
{
  int p1 = GetName(c1);
  int p2 = GetName(c2);
/*printf("Status of the 2 voxels: %d %d\n", p1,p2);*/
  fprintf(fd, "2 %d %d\n", (p1-1), (p2-1));
}


int main(int argc, char ** argv)
{
  FILE * fd_in, *fd_out;
  int min_val = 0, max_val = 0;
  struct CellStruct aux;
  struct CellStruct a0,a1,a2,a3,a4,a5,a6,a7;
  CellPtr adjs[8] = {&a0,&a1,&a2,&a3,&a4,&a5,&a6,&a7};
  int num_voxels = 0;  
  int num_arcs = 0;
  int p,q,r,s;
  int x,y,z;
  int aux_count, i;
      
  /* user parameters from command-line */
  processUserData(argc,argv);

/**/fprintf(stderr, "Input file is %s\n", input_name);
/**/fprintf(stderr, "Shrink factor is %f\n", shrink_factor);
/**/fprintf(stderr, "Output file is %s\n", out_name);

  /* --------------- read input file 1st time: 
     --------------  count voxels, get min and max coordinate */
  num_voxels = countVoxelsFromFile(input_name, &min_val, &max_val);
  
  /* allocate mark table and set all empty*/
//  InitVoxelMarkArray(min_val-2,max_val+2);
  AllocNames(min_val,max_val);
  //InitMarkArrayXYZ(min_val,min_val,min_val, max_val,max_val,max_val);
  //ResetVoxelStatus();
  
  /* --------------- read input 2nd time:
     --------------- set the read voxels as full */
  fd_in = fopen(argv[1], "r");
  if (!fd_in)
  {  fprintf(stderr, "Cannot open input file\n"); return 0;  }  
  /* We mark full voxels with a number equal to the
     progressive number in the file, starting from 1 */
  aux_count = 0;
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4)
  {
    FillCoord(&aux, p,q,r,s);
    SetName(&aux, ++aux_count);
/*printf("For voxel "); PrintCellPtr(&aux);
printf("set status %d ", aux_count);
printf(", check = %d\n", GetName(&aux));*/
  }
  fclose(fd_in);
  
/**/fprintf(stderr, "Full Voxels are %d\n", num_voxels);

  /* --------------- open output file are write header */
  fd_out = fopen(out_name, "w");
/**/fprintf(stderr, "Write file %s\n", out_name);
  writeVTK_Header(fd_out);

  /* --------------- open input file 3rd time:
     --------------- write vertices, count arcs */
  fd_in = fopen(input_name, "r");
  fprintf(fd_out, "POINTS %d float\n", num_voxels);
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4) 
  {
    FillCoord(&aux, p,q,r,s);
    /* retrieve Cartesian coordinates of voxel center */    
    VoxelCenterXYZfromPQRS(p,q,r,s, &shift_x, &shift_y, &shift_z);
    /* Cartesian coordinates are now in shift_x, shift_y, shift_z */
    printShrinkedShiftedVertex(fd_out, 0,0,0);
    /* We have an arc for each pair of mutually adjacent full voxels.
       In order to count (and write) an arc only once, we consider 
       only adjacencies from a voxels to voxels in positive directions */
    Get6AdjacentVoxels(&aux, adjs);
    for (i=0; i<3; i++)
    {  if (GetName(adjs[i])>0) num_arcs++;  }
    Get8AdjacentVoxels(&aux, adjs);
    for (i=0; i<4; i++)
    {  if (GetName(adjs[i])>0) num_arcs++;  }
  }
  fclose(fd_in);

  /* --------------- read input 4th time:
  /* --------------- write arcs as segments */
  fd_in = fopen(input_name, "r");
  fprintf(fd_out, "\n\nCELLS %d %d\n\n", num_arcs, (3*num_arcs));
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4) 
  {
    FillCoord(&aux, p,q,r,s);
    Get6AdjacentVoxels(&aux, adjs);
    for (i=0; i<3; i++)
    {  if (GetName(adjs[i])>0) writeVTK_Arc(fd_out, &aux, adjs[i]);
    }
    Get8AdjacentVoxels(&aux, adjs);
    for (i=0; i<4; i++)
    {  if (GetName(adjs[i])>0) writeVTK_Arc(fd_out, &aux, adjs[i]);
    }
  }
  fclose(fd_in);
  
  /* cell types */  
  {
    int i;
    fprintf(fd_out, "\n\nCELL_TYPES %d\n", num_arcs);
    /* type = 3 (VTK_LINE) */
    for (i=0; i<num_arcs; i++) fprintf(fd_out, "3 ");
    fprintf(fd_out, "\n");
  }
  fclose(fd_out);
}
