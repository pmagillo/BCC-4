#include <stdio.h>
#include <string.h>
#include "vtk_cubic.h"

/* Auxiliary functions to support the generation of elements of a 
   cubic grid in vtk format. 
   See corresponding header file for comments. */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

float shrink_factor = 1.0;

int shift_x = 0, shift_y = 0, shift_z =0;

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

void printShrinkedShiftedVertex(FILE *fd, float x, float y, float z)
{
  fprintf(fd, "%f %f %f\n", x*shrink_factor+shift_x,
                            y*shrink_factor+shift_y,
                            z*shrink_factor+shift_z);
}

void printVoxelPoints(FILE *fd)
{
  /* Voxel centered in (0,0,0) is a cube with diagonal
     from (-1,-1,-1) to (1,1,1).
     Wite vertices in lexicographic order of their coordinates. */
   
   int i,j,k;
   for (i=-1; i<=1; i+=2)
   for (j=-1; j<=1; j+=2)
   for (k=-1; k<=1; k+=2)
      printShrinkedShiftedVertex(fd, i, j, k);
}

void printVoxelFaces(FILE *fd, int base)
{
    /* the vertices of the faces of this cubic voxel have been
       printed in the base-th call to printVoxelPoints,
       (see comments inside printVoxelPoints) */

    /* face on plane x=-1: */
    fprintf(fd, "4 %d %d %d %d\n", 
        8*base+0, 8*base+2, 8*base+3, 8*base+1);
    /* face on plane x=1; */
    fprintf(fd, "4 %d %d %d %d\n",
        8*base+4, 8*base+5, 8*base+7, 8*base+6);
        
    /* face on plane y=-1: */
    fprintf(fd, "4 %d %d %d %d\n", 
        8*base+0, 8*base+1, 8*base+5, 8*base+4);
    /* face on plane y=1; */
    fprintf(fd, "4 %d %d %d %d\n",
        8*base+2, 8*base+3, 8*base+7, 8*base+6);
        
    /* face on plane z=-1: */
    fprintf(fd, "4 %d %d %d %d\n", 
        8*base+0, 8*base+2, 8*base+6, 8*base+4);
    /* face on plane z=1; */
    fprintf(fd, "4 %d %d %d %d\n",
        8*base+1, 8*base+5, 8*base+7, 8*base+3);
}

void writeVTK_Header(FILE *fd)
{
  fprintf(fd, "# vtk DataFile Version 2.0\n\n");
  fprintf(fd, "ASCII\n");
  fprintf(fd, "DATASET UNSTRUCTURED_GRID\n\n");
}

void writeVTK_Faces(FILE *fd, int voxel_num)
{
  int i;
  for (i=0; i<voxel_num; i++)  printVoxelFaces(fd, i);
}

void writeVTK_cellTypes(FILE *fd, int num_voxels)
{
  int i;
  fprintf(fd, "\n\nCELL_TYPES %d\n", (6*num_voxels));
  /* faces, type = 9 (VTK_QUAD) */
  for (i=0; i<(6*num_voxels); i++) fprintf(fd, "9 ");
  fprintf(fd, "\n");
}

/* ----------------------------------------------------------------- */
