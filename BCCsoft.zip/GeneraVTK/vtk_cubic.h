#include <stdio.h>
#include <string.h>

/* Auxiliary functions to support the generation of elements of a 
   cubic grid in vtk format. */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

/* shrinking factor for voxels (it must be >=0 and <=1), with 
   default value (the user can overwrite it from command-line) */
extern float shrink_factor;

/* position of center of voxel to be printed (set by the algorithm 
   while iterating on voxels) */
extern int shift_x, shift_y, shift_z;

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

/* print vertex after first scaling by shrink_factor and then
   translating by offsets shift_x, int shift_y, int shift_z */
extern void printShrinkedShiftedVertex(FILE *fd, 
                                       float x, float y, float z);

/* print all vertices of voxel centered at (shift_x,shift_y,shift_z),
   sorted by faces (6 groups of 4 vertices each) */
extern void printVoxelPoints(FILE *fd);

/* print, in indexed version, the six faces of a cubic voxel
   whose vertices have been printed in the base-th call
   to printVoxelSquarePoints */
extern void printVoxelFaces(FILE *fd, int base);

/* wite header of VTK file */
extern void writeVTK_Header(FILE *fd);

/* cycle writing faces of voxel_num cubic voxels */
extern void writeVTK_Faces(FILE *fd, int voxel_num);

/* write VTK cell types for voxel_num voxels */
extern void writeVTK_cellTypes(FILE *fd, int num_voxels);

/* ----------------------------------------------------------------- */
