#include <stdio.h>
#include <string.h>

/* Auxiliary functions to support the generation of elements of a 
   BCC grid in vtk format. */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

/* shrinking factor for voxels (it must be >=0 and <=1), with 
   default value (the user can overwrite it from command-line) */
extern float shrink_factor;

/* The value of level must be > 0 and < 1.
If level = 0.5 (default) we draw even and odd voxels with same shape.
If level >0.5 the square facets of even voxels are bigger and those
of odd voxels are smaller, if level <0.5 vice versa.
The limit value level=1 means that odd voxels are diamond-like
pyramids (square facets collapsed and exagonal facets degenerated
to triangles). For limit value level=0, the opposite happens. */
extern float level;

/* position of center of voxel to be printed (set by the algorithm 
   while iterating on voxels) */
extern int shift_x, shift_y, shift_z;

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

/* print vertex after first scaling by shrink_factor and then
   translating by offsets shift_x, int shift_y, int shift_z */
extern void printShrinkedShiftedVertex(FILE *fd, 
                                       float x, float y, float z);

/* print all vertices of voxel centered at (shift_x,shift_y,shift_z),
   sorted by square faces (6 groups of 4 vertices each) */
extern void printVoxelSquarePoints(FILE *fd, int is_even);

/* print, in indexed version, the six square faces of a voxel
   whose vertices have been printed in the base-th call
   to printVoxelSquarePoints */
extern void printVoxelSquareFaces(FILE *fd, int base);

/* print hex-face with given indices, plus base */
extern void printHexFace(FILE *fd, int base, 
                         int a, int b, int c, int d, int e, int f);

/* print, in indexed version, the eight hex-faces of a voxel
   whose vertices have been printed in the base-th call
   to printVoxelSquarePoints */
extern void printVoxelHexFaces(FILE *fd, int base);

/* wite header of VTK file */
extern void writeVTK_Header(FILE *fd);

/* cycle writing quad-faces of voxel_num voxels */
extern void writeVTK_quadFaces(FILE *fd, int voxel_num);

/* cycle writing hex-faces of voxel_num voxels */
extern void writeVTK_hexFaces(FILE *fd, int voxel_num);

/* write VTK cell types for voxel_num voxels, assuming that first
   all quad-faces have been written, and later all hex-faces */
extern void writeVTK_cellTypes(FILE *fd, int num_voxels);

/* ----------------------------------------------------------------- */
