#include <stdio.h>
#include <string.h>
#include "vtk_bcc.h"

/* Auxiliary functions to support the generation of elements of a 
   BCC grid in vtk format. 
   See corresponding header file for comments. */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

float shrink_factor = 1.0;

float level = 0.5; /* default = 0.5 */

int shift_x = 0, shift_y = 0, shift_z =0;

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

void printShrinkedShiftedVertex(FILE *fd, float x, float y, float z)
{
  fprintf(fd, "%f %f %f\n", x*shrink_factor+shift_x,
                            y*shrink_factor+shift_y,
                            z*shrink_factor+shift_z);
}

void printVoxelSquarePoints(FILE *fd, int is_even)
{
    /* Voxel centered in (0,0,0) is inscribed into a cube with diagonal
       from (-1,-1,-1) to (1,1,1). The quad face of the voxel contained
       in a face of the cube has one fixed coordinate (=-1 or =1) while
       the other two assume values (-0.5,0) (0,0.5) (0.5,0) (0,-0.5) */

    float t = ((is_even) ? level : (1.0-level));
    int ff;
    for (ff=-1; ff<=1; ff+=2)
    {
      /* these points get index BASE+{0..3} for ff=0 and
         BASE+12+{0..3} for ff=1 in the list */
      printShrinkedShiftedVertex(fd, ff,  -t,  0);
      printShrinkedShiftedVertex(fd, ff,   0  , -t*ff);
      printShrinkedShiftedVertex(fd, ff,   t,  0);
      printShrinkedShiftedVertex(fd, ff,   0  ,  t*ff);
      /* these points get index BASE+{4..7} for ff=0 and
         BASE+12+{4..7} for ff=1 in the list */
      printShrinkedShiftedVertex(fd, -t, ff,  0);
      printShrinkedShiftedVertex(fd,  0  , ff,  t*ff);
      printShrinkedShiftedVertex(fd,  t, ff,  0);
      printShrinkedShiftedVertex(fd,  0  , ff, -t*ff);
      /* these points get index BASE+{8..11} for ff=0 and
         BASE+12+{8..11} for ff=1 in the list */
      printShrinkedShiftedVertex(fd, -t,  0  ,    ff);
      printShrinkedShiftedVertex(fd,  0  , -t*ff, ff);
      printShrinkedShiftedVertex(fd,  t,  0  ,    ff);
      printShrinkedShiftedVertex(fd,  0  ,  t*ff, ff);
    }
}

void printVoxelSquareFaces(FILE *fd, int base)
{
    /* the vertices of the square faces of this voxel have been
       printed in the base-th call to printVoxelSquarePoints,
       (see comments inside printVoxelSquarePoints) */

    int ff, vv;
    for (ff=0; ff<6; ff++)
    {
      fprintf(fd, "4 "); /* number of vertices */
      for (vv=0; vv<4; vv++)    
      {
         fprintf(fd, "%d ",24*base+ 4*ff+vv); /* face vertex */
      }
      fprintf(fd, "\n"); /* end of face */
    }
}

void printHexFace(FILE *fd, int base, 
                  int a, int b, int c, int d, int e, int f)
{
  fprintf(fd, "6 "); /* number of vertices */
  fprintf(fd, "%d %d %d %d %d %d\n",
          24*base+a,24*base+b,24*base+c,
          24*base+d,24*base+e,24*base+f);
}

void printVoxelHexFaces(FILE *fd, int base)
{
    /* the vertices of the square faces of this voxel have been
       printed in the base-th call to printVoxelSquarePoints,
       (see comments inside printVoxelSquarePoints) */

    /* face corresponding to cube vertex (-1,-1,-1) */ 
    printHexFace(fd, base, 0,3,8,11,5,4);
    /* face corresponding to cube vertex (-1,1,-1) */
    printHexFace(fd, base, 3,2,16,19,9,8);
    /* face corresponding to cube vertex (-1,-1,1) */
    printHexFace(fd, base, 21,20,1,0,4,7);
    /* face corresponding to cube vertex (-1,1,1) */
    printHexFace(fd, base, 2,1,20,23,17,16);

    /* face corresponding to cube vertex (1,-1,-1) */
    printHexFace(fd, base, 13,12,6,5,11,10);
    /* face corresponding to cube vertex (1,-1,1) */
    printHexFace(fd, base, 12,15,22,21,7,6);	
    /* face corresponding to cube vertex (1,1,-1) */
    printHexFace(fd, base, 10,9,19,18,14,13);
    /* face corresponding to cube vertex (1,1,1) */
    printHexFace(fd, base, 18,17,23,22,15,14);
}

void writeVTK_Header(FILE *fd)
{
  fprintf(fd, "# vtk DataFile Version 2.0\n\n");
  fprintf(fd, "ASCII\n");
  fprintf(fd, "DATASET UNSTRUCTURED_GRID\n\n");
}

void writeVTK_quadFaces(FILE *fd, int voxel_num)
{
  int i;
  for (i=0; i<voxel_num; i++)  printVoxelSquareFaces(fd, i);
}

void writeVTK_hexFaces(FILE *fd, int voxel_num)
{
  int i;
  for (i=0; i<voxel_num; i++)  printVoxelHexFaces(fd, i);
}

void writeVTK_cellTypes(FILE *fd, int num_voxels)
{
  int i;
  fprintf(fd, "\n\nCELL_TYPES %d\n", (14*num_voxels));
  /* first quad-faces, type = 9 (VTK_QUAD) */
  for (i=0; i<(6*num_voxels); i++) fprintf(fd, "9 ");
  fprintf(fd, "\n");
  /* then hex-faces, type = 7 (VTK_POLYGON) */
  for (i=0; i<(8*num_voxels); i++) fprintf(fd, "7 ");
  fprintf(fd, "\n");
}

/* ----------------------------------------------------------------- */
