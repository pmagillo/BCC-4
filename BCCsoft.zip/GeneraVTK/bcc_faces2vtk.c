#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include "vtk_bcc.h"
#include "cells.h"
#include "relations.h"

/* Given a set of face coordinates in the system using 4 coordinates,
   write these faces in vtk format. */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

/* file containing the list of faces */
char input_name[255] = "pippo.txt";
char out_quad_name[255] = "faces_4.vtk";
char out_hex_name[255] = "faces_6.vtk";

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

/* process ser parameters from command-line and update 
   default values of global variables as required */
void processUserData(int argc, char ** argv)
{
  /* The user can overwrite input file name */
    char name[255];
    float aux1;
    if (argc>1)
    {  strcpy(input_name, argv[1]);  }
  /* The user can overwrite shrink_factor only with a positive value
     smaller or equal to 1, otherwise user specification is ignored. */
    if (argc>2)
    {  if (sscanf(argv[2],"%f", &aux1)==1) 
       {
         if ((aux1>0)&&(aux1<=1)) shrink_factor = aux1;
       }
       else 
       {
         if (argc==5)
         {  strcpy(out_quad_name, argv[2]); 
            strcpy(out_hex_name, argv[3]);
         }
       }
    }
    if (argc>4)
    {  strcpy(out_quad_name, argv[3]);
       strcpy(out_hex_name, argv[4]);
    }
}

/* ---------------------- GENERAL PROCEDURE ------------------------ */

/*
Each face is written separately, with its 4 or 6 vertices as separate
points in the VTK file.

Get face type (functions IsHexFace, IsEvenQuadFace, IsOddQuadFace).
Get the two incident voxels (function GetFaceVoxels).
Get the centers of the two voxels.

If the face is a quad-face:
The two voxel centers have two equal coordinates aamong x,y,z and one
different coordinate.
The plane of the face is perpendicular to the axis of the different 
coordinate.
Given a voxel center and a Cartesian direction (+X,-X,+Y,-Y,+z,-Z),
write the quad-face of the voxel lying in that direction.

If the face is a hex-face:
The 4D coordinates of the two voxels have exactly one coordinate 
(among p,q,r,s) which differs by 6. 
Find such coordinate and the sign of the difference.
Given a voxel center and an octahedral direction,
write the hex-face of the voxel lying in that direction.
*/

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

/* Print the vertices of the quad-face lying in the given Cartesian 
   direction of the voxel whose center is stored in global variables
   (shift_x,shift_y,shift_z).
   dir_name = one of 'x','y','z', sign = one of -1,1 */
void print_voxel_quad_in_dir(char dir_name, int dir_sign, FILE * fd)
{
  switch(dir_name)
  {
    case 'x':
    if (dir_sign==1) /* POS_X */
    {
      printShrinkedShiftedVertex(fd, 1,  -0.5,  0);
      printShrinkedShiftedVertex(fd, 1,   0  , -0.5);
      printShrinkedShiftedVertex(fd, 1,   0.5,  0);
      printShrinkedShiftedVertex(fd, 1,   0  ,  0.5);
    }
    else /* NEG_X */
    {
      printShrinkedShiftedVertex(fd, -1,  -0.5,  0);
      printShrinkedShiftedVertex(fd, -1,   0  ,  0.5);
      printShrinkedShiftedVertex(fd, -1,   0.5,  0);
      printShrinkedShiftedVertex(fd, -1,   0  , -0.5);
    }
    break;
    case 'y': 
    if (dir_sign==1) /* POS_Y */
    {
      printShrinkedShiftedVertex(fd, -0.5, 1,  0);
      printShrinkedShiftedVertex(fd,  0  , 1,  0.5);
      printShrinkedShiftedVertex(fd,  0.5, 1,  0);
      printShrinkedShiftedVertex(fd,  0  , 1, -0.5);
    }
    else /* NEG_Y */
    {
      printShrinkedShiftedVertex(fd, -0.5, -1,  0);
      printShrinkedShiftedVertex(fd,  0  , -1, -0.5);
      printShrinkedShiftedVertex(fd,  0.5, -1,  0);
      printShrinkedShiftedVertex(fd,  0  , -1,  0.5);
    }
    break;
    case 'z':
    if (dir_sign==1) /* POS_Z */
    { 
      printShrinkedShiftedVertex(fd, -0.5,  0  , 1);
      printShrinkedShiftedVertex(fd,  0  , -0.5, 1);
      printShrinkedShiftedVertex(fd,  0.5,  0  , 1);
      printShrinkedShiftedVertex(fd,  0  ,  0.5, 1);
    }
    else /* NEG_Z */
    { 
      printShrinkedShiftedVertex(fd, -0.5,  0  , -1);
      printShrinkedShiftedVertex(fd,  0  ,  0.5, -1);
      printShrinkedShiftedVertex(fd,  0.5,  0  , -1);
      printShrinkedShiftedVertex(fd,  0  , -0.5, -1);
    }
    break;
  }
}

/* To be called in situation where either IsEvenQuadFace(&fac) or
   IsOddQuadFace(&fac) is true.
   Print the vertices of the given face. */
void processQuadFace(CellPtr fac, FILE * out_fd)
{
  struct CellStruct adj_vox[2];
  int vox_cx[2], vox_cy[2], vox_cz[2];
  char dir_name;
  int dir_sign;
  int i;
  
  /* centers of incident voxels */
  GetFaceVoxels(fac, &adj_vox[0], &adj_vox[1]);
  for (i=0; i<2; i++)
  {
    VoxelCenterXYZ(&adj_vox[i], &vox_cx[i], &vox_cy[i], &vox_cz[i]);
  }

  {/* check: exactly one coordinate among (x,y,z) must be different
      in the centers of the two voxels */
   int count = 0;
   if (vox_cx[1]==vox_cx[0]) count++;
   if (vox_cy[1]==vox_cy[0]) count++;
   if (vox_cz[1]==vox_cz[0]) count++;
   if (count!=2)
   { fprintf(stderr,"Errore, XYZ coordinate uguali non sono due:\n");
     fprintf(stderr,"  (%d,%d,%d) and (%d,%d,%d)\n",
       vox_cx[0],vox_cy[0],vox_cz[0], vox_cx[1],vox_cy[1],vox_cz[1]);        
   }
  /*end of check*/}    
  
  /* the different coordinate, and sign of the difference */
  if (vox_cx[1]!=vox_cx[0])
  {
    dir_name = 'x'; 
    dir_sign = (vox_cx[1]>vox_cx[0]) ? 1 : -1;
  }
  else if (vox_cy[1]!=vox_cy[0])
  {
    dir_name = 'y';
    dir_sign = (vox_cy[1]>vox_cy[0]) ? 1 : -1;
  }
  else if (vox_cz[1]!=vox_cz[0])
  {
    dir_name = 'z';
    dir_sign = (vox_cz[1]>vox_cz[0]) ? 1 : -1;
  }

  /* write */
  shift_x = vox_cx[0];
  shift_y = vox_cy[0];
  shift_z = vox_cz[0];
  print_voxel_quad_in_dir(dir_name, dir_sign, out_fd);
}

/* Print the vertices of the hex-face lying in the given octahedral
   direction of the voxel whose center is stored in global variables
   (shift_x,shift_y,shift_z).
   dir_name = one of 'p','q','r','s', sign = one of -1,1 */
void print_voxel_hex_in_dir(char dir_name, int dir_sign, FILE * fd)
{
  switch(dir_name)
  {
    case 'p':
    if (dir_sign==1) /* POS_P */
    {
    /* face corresponding to direction +P = (-1,1,1) */
      printShrinkedShiftedVertex(fd, -1,   0.5,  0);    // 2
      printShrinkedShiftedVertex(fd, -1,   0  , 0.5);  // 1
      printShrinkedShiftedVertex(fd, -0.5,  0  ,    1);  // 20
      printShrinkedShiftedVertex(fd,  0  ,  0.5, 1); // 23
      printShrinkedShiftedVertex(fd,  0  , 1,  0.5); // 17
      printShrinkedShiftedVertex(fd, -0.5, 1,  0);  // 16
    }
    else /* NEG_P */
    {
    /* face corresponding to direction -P = (1,-1,-1) */
      printShrinkedShiftedVertex(fd, 1,   0  , -0.5);// 13
      printShrinkedShiftedVertex(fd, 1,  -0.5,  0); // 12
      printShrinkedShiftedVertex(fd,  0.5, -1,  0); // 6
      printShrinkedShiftedVertex(fd,  0  , -1,  -0.5); // 5
      printShrinkedShiftedVertex(fd,  0  ,  -0.5, -1); // 11
      printShrinkedShiftedVertex(fd,  0.5,  0  ,    -1); // 10
    }
    break;
    case 'q':
    if (dir_sign==1) /* POS_Q */
    {
    /* face corresponding to direction +Q = (1,-1,1) */
      printShrinkedShiftedVertex(fd, 1,  -0.5,  0); // 12
      printShrinkedShiftedVertex(fd, 1,   0  ,  0.5);  // 15
      printShrinkedShiftedVertex(fd,  0.5,  0  ,    1);  // 22 
      printShrinkedShiftedVertex(fd,  0  , -0.5, 1); // 21
      printShrinkedShiftedVertex(fd,  0  , -1, 0.5); // 7 
      printShrinkedShiftedVertex(fd,  0.5, -1,  0); // 6
    }
    else /* NEG_Q */
    {
    /* face corresponding to direction -Q = (-1,1,-1) */
      printShrinkedShiftedVertex(fd, -1,   0  ,  -0.5); // 3
      printShrinkedShiftedVertex(fd, -1,   0.5,  0);  // 2
      printShrinkedShiftedVertex(fd, -0.5, 1,  0);// 16 
      printShrinkedShiftedVertex(fd,  0  , 1, -0.5); // 19
      printShrinkedShiftedVertex(fd,  0  , 0.5, -1); // 9
      printShrinkedShiftedVertex(fd, -0.5,  0  ,    -1); // 8
    }
    break;
    case 'r':
    if (dir_sign==1) /*_POS_R */
    {
    /* face corresponding to direction +R = (-1,-1,-1) */ 
      printShrinkedShiftedVertex(fd, -1  , -0.5,  0);   // 0
      printShrinkedShiftedVertex(fd, -1,   0  ,  -0.5); // 3
      printShrinkedShiftedVertex(fd, -0.5,  0  ,    -1); // 8
      printShrinkedShiftedVertex(fd,  0  ,  -0.5, -1);        // 11
      printShrinkedShiftedVertex(fd,  0  , -1,  -0.5);       // 5
      printShrinkedShiftedVertex(fd, -0.5, -1,  0);   // 4
    }
    else /* NEG_R  */
    {
    /* face corresponding to direction -R = (1,1,1) */
      printShrinkedShiftedVertex(fd,  0.5, 1,  0); // 18
      printShrinkedShiftedVertex(fd,  0  , 1,  0.5); // 17
      printShrinkedShiftedVertex(fd,  0  ,  0.5, 1);  // 23
      printShrinkedShiftedVertex(fd,  0.5,  0  ,    1); // 22 
      printShrinkedShiftedVertex(fd, 1,   0  ,  0.5); // 15
      printShrinkedShiftedVertex(fd, 1,   0.5,  0); // 14
    }
    case 's':
    if (dir_sign==1) /*_POS_s */
    {
    /* face corresponding to direction +S = (1,1,-1) */
      printShrinkedShiftedVertex(fd,  0.5,  0  ,    -1); // 10
      printShrinkedShiftedVertex(fd,  0  , 0.5, -1);  // 9 
      printShrinkedShiftedVertex(fd,  0  , 1, -0.5); // 19
      printShrinkedShiftedVertex(fd,  0.5, 1,  0);  // 18
      printShrinkedShiftedVertex(fd, 1,   0.5,  0); // 14
      printShrinkedShiftedVertex(fd, 1,   0  , -0.5); // 13
    }
    else /* NEG_S */
    {
    /* face corresponding to direction -S = (-1,-1,1) */
      printShrinkedShiftedVertex(fd,  0  , -0.5, 1); // 21
      printShrinkedShiftedVertex(fd, -0.5,  0  ,    1); // 20 
      printShrinkedShiftedVertex(fd, -1,   0  , 0.5);// 1
      printShrinkedShiftedVertex(fd, -1,  -0.5,  0); // 0
      printShrinkedShiftedVertex(fd, -0.5, -1,  0); // 4
      printShrinkedShiftedVertex(fd,  0  , -1, 0.5);  // 7
    }
    break;
  }
}

/* To be called in situation where IsHexFace(&fac) is true.
   Print the vertices of the given face. */
void processHexFace(CellPtr fac, FILE * out_fd)
{
  struct CellStruct adj_vox1;
  struct CellStruct adj_vox2;
  char dir_name;
  int dir_sign;

  /* incident voxels */
  GetFaceVoxels(fac, &adj_vox1, &adj_vox2);

  {/* check: exactly one coordinate among (p,q,r,s) must differ by 6
      in the two voxels */
   int count = 0;
   if (P_COORD(&adj_vox2)-P_COORD(&adj_vox1)==6) count++;
   if (P_COORD(&adj_vox2)-P_COORD(&adj_vox1)==-6) count++;
   if (Q_COORD(&adj_vox2)-Q_COORD(&adj_vox1)==6) count++;
   if (Q_COORD(&adj_vox2)-Q_COORD(&adj_vox1)==-6) count++;
   if (R_COORD(&adj_vox2)-R_COORD(&adj_vox1)==6) count++;
   if (R_COORD(&adj_vox2)-R_COORD(&adj_vox1)==-6) count++;
   if (S_COORD(&adj_vox2)-S_COORD(&adj_vox1)==6) count++;
   if (S_COORD(&adj_vox2)-S_COORD(&adj_vox1)==-6) count++;
   if (count!=1)
   { fprintf(stderr,"Errore, PQRS coordinate che diff 6 non e una:\n");
     fprintf(stderr,"  (%d,%d,%d,%d) and (%d,%d,%d,%d)\n",
       P_COORD(&adj_vox1),Q_COORD(&adj_vox1),R_COORD(&adj_vox1),S_COORD(&adj_vox1),
       P_COORD(&adj_vox2),Q_COORD(&adj_vox2),R_COORD(&adj_vox2),S_COORD(&adj_vox2));
   }
  /*end of check*/}    

  /* the coordinate which differs by 6, and sign of the difference */
  if (P_COORD(&adj_vox2)-P_COORD(&adj_vox1) == 6)
  { dir_name = 'p'; dir_sign = 1; }
  else if (P_COORD(&adj_vox2)-P_COORD(&adj_vox1) == -6)
  { dir_name = 'p'; dir_sign = -1; }
  else if (Q_COORD(&adj_vox2)-Q_COORD(&adj_vox1) == 6)
  { dir_name = 'q'; dir_sign = 1; }
  else if (Q_COORD(&adj_vox2)-Q_COORD(&adj_vox1) == -6)
  { dir_name = 'q'; dir_sign = -1; }
  else if (R_COORD(&adj_vox2)-R_COORD(&adj_vox1) == 6)
  { dir_name = 'r'; dir_sign = 1; }
  else if (R_COORD(&adj_vox2)-R_COORD(&adj_vox1) == -6)
  { dir_name = 'r'; dir_sign = -1; }
  else if (S_COORD(&adj_vox2)-S_COORD(&adj_vox1) == 6)
  { dir_name = 's'; dir_sign = 1; }
  else if (S_COORD(&adj_vox2)-S_COORD(&adj_vox1) == -6)
  { dir_name = 's'; dir_sign = -1; }

  /* write */
  VoxelCenterXYZ(&adj_vox1, &shift_x, &shift_y, &shift_z);
  /* now (shift_x, shift_y, shift_z) is center of adj_vox1 */
  print_voxel_hex_in_dir(dir_name, dir_sign, out_fd);
}
  
/* read input file and count quad or hex faces */
int countFacesFromFile(char * name, int quad_or_hex)
{
  FILE * fd = fopen(name, "r");
  int p,q,r,s;
  struct CellStruct fac;
  int count = 0;
  if (fd==NULL)
  {
      fprintf(stderr, "Cannot open input file %s\n", name);
      return 0;
  }
  while (fscanf(fd, "%d %d %d %d", &p, &q, &r, &s)==4)
  {
    FillCoord(&fac, p,q,r,s);
    switch (quad_or_hex)
    {
      case 4:
        if (IsEvenQuadFace(&fac)||IsOddQuadFace(&fac)) count++;
        break;
      case 6:
        if (IsHexFace(&fac)) count++;
        break;
    }
  }
  fclose(fd);
  return count;
}

int main(int argc, char ** argv)
{
  FILE * fd_in, *fd_out;
  int num_quad, num_hex;
  int p,q,r,s;
  struct CellStruct fac;
  int x,y,z;
  int count, i;
  
  /* user parameters from command-line */
  processUserData(argc,argv);

/**/fprintf(stderr, "Input file is %s\n", input_name);
/**/fprintf(stderr, "Shrink factor is %f\n", shrink_factor);
/**/fprintf(stderr, "Output files are %s and %s\n", out_quad_name, out_hex_name);

  /* --------------- read input file first time */
  num_quad = countFacesFromFile(input_name, 4);
  num_hex = countFacesFromFile(input_name, 6);

  if ((num_quad==0)&&(num_hex==0))  
  {
    fprintf(stderr, "No faces, nothing to do\n");
    return 1;
  }
  
  /* Each quad_face has 4 vertices */
/**/fprintf(stderr, "Quad faces are %d (vertices are %d)\n", 
           num_quad, (num_quad*4));
  
  /* Each hex_face has 6 vertices */
/**/fprintf(stderr, "Hex faces are %d (vertices are %d)\n",
           num_hex, (num_hex*6));
  
  /* --------------- write file containing quad faces */

  fd_out = fopen(out_quad_name, "w");
/**/fprintf(stderr, "Write quad file %s\n", out_quad_name);
  writeVTK_Header(fd_out);

  /* points (coordinates of vertices) */
  fd_in = fopen(input_name, "r");
  fprintf(fd_out, "POINTS %d float\n", 4*num_quad);
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4)
  {
    FillCoord(&fac, p,q,r,s);
    if (IsEvenQuadFace(&fac)||IsOddQuadFace(&fac))
       processQuadFace(&fac, fd_out); /* vertices */
  }
  fclose(fd_in);
  
  /* cells (four vertex indexes for each face) */
  fd_in = fopen(input_name, "r");
  count = 0;
  fprintf(fd_out, "\n\nCELLS %d %d\n\n", num_quad, (5*num_quad));
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4)
  {
    FillCoord(&fac, p,q,r,s);
    if (IsEvenQuadFace(&fac)||IsOddQuadFace(&fac))
    {
      fprintf(fd_out, "4 %d %d %d %d\n",
          count*4, count*4+1, count*4+2, count*4+3);
      count++;
    }
  }
  fclose(fd_in);

  /* cell types (all quads) */
  fprintf(fd_out, "\n\nCELL_TYPES %d\n", num_quad);
  for (i=0; i<num_quad; i++) fprintf(fd_out, "9 ");
  fprintf(fd_out, "\n");
  fclose(fd_out);
  
  /* --------------- write file containing hex faces */

  fd_out = fopen(out_hex_name, "w");
/**/fprintf(stderr, "Write hex file %s\n", out_hex_name);
  writeVTK_Header(fd_out);

  /* points (coordinates of vertices) */
  fd_in = fopen(input_name, "r");
  fprintf(fd_out, "POINTS %d float\n", 6*num_hex);
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4)
  {
    FillCoord(&fac, p,q,r,s);
    if (IsHexFace(&fac)) processHexFace(&fac, fd_out); /* vertices */
  }
  fclose(fd_in);
  
  /* cells (six vertex indexes for each face) */
  fd_in = fopen(input_name, "r");
  count = 0;
  fprintf(fd_out, "\n\nCELLS %d %d\n\n", num_hex, (7*num_hex));
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4)
  {
    FillCoord(&fac, p,q,r,s);
    if (IsHexFace(&fac))
    {
      fprintf(fd_out, "6 %d %d %d %d %d %d\n",
          count*6, count*6+1, count*6+2, count*6+3, count*6+4, count*6+5);
      count++;
    }
  }
  fclose(fd_in);

  /* cell types (all polygons) */
  fprintf(fd_out, "\n\nCELL_TYPES %d\n", num_hex);
  for (i=0; i<num_hex; i++) fprintf(fd_out, "7 ");
  fprintf(fd_out, "\n");
  fclose(fd_out);

}
