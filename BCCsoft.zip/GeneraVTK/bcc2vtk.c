#include <stdio.h>
#include <string.h>
#include "vtk_bcc.h"
#include "cells.h"

/* Given a set of voxel coordinates in the system using 4 coordinates,
   write their faces in vtk format. */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

/* file containing the list of voxels */
char input_name[255] = "pippo.txt";
char out_name[255] = "the_voxels.vtk";

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

/* process ser parameters from command-line and update 
   default values of global variables as required */
void processUserData(int argc, char ** argv)
{
  /* The user can overwrite input file name */
    char name[255];
    float aux1;
    if (argc>1)
    {  strcpy(input_name, argv[1]);  }
  /* The user can overwrite shrink_factor only with a positive value
     smaller or equal to 1, otherwise user specification is ignored. */
    if (argc>2)
    {  if (sscanf(argv[2],"%f", &aux1)==1) 
       {
         if ((aux1>0)&&(aux1<=1)) shrink_factor = aux1;
       }
       else 
       {
         if (argc==3) strcpy(out_name, argv[2]); 
       }
    }
    if (argc>3)
    {  strcpy(out_name, argv[3]);  }
}

/* read input file and count voxels */
int countVoxelsFromFile(char * name)
{
  FILE * fd = fopen(name, "r");
  int p,q,r,s;
  int count = 0;
  if (fd==NULL)
  {
      fprintf(stderr, "Cannot open input file %s\n", name);
      return 0;
  }
  while (fscanf(fd, "%d %d %d %d", &p, &q, &r, &s)==4) count++;
  fclose(fd);
  return count;
}

int main(int argc, char ** argv)
{
  FILE * fd_in, *fd_out;
  int num_voxels = 0;
  int p,q,r,s;
  int x,y,z;
    
  /* user parameters from command-line */
  processUserData(argc,argv);

/**/fprintf(stderr, "Input file is %s\n", input_name);
/**/fprintf(stderr, "Shrink factor is %f\n", shrink_factor);
/**/fprintf(stderr, "Output file is %s\n", out_name);

  /* --------------- read input file first time */
  num_voxels = countVoxelsFromFile(input_name);
  
  if (num_voxels==0)
  {
    fprintf(stderr, "no voxel, nothing to do\n");
    return 1;
  }
  
  /* Each voxel has 14 faces (6 quad-faces and 8 hex-faces) */
/**/fprintf(stderr, "Voxels have %d faces (%d quad and %d hex)\n", 
           (num_voxels*14), (num_voxels*6), (num_voxels*8));
  
  /* Each voxel has 24 vertices, i.e., 
     the vertices of its square faces */
/**/fprintf(stderr, "Voxels have %d vertices\n", (num_voxels*24));

  /* --------------- open output file are write header */
  fd_out = fopen(out_name, "w");
/**/fprintf(stderr, "Write file %s\n", out_name);
  writeVTK_Header(fd_out);

  /* --------------- open input file second time, write vertices */
  fd_in = fopen(input_name, "r");

  fprintf(fd_out, "POINTS %d float\n", 24*num_voxels);
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4) 
  {
    /* retrieve Cartesian coordinates of voxel center */    
    VoxelCenterXYZfromPQRS(p,q,r,s, &shift_x, &shift_y, &shift_z);
    /* Cartesian coordinates are now in shift_x, shift_y, shift_z */
    printVoxelSquarePoints(fd_out, IsEvenVoxelPQRS(p,q,r,s));
  }
  fclose(fd_in);
  
  /* --------------- write faces */
  
    /* each voxel has 6 quad-faces and 8 hex-faces,
       each quad-face is represented by 5 numbers ("4"+vertex list),
       each hex-face is represented by 7 numbers ("6"+vertex list) */

    /* number of faces */
    fprintf(fd_out, "\n\nCELLS %d %d\n\n",
            (6*num_voxels)+(8*num_voxels),
            (30*num_voxels)+(56*num_voxels));
    
    /* quad-faces */
    writeVTK_quadFaces(fd_out, num_voxels);
    /* hex-faces  */
    writeVTK_hexFaces(fd_out, num_voxels);
        
    /* cell types */
    writeVTK_cellTypes(fd_out, num_voxels);

  fclose(fd_out);
}
