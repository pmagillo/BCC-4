#include <stdio.h>
#include <string.h>
#include "vtk_mod.h"

/* Auxiliary functions to support the generation of elements of a 
   BCC grid in vtk format. 
   See corresponding header file for comments.
   MODIFIED!!! */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

float shrink_factor = 1.0;

#ifndef LEVEL 
float level = 0.25; /* default = 0.25 */
#else
float level = LEVEL;
#endif

int shift_x = 0, shift_y = 0, shift_z =0;

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

void printShrinkedShiftedVertex(FILE *fd, float x, float y, float z)
{
  fprintf(fd, "%f %f %f\n", x*shrink_factor+shift_x,
                            y*shrink_factor+shift_y,
                            z*shrink_factor+shift_z);
}

/* --------------------- EVEN VOXELS --------------------------------*/

void printEvenVoxelPoints(FILE *fd)
{
    /* Voxel centered in (0,0,0) is inscribed into a cube with diagonal
       from (-1,-1,-1) to (1,1,1). There are 8 triangular faces at the
       8 cube vertices and 6 octagonal faces at the 6 cuve faces. */

    float t = level;
      /* vertices of triangular face around vertex (-1,-1,-1) */
      /* these points get index BASE+{0,1,2} */
      printShrinkedShiftedVertex(fd, -1.0,   -1.0+t, -1.0);
      printShrinkedShiftedVertex(fd, -1.0+t, -1.0,   -1.0);
      printShrinkedShiftedVertex(fd, -1.0,   -1.0,   -1.0+t);
      /* vertices of triangular face around vertex (-1,-1,1) */
      /* these points get index BASE+{3,4,5} */
      printShrinkedShiftedVertex(fd, -1.0+t, -1.0,   1.0);
      printShrinkedShiftedVertex(fd, -1.0,   -1.0+t, 1.0);
      printShrinkedShiftedVertex(fd, -1.0,   -1.0,   1.0-t);
      /* vertices of triangular face around vertex (-1,1,-1) */
      /* these points get index BASE+{6,7,8} */
      printShrinkedShiftedVertex(fd, -1.0,   1.0-t, -1.0);
      printShrinkedShiftedVertex(fd, -1.0+t, 1.0,   -1.0);
      printShrinkedShiftedVertex(fd, -1.0,   1.0,   -1.0+t);
      /* vertices of triangular face around vertex (-1,1,1) */
      /* these points get index BASE+{9,10,11} */
      printShrinkedShiftedVertex(fd, -1.0+t, 1.0,   1.0);
      printShrinkedShiftedVertex(fd, -1.0,   1.0-t, 1.0);
      printShrinkedShiftedVertex(fd, -1.0,   1.0,   1.0-t);
      /* vertices of triangular face around vertex (1,-1,-1) */
      /* these points get index BASE+{12,13,14} */
      printShrinkedShiftedVertex(fd, 1.0-t, -1.0,   -1.0);
      printShrinkedShiftedVertex(fd, 1.0,   -1.0+t, -1.0);
      printShrinkedShiftedVertex(fd, 1.0,   -1.0,   -1.0+t);
      /* vertices of triangular face around vertex (1,-1,1) */
      /* these points get index BASE+{15,16,17} */
      printShrinkedShiftedVertex(fd, 1.0,   -1.0+t, 1.0);
      printShrinkedShiftedVertex(fd, 1.0-t, -1.0,   1.0);
      printShrinkedShiftedVertex(fd, 1.0,   -1.0,   1.0-t);
      /* vertices of triangular face around vertex (1,1,-1) */
      /* these points get index BASE+{18,19,20} */
      printShrinkedShiftedVertex(fd, 1.0,   1.0-t, -1.0);
      printShrinkedShiftedVertex(fd, 1.0-t, 1.0,   -1.0);
      printShrinkedShiftedVertex(fd, 1.0,   1.0,   -1.0+t);
      /* vertices of triangular face around vertex (1,1,1) */
      /* these points get index BASE+{21,22,23} */
      printShrinkedShiftedVertex(fd, 1.0-t, 1.0,   1.0);
      printShrinkedShiftedVertex(fd, 1.0,   1.0-t, 1.0);
      printShrinkedShiftedVertex(fd, 1.0,   1.0,   1.0-t);
}

void printEvenVoxelTriFaces(FILE *fd, int base)
{
    /* the vertices of the 8 tri-faces of this voxel have been
       printed in the base-th call to printEvenVoxelPoints */

    int ff, vv;
    for (ff=0; ff<8; ff++)
    {
      fprintf(fd, "3 "); /* number of vertices */
      for (vv=0; vv<3; vv++)    
      {
         fprintf(fd, "%d ",24*base+ 3*ff+vv); /* face vertex */
      }
      fprintf(fd, "\n"); /* end of face */
    }
}

void printOctFace(FILE *fd, int base, 
                  int a, int b, int c, int d, int e, int f, int g, int h)
{
  fprintf(fd, "8 "); /* number of vertices */
  fprintf(fd, "%d %d %d %d %d %d %d %d\n",
          24*base+a,24*base+b,24*base+c,24*base+d,
          24*base+e,24*base+f,24*base+g,24*base+h);
}

void printEvenVoxelOctFaces(FILE *fd, int base)
{
    /* the vertices of the 6 oct-faces of this voxel have been
       printed in the base-th call to printEvenVoxelPoints */

    /* positive y */
    printOctFace(fd, base, 7,8, 11,9, 21,23, 20,19);
    /* positive z */
    printOctFace(fd, base, 9,10, 4,3, 16,15, 22,21);
    /* positive x */
    printOctFace(fd, base, 23,22, 15,17, 14,13, 18,20);
    /* negative x */
    printOctFace(fd, base, 10,11, 8,6, 0,2, 5,4);
    /* negative z */
    printOctFace(fd, base, 6,7, 19,18, 13,12, 1,0);
    /* negative y */
    printOctFace(fd, base, 2,1, 12,14, 17,16, 3,5);
}


/* -------------------- ODD VOXELS --------------------------------- */

void printOddVoxelPoints(FILE *fd)
{
    /* Voxel centered in (0,0,0) is inscribed into a cube with diagonal
       from (-1,-1,-1) to (1,1,1). There are 8 triangular faces around
       the center, vertices are 6 in pos/neg dir of Cartesian axes. */

    float t = level;
      /* negative and positive x, these points get index BASE+{0,1} */
      printShrinkedShiftedVertex(fd, -t,   0.0, 0.0);
      printShrinkedShiftedVertex(fd,  t,   0.0, 0.0);
      /* negative and positive y, these points get index BASE+{2,3} */
      printShrinkedShiftedVertex(fd, 0.0,  -t,   0.0);
      printShrinkedShiftedVertex(fd, 0.0,   t, 0.0);
      /* negative and positive z, these points get index BASE+{4,5} */
      printShrinkedShiftedVertex(fd, 0.0,  0.0, -t);
      printShrinkedShiftedVertex(fd, 0.0,  0.0,  t);
}

void printTriFace(FILE *fd, int base_even, int base, 
                  int a, int b, int c)
{
  fprintf(fd, "3 "); /* number of vertices */
  fprintf(fd, "%d %d %d\n",
          24*base_even+6*base+a,
          24*base_even+6*base+b,
          24*base_even+6*base+c);
}

void printOddVoxelTriFaces(FILE *fd, int base_even, int base)
{
    /* the vertices of the triangular faces of this voxel have been
       printed in the base-th call to printEvenVoxelPoints */

    printTriFace(fd, base_even, base, 0,5,3);
    printTriFace(fd, base_even, base, 0,3,4);
    printTriFace(fd, base_even, base, 0,4,2);
    printTriFace(fd, base_even, base, 0,2,5);
    printTriFace(fd, base_even, base, 1,4,3);
    printTriFace(fd, base_even, base, 1,3,5);
    printTriFace(fd, base_even, base, 1,5,2);
    printTriFace(fd, base_even, base, 1,2,4);
}

/* --------------------- ALL ------------------------------------ */

void writeVTK_Header(FILE *fd)
{
  fprintf(fd, "# vtk DataFile Version 2.0\n\n");
  fprintf(fd, "ASCII\n");
  fprintf(fd, "DATASET UNSTRUCTURED_GRID\n\n");
}

void writeVTK_EvenVoxelOctFaces(FILE *fd, int even_voxel_num)
{
  int i;
  for (i=0; i<even_voxel_num; i++)  printEvenVoxelOctFaces(fd, i);
}

void writeVTK_EvenVoxelTriFaces(FILE *fd, int even_voxel_num)
{
  int i;
  for (i=0; i<even_voxel_num; i++)  printEvenVoxelTriFaces(fd, i);
}

void writeVTK_OddVoxelTriFaces(FILE *fd,
     int even_voxel_num, int odd_voxel_num)
{
  int i;
  for (i=0; i<odd_voxel_num; i++)
    printOddVoxelTriFaces(fd, even_voxel_num, i);
}

void writeVTK_cellTypes(FILE *fd, int num_even, int num_odd)
{
  /* Each even voxel has 8 triangular faces and 6 octagonal faces
  (tot= 14 faces), and each odd voxel has 8 triangular faces. */
  
  int i;
  fprintf(fd, "\n\nCELL_TYPES %d\n", ((14*num_even)+(8*num_odd)));
  /* first tri-faces of even voxels, type = 5 (VTK_TRIANGLE) */
  for (i=0; i<(8*num_even); i++) fprintf(fd, "5 ");
  fprintf(fd, "\n");
  /* then oct-faces of even voxels, type = 7 (VTK_POLYGON) */
  for (i=0; i<(6*num_even); i++) fprintf(fd, "7 ");
  fprintf(fd, "\n");
  /* then tri-faces of odd voxels, type = 5 (VTK_TRIANGLE) */
  for (i=0; i<(8*num_odd); i++) fprintf(fd, "5 ");
  fprintf(fd, "\n");
}

/* ----------------------------------------------------------------- */
