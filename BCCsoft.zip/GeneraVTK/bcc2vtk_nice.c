#include <stdio.h>
#include <string.h>
#include "vtk_mod.h"
#include "cells.h"

/* Given a set of voxel coordinates in the system using 4 coordinates,
   write their faces in vtk format.
   MODIFIED in order to write faces of different size!!!! */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

/* file containing the list of voxels */
char input_name[255] = "pippo.txt";
char out_name[255] = "the_voxels.vtk";

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

/* process ser parameters from command-line and update 
   default values of global variables as required */
void processUserData(int argc, char ** argv)
{
  /* The user can overwrite input file name */
    char name[255];
    float aux1;
    if (argc>1)
    {  strcpy(input_name, argv[1]);  }
  /* The user can overwrite shrink_factor only with a positive value
     smaller or equal to 1, otherwise user specification is ignored. */
    if (argc>2)
   {  if (sscanf(argv[2],"%f", &aux1)==1) 
       {
         if ((aux1>0)&&(aux1<=1)) shrink_factor = aux1;
       }
       else 
       {
         if (argc==3) strcpy(out_name, argv[2]); 
       }
    }
    if (argc>3)
    {  strcpy(out_name, argv[3]);  }
}

/* read input file and count voxels */
int countVoxelsFromFile(char * name, int *odd_n, int *even_n)
{
  FILE * fd = fopen(name, "r");
  int p,q,r,s;
  int count = 0;
  struct CellStruct aux;
  if (fd==NULL)
  {
      fprintf(stderr, "Cannot open input file %s\n", name);
      return 0;
  }
  while (fscanf(fd, "%d %d %d %d", &p, &q, &r, &s)==4)
  { 
   count++;
   FillCoord(&aux, p,q,r,s);
   if (IsOddVoxel(&aux)) (*odd_n)++;
   else if (IsEvenVoxel(&aux)) (*even_n)++;
  }
  fclose(fd);
  if (count != ((*odd_n)+(*even_n)))
    fprintf(stderr, "Not all given cells are voxels!\n");
  return count;
}

int main(int argc, char ** argv)
{
  FILE * fd_in, *fd_out;
  int num_voxels = 0, num_odd = 0, num_even = 0;
  int p,q,r,s;
  int x,y,z;
    
  /* user parameters from command-line */
  processUserData(argc,argv);

/**/fprintf(stderr, "Input file is %s\n", input_name);
/**/fprintf(stderr, "Shrink factor is %f\n", shrink_factor);
/**/fprintf(stderr, "Output file is %s\n", out_name);

  /* --------------- read input file first time */
  num_voxels = countVoxelsFromFile(input_name, &num_odd, &num_even);

  if (num_voxels==0)
  {
    fprintf(stderr, "no voxel, nothing to do\n");
    return 1;
  }
  
/**/fprintf(stderr, "Even Voxels: %d, have %d faces (%d oct and %d tri)\n", 
           num_even,  (num_even*14), (num_even*6), (num_even*8));

/**/fprintf(stderr, "Odd Voxels: %d, have %d faces (tri)\n", 
           num_odd, (num_odd*8));

  /* Each even voxel has 24 vertices, each odd voxel has 6 vertices */
/**/fprintf(stderr, "Even Voxels have %d vertices\n", (num_even*24));
/**/fprintf(stderr, "Odd Voxels have %d vertices\n", (num_odd*6));

  /* --------------- open output file are write header */
  fd_out = fopen(out_name, "w");
/**/fprintf(stderr, "Write file %s\n", out_name);
  writeVTK_Header(fd_out);

  /* --------------- open input file again, write vertices */

  fprintf(fd_out, "POINTS %d float\n", ((24*num_even) + (6*num_odd)));
  /* even */
  fd_in = fopen(input_name, "r");
  while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4) 
  {
    struct CellStruct aux;
    FillCoord(&aux, p,q,r,s);
    if (IsEvenVoxel(&aux))
    {
    /* retrieve Cartesian coordinates of voxel center */    
    VoxelCenterXYZfromPQRS(p,q,r,s, &shift_x, &shift_y, &shift_z);
    /* Cartesian coordinates are now in shift_x, shift_y, shift_z */
    printEvenVoxelPoints(fd_out);
    }
  }
  fclose(fd_in);
  /* odd */
  fd_in = fopen(input_name, "r");
while (fscanf(fd_in, "%d %d %d %d", &p, &q, &r, &s)==4) 
  {
    struct CellStruct aux;
    FillCoord(&aux, p,q,r,s);
    if (IsOddVoxel(&aux))
    {
    /* retrieve Cartesian coordinates of voxel center */    
    VoxelCenterXYZfromPQRS(p,q,r,s, &shift_x, &shift_y, &shift_z);
    /* Cartesian coordinates are now in shift_x, shift_y, shift_z */
    printOddVoxelPoints(fd_out);
    }
  }
  fclose(fd_in);
  
  /* --------------- write faces */
  
    /* tri faces of even voxels are num_even * 8,
       oct faces of even voxels are num_even * 6,
       tri faces of odd voxels are num_odd * 8,
       each tri-face is represented by 4 numbers ("3"+vertex list),
       each oct-face is represented by 9 numbers ("8"+vertex list) */

    /* number of faces */
    fprintf(fd_out, "\n\nCELLS %d %d\n\n",
            (8*num_voxels)+(6*num_even),
            (32*num_voxels)+(54*num_even));
    
    /* first tri-faces of even voxels */
    writeVTK_EvenVoxelTriFaces(fd_out, num_even);
    /* then oct-faces of even voxels */
    writeVTK_EvenVoxelOctFaces(fd_out, num_even);
    /* then tri-faces of odd voxels */
    writeVTK_OddVoxelTriFaces(fd_out, num_even, num_odd);
        
    /* cell types */
    writeVTK_cellTypes(fd_out, num_even, num_odd);

  fclose(fd_out);
}
