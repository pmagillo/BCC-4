#include <stdio.h>
#include <string.h>

/* Auxiliary functions to support the generation of elements of a 
   BCC grid in vtk format. */

/* ----------------------- GLOBAL VARIABLES ------------------------ */

/* shrinking factor for voxels (it must be >=0 and <=1), with 
   default value (the user can overwrite it from command-line) */
extern float shrink_factor;

/* we draw even voxels as cubes of edge-length=2, and cut at each
vertex at a distance = level from vertex, and odd voxels at diamond-like 
pyramids centered at vertices, with edge = 2*level. 
The value of level must be > 0 (even voxels are drawn as entire cubes and 
odd voxels degenerate to points ) and < 1 (even and odd voxels both drawn
as diamond-like pyramids of same size. Default value = 0.25 */
extern float level;

/* position of center of voxel to be printed (set by the algorithm 
   while iterating on voxels) */
extern int shift_x, shift_y, shift_z;

/* --------------------- AUXILIARY FUNCTIONS ----------------------- */

/* print vertex after first scaling by shrink_factor and then
   translating by offsets shift_x, int shift_y, int shift_z */
extern void printShrinkedShiftedVertex(FILE *fd, 
                                       float x, float y, float z);

/* print all vertices of even voxel centered at (shift_x,shift_y,shift_z),
   sorted by triangular faces (8 groups of 3 vertices each) */
extern void printEvenVoxelPoints(FILE *fd);

/* print, in indexed version, the 8 triangular faces of an even voxel
   whose vertices have been printed in the base-th call
   to printEvenVoxelPoints */
extern void printEvenVoxelTriFaces(FILE *fd, int base);

/* print octagonal-face with given indices, plus base */
extern void printOctFace(FILE *fd, int base, 
                   int a, int b, int c, int d, int e, int f, int g, int h);

/* print, in indexed version, the 6 octagonal-faces of an even voxel
   whose vertices have been printed in the base-th call
   to printEvenVoxelPoints */
extern void printEvenVoxelOctFaces(FILE *fd, int base);

/* print all vertices of odd voxel centered at (shift_x,shift_y,shift_z) */
extern void printOddVoxelPoints(FILE *fd);

/* print triangular-face of odd voxel with given indices, plus base */
extern void printTriFace(FILE *fd, int base_even, int base, int a, int b, int c);

/* print, in indexed version, the 8 triangular-faces of an odd voxel
   whose vertices have been printed in the base-th call 
   to printOddVoxelPoints */
extern void printOddVoxelTriFaces(FILE *fd, int base_even, int base);

/* wite header of VTK file */
extern void writeVTK_Header(FILE *fd);

/* cycle writing octagonal-faces of a number of even voxels */
extern void writeVTK_EvenVoxelOctFaces(FILE *fd, int even_voxel_num);

/* cycle writing triangular-faces of a number of even voxels */
extern void writeVTK_EvenVoxelTriFaces(FILE *fd, int even_voxel_num);

/* cycle writing triangular-faces of a number of odd voxels */
extern void writeVTK_OddVoxelTriFaces(FILE *fd,
     int even_voxel_num,  int odd_voxel_num);

/* write VTK cell types for voxel_num voxels, assuming that first
   all quad-faces have been written, and later all hex-faces */
extern void writeVTK_cellTypes(FILE *fd, int num_even, int num_odd);

/* ----------------------------------------------------------------- */
