#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "relations.h"
#include "filling.h"

/* See comments in header file */

/* fill only the even voxel corresponding to the cube */
int fillEvenFromCube(int x, int y, int z)
{
  struct CellStruct c;
  voxelFromCube(&c, x,y,z);
  // fill c (even voxel)
  if (GetVoxelStatus(&c)==0)
  {  SetVoxelStatus(&c, 1); return 1; }
  return 0;
}

/* even voxel already filled, fill the necessary odd ones */
int fillOddFromCube(int x, int y, int z)
{
  struct CellStruct c;
  struct CellStruct adjs[8];
  int i, count = 0;
  voxelFromCube(&c, x,y,z);
  // fill the 8-adjacent voxels of c (odd voxels)
  Get8AdjacentVoxels(&c,adjs);
  for (i=0; i<8; i++)
  {
    if (GetVoxelStatus(&adjs[i])==0)
      if (MustBeFilled(&adjs[i]))
      {  SetVoxelStatus(&adjs[i], 1); count++; }
  }
  return count;
}


int writeBCCfromCube(int x, int y, int z, FILE * fd_out)
{
  struct CellStruct c;
  struct CellStruct adjs[8];
  int i, count = 0;
  voxelFromCube(&c, x,y,z);
  // write and empty c
  if (GetVoxelStatus(&c)!=0)
  {
     fprintf(fd_out, "%d %d %d %d\n",
             P_COORD(&c), Q_COORD(&c), R_COORD(&c), S_COORD(&c));
     SetVoxelStatus(&c, 0);
     count++;
  }
  // write and empty 8-adjacent voxels
  Get8AdjacentVoxels(&c,adjs);
  for (i=0; i<8; i++)
  {
     if (GetVoxelStatus(&adjs[i])!=0)
     {
        fprintf(fd_out, "%d %d %d %d\n",
                P_COORD(&adjs[i]), Q_COORD(&adjs[i]), 
                R_COORD(&adjs[i]), S_COORD(&adjs[i]));
        SetVoxelStatus(&adjs[i], 0);
        count++;
     }
  }
  return count;
}

int fillBCC(char * input_name, int *num)
{
  FILE * fd = fopen(input_name, "r");
  int x,y,z, n = 0;
  (*num) = 0;
  if (fd==NULL)
  {
    fprintf(stderr, "No input file %s, abort\n", input_name);
    return -1;
  }

  /* read and fill even voxels */
  while (fscanf(fd, "%d %d %d", &x, &y, &z)==3)
  {
    (*num) += fillEvenFromCube(x,y,z);
    n++;
  }
  fclose(fd);
  
  /* read again and fill odd voxels */
  fd = fopen(input_name, "r");
  while (fscanf(fd, "%d %d %d", &x, &y, &z)==3)
  {
    (*num) += fillOddFromCube(x,y,z);
    n++;
  }
  fclose(fd);
  
  return n;
}


int writeBCC(char * input_name, FILE * fd_out, int *num)
{
  FILE * fd = fopen(input_name, "r");
  int x,y,z, n = 0;
  (*num) = 0;
  if (fd==NULL)
  {
    fprintf(stderr, "No input file %s, abort\n", input_name);
    return -1;
  }
  while (fscanf(fd, "%d %d %d", &x, &y, &z)==3)
  {
    (*num) += writeBCCfromCube(x,y,z, fd_out);
    n++;
  }
  fclose(fd);
  return n;
}

/* ------------------------------------------------------------------------ */

/*
Considering that incident cubes in a vertex are given in this order:
0) dir +p = -x+y+z
1) dir +q = +x-y+z
2) dir +r = -x-y-z
3) dir +s = +x+y-z
4) dir -p = +x-y-z
5) dir -q = -x+y-z
6) dir -r = +x+y+z
7) dir -s = -x-y+z
Then the bit mask to get the 4 cubes in directions is:
 +x is 01011010=0x5A,
 +y is 01101001=0x69
 +z is 11000011=0xC3 
 -x is 10100101=0xA5
 -y is 10010110=0x96
 -z is 00111100=0x3C
And the bit mask to get one pair of 2 cubes (subset of the 4 ones
above) that are non face-adjacent is:
 +x is 00001010=0x0A,
 +y is 00001001=0x09
 +z is 00000011=0x03 
 -x is 00000101=0x05
 -y is 00000110=0x06
 -z is 00001100=0x0C 
*/


/*
In the cubic grid, we call:
- empy edge an edge where all 4 incident cubes are empty
- full edge an edge where all 4 incident cubes are full
Note that if a vertex has a full incident edge e, then only the 
only incident edge that can be empty or non-manifold is the
one aligned with e.
*/


/*
Test if the given vertex is non-manifold.
vert = the BCC odd voxel representing the vertex
num = the number of full incident BCC even voxels
mask = bit mask telling which incident BCC voxel is full
*/
BOOLEAN IsNonManifoldVertex(CellPtr vert, int num, unsigned int mask)
{
#ifdef PARLA
  printf("  IsNonManifoldVertex for vertex ");
  PrintPlainCellPtr(vert);  printf("\n");
#endif
  /* configurations with 2 incident full voxels 
     sharing just this vertex */
  if (mask == 0x11) return 1;
  if (mask == 0x22) return 1;
  if (mask == 0x44) return 1;
  if (mask == 0x88) return 1;
  /* configurations with 2 incident full voxels
     sharing a non-manifold edge */
  if (mask == 0xC0) return 1;
  if (mask == 0x0C) return 1;
  if (mask == 0x03) return 1;
  if (mask == 0x30) return 1;
  if (mask == 0x0A) return 1;
  if (mask == 0xA0) return 1;
  if (mask == 0x09) return 1;
  if (mask == 0x90) return 1;
  if (mask == 0x06) return 1;
  if (mask == 0x60) return 1;
  if (mask == 0x05) return 1;
  if (mask == 0x50) return 1;
  /* configurations with 3 incident full voxels, two of them sharing a
     face, the third one sharing a non-manifold edge with one of them */
  if (mask == 0x23) return 1;
  if (mask == 0x13) return 1;
  if (mask == 0xC4) return 1;
  if (mask == 0xC8) return 1;
  if (mask == 0x32) return 1;
  if (mask == 0x31) return 1;
  if (mask == 0x4C) return 1;
  if (mask == 0x8C) return 1;
  if (mask == 0xA2) return 1;
  if (mask == 0x8A) return 1;
  if (mask == 0x45) return 1;
  if (mask == 0x51) return 1;
  if (mask == 0x46) return 1;
  if (mask == 0x62) return 1;
  if (mask == 0x89) return 1;
  if (mask == 0x91) return 1;
  if (mask == 0x2A) return 1;
  if (mask == 0xA8) return 1;
  if (mask == 0x64) return 1;
  if (mask == 0x26) return 1;
  if (mask == 0x54) return 1;
  if (mask == 0x15) return 1;
  if (mask == 0x98) return 1;
  if (mask == 0x19) return 1;
  /* configurations with 3 incident full voxels
     sharing just this vertex */
  if (mask == 0x0D) return 1;
  if (mask == 0xD0) return 1;
  if (mask == 0x07) return 1;
  if (mask == 0x70) return 1;
  if (mask == 0x0B) return 1;
  if (mask == 0xB0) return 1;
  if (mask == 0x0E) return 1;
  if (mask == 0xE0) return 1;
  /* configurations with 4 incident full voxels
     sharing two non-manifold edges */
  if (mask == 0x33) return 1;
  if (mask == 0xCC) return 1;
  if (mask == 0x55) return 1;
  if (mask == 0xAA) return 1;
  if (mask == 0x99) return 1;
  if (mask == 0x66) return 1;
  /* configurations with 4 full voxels: one corner voxel and
     its 2 face-adjacent voxels, plus the opposite voxel */
  if (mask == 0xE8) return 1;
  if (mask == 0xD8) return 1;
  if (mask == 0xB8) return 1;
  if (mask == 0xE4) return 1;
  if (mask == 0x74) return 1;
  if (mask == 0xD4) return 1;
  if (mask == 0xE2) return 1;
  if (mask == 0xB2) return 1;
  if (mask == 0x72) return 1;
  if (mask == 0xD1) return 1;
  if (mask == 0xB1) return 1;
  if (mask == 0x71) return 1;
  if (mask == 0x8B) return 1;
  if (mask == 0x8D) return 1;
  if (mask == 0x8E) return 1;
  if (mask == 0x47) return 1;
  if (mask == 0x4E) return 1;
  if (mask == 0x4D) return 1;
  if (mask == 0x1D) return 1;
  if (mask == 0x1B) return 1;
  if (mask == 0x17) return 1;
  if (mask == 0x27) return 1;
  if (mask == 0x2B) return 1;
  if (mask == 0x2E) return 1;
  /* configurations with 4 incident full voxels
     sharing just this vertex */
  if (mask == 0x0F) return 1;
  if (mask == 0xF0) return 1;
  /* configurations with 5 incident full voxels
     where exactly 2 empty voxels are face-adjacent */
  if (mask == 0xEC) return 1;
  if (mask == 0xDC) return 1;
  if (mask == 0xCD) return 1;
  if (mask == 0xCE) return 1;
  if (mask == 0x73) return 1;
  if (mask == 0xB3) return 1;
  if (mask == 0x3B) return 1;
  if (mask == 0x37) return 1;
  if (mask == 0xEA) return 1;
  if (mask == 0xBA) return 1;
  if (mask == 0xAE) return 1;
  if (mask == 0xAB) return 1;
  if (mask == 0x9B) return 1;
  if (mask == 0x9D) return 1;
  if (mask == 0xB9) return 1;
  if (mask == 0xD9) return 1;
  if (mask == 0xD5) return 1;
  if (mask == 0x75) return 1;
  if (mask == 0x5D) return 1;
  if (mask == 0x57) return 1;
  if (mask == 0x76) return 1;  
  if (mask == 0xE6) return 1;
  if (mask == 0x67) return 1;
  if (mask == 0x6E) return 1;
  /* configurations with 5 incident full voxels, which are one
     voxel, its 3 face-adjacent voxels, and its opposite voxel */
  if (mask == 0x1F) return 1;
  if (mask == 0xF1) return 1;
  if (mask == 0x2F) return 1;
  if (mask == 0xF2) return 1;
  if (mask == 0x4F) return 1;
  if (mask == 0xF4) return 1;
  if (mask == 0x8F) return 1;
  if (mask == 0xF8) return 1;
  /* configurations with 6 incident full voxels
     where the 2 empty voxels are an opposite pair */
  if (mask == 0x77) return 1;
  if (mask == 0xBB) return 1;
  if (mask == 0xDD) return 1;
  if (mask == 0xEE) return 1;
  /* configurations with 6 incident full voxels,
     4 of them sharing a black edge, and the other 2
     sharing a non-manifold edge */
  if (mask == 0xF3) return 1;
  if (mask == 0x3F) return 1;
  if (mask == 0xFC) return 1;
  if (mask == 0xCF) return 1;  
  if (mask == 0xF5) return 1;
  if (mask == 0xAF) return 1;
  if (mask == 0xFA) return 1;
  if (mask == 0x5F) return 1;
  if (mask == 0xF9) return 1;
  if (mask == 0x6F) return 1;
  if (mask == 0x9F) return 1;
  if (mask == 0xF6) return 1;
  /* manifold configurations */
#ifdef PARLA
  printf(" vertex was manifold\n");
#endif
  return 0;
}

/*
Test if the given vertex has a black edge (edge shared by four
full incident voxels in the vertex). Return the direction
(axis = one of 'x','y',z') and sign (-1 or 1) of the first 
black edge found. Start searching from the ones lying in negative
direction from the vertex, so a negative direction is returned,
if any.
vert = the BCC odd voxel representing the vertex
num = the number of full incident BCC even voxels
mask = bit mask telling which incident BCC voxel is full
*/
BOOLEAN VertexHasBlackEdge(CellPtr vert, int num, unsigned int mask,
    char * dir_name, int * dir_sign)
{
  /* test negative directions */
  (*dir_sign) = -1;
  if ((mask & 0xA5)==0xA5)
  {  (*dir_name) = 'x'; return 1; }
  if ((mask & 0x96)==0x96)
  {  (*dir_name) = 'y'; return 1; }
  if ((mask & 0x3C)==0x3C)
  {  (*dir_name) = 'z'; return 1; }
  /* test positive directions */
  (*dir_sign) = 1;
  if ((mask & 0x5A)==0x5A)
  {  (*dir_name) = 'x'; return 1; }
  if ((mask & 0x69)==0x69)
  {  (*dir_name) = 'y'; return 1; }
  if ((mask & 0xC3)==0xC3)
  {  (*dir_name) = 'z'; return 1; }
  /* no black edge */
  return 0;
}

/*
Test if the given vertex has a white edge (edge shared by four
empty incident voxels in the vertex). Return the direction
(axis = one of 'x','y',z') and sign (-1 or 1) of the first 
black edge found. Start searching from the ones lying in positive
direction from the vertex, so a positive direction is returned,
if any.
vert = the BCC odd voxel representing the vertex
num = the number of full incident BCC even voxels
mask = bit mask telling which incident BCC voxel is full
*/
BOOLEAN VertexHasWhiteEdge(CellPtr vert, int num, unsigned int mask,
    char * dir_name, int * dir_sign)
{
  /* test positive directions */
  (*dir_sign) = 1;
  if ((mask & 0xA5)==mask)
  {  (*dir_name) = 'x'; return 1; }
  if ((mask & 0x96)==mask)
  {  (*dir_name) = 'y'; return 1; }
  if ((mask & 0x3C)==mask)
  {  (*dir_name) = 'z'; return 1; }
  /* test negative directions */
  (*dir_sign) = -1;
  if ((mask & 0x5A)==mask)
  {  (*dir_name) = 'x'; return 1; }
  if ((mask & 0x69)==mask)
  {  (*dir_name) = 'y'; return 1; }
  if ((mask & 0xC3)==mask)
  {  (*dir_name) = 'z'; return 1; }
  /* no white edge */
  return 0;
}

/*
Test if the edge from given vertex in Cartesian direction dir
is non-manifold.
It is non-manifold iff the 4 incident cubes are 2 full and 2
empty, and they are not face-adjacent.
vert = the BCC odd voxel representing the vertex
num = the number of full incident BCC even voxels
mask = bit mask telling which incident BCC voxel is full
dir_name = one of 'x','y','z'
dir_sign = -1 or 1
*/
BOOLEAN IsNonManifoldEdge(CellPtr vert, char dir_name, int dir_sign,
   int num, unsigned int mask)
{
#ifdef PARLA
  printf("  IsNonManifoldEdge for vertex ");
  PrintPlainCellPtr(vert); 
  printf("with mask=%x in dir %d %c\n", mask, dir_sign, dir_name);
#endif
  switch (dir_name)
  {
    case 'x':
    if (dir_sign==1) /* POS_X */
      return (((mask | 0x0F) == 0x5F) && ((mask & 0x0A) == 0x0)) || 
             (((mask | 0xF0) == 0xFA) && ((mask & 0x50) == 0x0)) ;
    else /* NEG_X */
      return (((mask | 0x0F) == 0xAF) && ((mask & 0x05) == 0x0)) ||
             (((mask | 0xF0) == 0xF5) && ((mask & 0xA0) == 0x0));
    break;
    case 'y':
    if (dir_sign==1) /* POS_Y */
      return (((mask | 0x0F) == 0x6F) && ((mask & 0x09) == 0x0)) ||
             (((mask | 0xF0) == 0xF9) && ((mask & 0x60) == 0x0));
    else /* NEG_Y */
      return (((mask | 0x0F) == 0x9F) && ((mask & 0x06) == 0x0)) || 
             (((mask | 0xF0) == 0xF6) && ((mask & 0x90) == 0x0));
    break;
    case 'z':
    if (dir_sign==1) /* POS_Z */
      return (((mask | 0x0F) == 0xCF) && ((mask & 0x03) == 0x0)) ||
             (((mask | 0xF0) == 0xF3) && ((mask & 0xC0) == 0x0));
    else /* NEG_Z */
      return (((mask | 0x0F) == 0x3F) && ((mask & 0x0C) == 0x0)) ||
             (((mask | 0xF0) == 0xFC) && ((mask & 0x30) == 0x0));
    break;
  }
  /* it should not happen */
#ifdef PARLA
  printf("  wrong parameters\n");
#endif  
  return 0;
}

/*
Test if a given vertex (BCC odd voxel) must be filled.
A vertex v must be filled in one of these cases:
- v is interior (all 8 incident cubes are full)
- v has 1 full incident edge (edge surrounded by 4 full cubes)
  in negative axis direction from v
- v has 1 empty incident edge (edge surrounded by 4 empty cubes)
  and the opposite incident edge to this is non-manifold
- v has no empty incident edge and v is a non-manifold vertex  
- v has no empty incident edge and there is some non-manifold 
  edge incident in v
*/
BOOLEAN MustBeFilled(CellPtr vert)
{
  /* count number of incident full voxels */
  int num_full; 
  /* for adj voxels */
  struct CellStruct aux8[8];
  /* bit vector for marking adj voxels as empty=0 or full=1 */
  unsigned int mask;
  /* other variables... */
  int i, res;
  BOOLEAN is_ok;
  unsigned int temp;
  BOOLEAN black_edge, white_edge;
  int black_sign, white_sign;
  char black_dir, white_dir;
  
#ifdef PARLA
  printf("MustBeFilled "); PrintCellPtr(vert); printf("\n");
#endif
  /* adj voxels are returned in this order: +p +q +r +_s
     -p -q -r -s, and are related with Cartesian axes in this way:
     +x = -p+q-r+s, +y= +p-q-r+s, +z = +p-q-r+s */
  Get8AdjacentVoxels(vert, aux8);
  /* count full voxels and init bit vector */
  mask = 0;
  num_full = 0;
  temp = 0x1;
  for (i=0; i<8; i++)
  {
    if (GetVoxelStatus(&aux8[i])==1) /* pieno */
    {
      num_full++;
      mask = mask | temp;
    }
    temp = temp << 1;
  }
  /* shortcuts */
  /* internal vertex must be filled */
  if (num_full==8) return 1;
  /* vertex with 1 full incident cube must not */
  if (num_full<=1) return 0;
  
  /* rules */
  /* vertex with black edge in negative axis dir must be filled */
  black_edge = VertexHasBlackEdge(vert, num_full, mask,
                  &black_dir, &black_sign);
#ifdef PARLA
  printf("  vertex has mask = %x\n", mask);
  printf("MustBeFilled, vertex has black edge? %d", black_edge);
  if (black_edge) printf(" in dir %d %c\n", black_sign, black_dir);
  else printf("\n");
#endif
  if (black_edge && (black_sign==-1)) return 1;
  
  /* vertex with white edge in positive axis dir and
     critical edge in opposite dir must be filled */ 
  white_edge = VertexHasWhiteEdge(vert, num_full, mask,
                  &white_dir, &white_sign);
#ifdef PARLA
  printf("MustBeFilled, vertex has white edge? %d", white_edge);
  if (white_edge) printf(" in dir %d %c\n", white_sign, white_dir);
  else printf("\n");
#endif
  if (white_edge && (white_sign==1))
  {
    return IsNonManifoldEdge(vert, white_dir,-1, num_full, mask);
  }
  
  /* vertex with white edge in negative dir must not be filled */
  if (white_edge) return 0;
  
  /* vertex with no white edge must be filled if it 
     is non-manifold, or incident in a non-manifold edge */
  if (IsNonManifoldVertex(vert, num_full, mask)) return 1;
  if (IsNonManifoldEdge(vert, 'x',1, num_full, mask)) return 1;
  if (IsNonManifoldEdge(vert, 'y',1, num_full, mask)) return 1;
  if (IsNonManifoldEdge(vert, 'z',1, num_full, mask)) return 1;
  if (IsNonManifoldEdge(vert, 'x',-1, num_full, mask)) return 1;
  if (IsNonManifoldEdge(vert, 'y',-1, num_full, mask)) return 1;
  if (IsNonManifoldEdge(vert, 'z',-1, num_full, mask)) return 1;
#ifdef PARLA
  printf("MustBeFilled, vertex is not to be filled\n");
#endif
  /* other configurations must not be filled */
  return 0;
}

/* ------------------------------------------------------------------------ */
