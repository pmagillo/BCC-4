#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "relations.h"
#include "reading2.h"

/*
Given a set of full cubic voxels, we want to initialize a BCC grid 
in which, for each full input cube, we have:
- an even full BCC voxel for the cube
- an odd full BCC voxel for some of its vertices, necessary to 
  get a manifold configuration while maintaining the topological
  properties

Here we have utilities for:
1) reading the cube file and initializing the BCC grid
2) writing the BCC full voxels (side affect: empty them)

Correct sequence to call functions:
0) init mark arrays based on coordinates of input cubes
1) call fillBCC 
2) call writeBCC
*/

/* Fill only the even voxel corresponding to the cube */
extern int fillEvenFromCube(int x, int y, int z);

/*
To be called when even voxel have been already filled.
Fill the necessary odd voxels.
*/
int fillOddFromCube(int x, int y, int z);

/*
Given the coordinates of the a cube, 
write the corresponding BCC voxels, if full, and then empty them.
Return number of written and emptied voxels.
*/
extern int writeBCCfromCube(int x, int y, int z, FILE * fd_out);

/*
Read cubes from file and fill the corresponding BCC voxels.
Return number of read cubes, initialize number of filled BCC voxels.
*/
extern int fillBCC(char * input_name, int *num);

/*
Read cubes from file a second time (function fillBCCfromAllCubes
must have been called first) and write the
corresponding BCC voxels if they are still full; empty each BCC
voxel after writing. In this way we write each voxel only once.
Return number of read cubes, initialize number of written BCC voxels.
*/
extern int writeBCC(char * input_name, FILE * fd_out, int *num);

/* ------------------------------------------------------------------------ */

/*
Test if the given vertex is non-manifold.
vert = the BCC odd voxel representing the vertex
num = the number of full incident BCC even voxels
mask = bit mask telling which incident BCC voxel is full
*/
extern BOOLEAN IsNonManifoldVertex(CellPtr vert, int num, unsigned int mask);

/*
Test if the edge from given vertex in Cartesian direction dir
is non-manifold.
vert = the BCC odd voxel representing the vertex
num = the number of full incident BCC even voxels
mask = bit mask telling which incident BCC voxel is full
dir_name = one of 'x','y','z'
dir_sign = -1 or 1
*/
extern int IsNonManifoldEdge(CellPtr vert, char dir_name, int dir_sign,
   int num, unsigned int mask);

/*
Test if the given vertex has a black edge (edge shared by four
full incident voxels in the vertex). Return the direction
(axis = one of 'x','y',z') and sign (-1 or 1) of the first 
black edge found. Start searching from the ones lying in negative
direction from the vertex, so a negative direction is returned,
if any.
vert = the BCC odd voxel representing the vertex
num = the number of full incident BCC even voxels
mask = bit mask telling which incident BCC voxel is full
*/
extern BOOLEAN VertexHasBlackEdge(CellPtr vert, int num, unsigned int mask,
    char * dir_name, int * dir_sign);

/*
Test if the given vertex has a white edge (edge shared by four
empty incident voxels in the vertex). Return the direction
(axis = one of 'x','y',z') and sign (-1 or 1) of the first 
black edge found. Start searching from the ones lying in positive
direction from the vertex, so a positive direction is returned,
if any.
vert = the BCC odd voxel representing the vertex
num = the number of full incident BCC even voxels
mask = bit mask telling which incident BCC voxel is full
*/
extern BOOLEAN VertexHasWhiteEdge(CellPtr vert, int num, unsigned int mask,
    char * dir_name, int * dir_sign);

/*
Test if a given vertex (BCC odd voxel) must be filled.
A vertex v must be filled in one of these cases:
- v is interior (all 8 incident cubes are full)
- v has 1 full incident edge (edge surrounded by 4 full cubes)
  in negative axis direction from v
- v has 1 empty incident edge (edge surrounded by 4 empty cubes)
  and the opposite incident edge to this is non-manifold
- v has no empty incident edge and v is a non-manifold vertex  
- v has no empty incident edge and there is some non-manifold 
  edge incident in v
*/
extern BOOLEAN MustBeFilled(CellPtr vert);

/* ------------------------------------------------------------------------ */
