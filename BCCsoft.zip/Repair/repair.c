#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include "relations.h"
#include "reading2.h"
#include "filling.h"

/*
Read a file containing full cubic voxels.
Write a set of BCC voxels in which, for each full input cube, we have:
- an even full BCC voxel for the cube
- an odd full BCC voxel for some of its vertices, necessary to 
  get a manifold configuration while maintaining the topological
  properties
*/

/* ------------------------------------------------------------------------ */

/*
Macros controlling the compilation:

PARLA:
  If defined, enable printing of what the algorithm is doing.

COUNTING:
  Print size of allocated marking array.

EXEC_TIME:
  Measure execution time.
*/

#ifdef EXEC_TIME
#include <time.h>
#endif

/* ------------------------------------------------------------------------ */

#ifdef COUNTING
  int array_size;
#endif 

/* ------------------------------------------------------------------------ */

/* Parameters are the input and the output file.
   Output file is optional; if missing, the output file is stdout. */
int main(int arg_n, char **arg_v)
{
  int n_cubes = 0, n_voxels = 0, dummy;
  FILE * fd_out = NULL;
  
  /* Range of coordinates of input voxels. */
  struct RangeStruct bbox;
  
  if (arg_n<2)
  {
    fprintf(stderr, "Use: %s in_file_name [-v vertex_out_file]");
    fprintf(stderr, " [-e edge_out_file] [out_file_name]\n", arg_v[0]);
    return 1;
  }

  /* Other parameters */
  if (arg_n>2)
  {
      fprintf(stderr, "Output file: %s\n", arg_v[2]);
      fd_out = fopen(arg_v[2], "w");
      if (fd_out!=NULL)
         fprintf(stderr, "Writing to file %s\n", arg_v[2]);
  }
  if (fd_out==NULL)
  {
    fprintf(stderr, "No output file, using stdout\n");
    fd_out = stdout;
  }   

#ifdef EXEC_TIME
  clock_t start_time, end_time;
  int spent_time;
  start_time = clock();
#endif 

  /* Get number of voxels and extreme coordinates */
  /* We also store the voxel with minimum x-coordinate,
     this must be an exposed voxel */ 
  InitRange(&bbox);
  n_cubes = ReadExtremes2(arg_v[1], &bbox);
  if (n_cubes<=0)
  {
    if (n_cubes==-1) fprintf(stderr, "No input file, abort\n");
    if (n_cubes==0) fprintf(stderr, "No full voxels, nothing to do, abort\n");
    return 1;
  }  
  fprintf(stderr, "Input full cubic voxels: %d\n", n_cubes);

  /* Allocate marking arrays */
#ifdef COUNTING
  array_size = allocMarkingArray(&bbox);
#else
  allocMarkingArray(&bbox);
#endif

  /* Read full voxels and mark them */
  ResetVoxelStatus();
  SetDefaultStatus(0); /* voxels out of limits are empty */

  fillBCC(arg_v[1], &n_voxels);

#ifdef PARLA
  printf("Read %d cubes, filled %d voxels\n", n_cubes, n_voxels);
#endif

#ifdef EXEC_TIME
  end_time = clock();
  spent_time = (end_time-start_time)*1000 / CLOCKS_PER_SEC;
  fprintf(stderr, "R Time (milliseconds): %d\n", spent_time);
#endif

  /* Now write filled voxels and mark as empty */
  fprintf(stderr, "Output full BCC voxels: %d\n", n_voxels);
  writeBCC(arg_v[1], fd_out, &dummy);
#ifdef PARLA
  if (arg_n>2)
    printf("Voxels written to file %s\n", arg_v[2]);
  else 
    printf("Voxels written to stdout\n");
#endif

#ifdef COUNTING
    fprintf(stderr, "Marking arrays (bytes): %d\n", array_size);
/*  sizeof(unsigned char) == 1 byte */
#endif

}

/* ------------------------------------------------------------------------ */
