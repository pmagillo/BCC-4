/*
Convert a set of voxels in cubic grid into a set of voxels in a BCC grid. 
Given the integer coordinates (x,y,z) of (the center of) a cube,
the corresponding coordinates in the BCC grid are:
p=4(-x+y+z)
q=4(x-y+z)
r=4(-x-y-z) 
s=4(x+y-z)

Read from stdin, write to stdout.

Esempio:
./cubic2bcc < esempioFig17_Gonzales2014.cub > esempioFig17_Gonzales2014.bcc
converte l'esempio di griglia cubica in fig.17 dell'articolo di
Gonzales-Diaz, Jimenez, Medrano 2014
"3D Well-Composed Polyhedral Complexes"
*/

#include <stdio.h>

int main()
{
  int x,y,z;
  int p,q,r,s;
  int n = 0;
  
  fprintf(stderr,"Read from stdin, write to stdout...\n");
  while (scanf("%d %d %d", &x, &y, &z)==3)
  {
    n++;
    p = 4*(-x+y+z);   q = 4*(x-y+z);
    r = 4*(-x-y-z);   s = 4*(x+y-z);
    printf("%d %d %d %d\n", p,q,r,s);
  }
  fprintf(stderr,"I have read and written %d voxels.\n", n);
}
