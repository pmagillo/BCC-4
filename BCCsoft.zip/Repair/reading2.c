#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "reading2.h"
#include "relations.h"

/*
This file is alternative and not compatible with ../algo/reading.c
*/

/* ------------------------------------------------------------------------ */

void voxelFromCube(CellPtr c, int x, int y, int z)
{
  FillCoord(c, 4*(-x+y+z), 4*(x-y+z), 4*(-x-y-z), 4*(x+y-z));
}

/* ------------------------------------------------------------------------ */

void InitRange(struct RangeStruct * range)
{
  range->min_x = range->min_y = range->min_z = INT_MAX;
  range->max_x = range->max_y = range->max_z = INT_MIN;
  range->min_p = range->min_q = range->min_r = range->min_s = INT_MAX;
  range->max_p = range->max_q = range->max_r = range->max_s = INT_MIN;
  range->min_x_voxel = NULL;
}

void UpdateRangeFromVoxel(CellPtr c, struct RangeStruct * range)
{
  int x,y,z;
  VoxelCenterXYZ(c, &x, &y, &z);
  if (x>range->max_x) range->max_x = x; 
  if (x<range->min_x) range->min_x = x;
  if (y>range->max_y) range->max_y = y;
  if (y<range->min_y) range->min_y = y;
  if (z>range->max_z) range->max_z = z;
  if (z<range->min_z) range->min_z = z;
  if (P_COORD(c)>range->max_p) range->max_p = P_COORD(c); 
  if (P_COORD(c)<range->min_p) range->min_p = P_COORD(c);
  if (Q_COORD(c)>range->max_q) range->max_q = Q_COORD(c); 
  if (Q_COORD(c)<range->min_q) range->min_q = Q_COORD(c);
  if (R_COORD(c)>range->max_r) range->max_r = R_COORD(c); 
  if (R_COORD(c)<range->min_r) range->min_r = R_COORD(c);
  if (S_COORD(c)>range->max_s) range->max_s = S_COORD(c); 
  if (S_COORD(c)<range->min_s) range->min_s = S_COORD(c);
  if (range->min_x_voxel==NULL)
  {  range->min_x_voxel = (CellPtr) malloc(sizeof(struct CellStruct));
     CopyCoordFrom(range->min_x_voxel, c);
  }
  else if (x<=range->min_x) CopyCoordFrom(range->min_x_voxel, c);
}

void UpdateRange(int p, int q, int r, int s, struct RangeStruct * range)
{
  struct CellStruct c;
  struct CellStruct adj1, adj2;
  FillCoord(&c, p,q,r,s);
  if (IsVoxel(&c)) UpdateRangeFromVoxel(&c, range); 
  else /* we assume that c is face */
  {
    GetFaceVoxels(&c, &adj1, &adj2);
    /* the first one, adj1, is the reference voxel for the face */
    UpdateRangeFromVoxel(&adj1, range);
  }
}

int ReadExtremes2(char * name, struct RangeStruct * range)
{
  int x,y,z;
  int counter = 0;
  struct CellStruct c;
  
  FILE * fd = fopen(name, "r");
  if (fd==NULL)
  {
    fprintf(stderr, "No input file %s, abort\n", name);
    return -1;
  }
  while (fscanf(fd, "%d %d %d", &x, &y, &z)==3)
  {
    voxelFromCube(&c, x,y,z);
    if (range != NULL) UpdateRangeFromVoxel(&c, range);
    counter++;
  }
  fclose(fd);
  return counter;
}

int ReadExtremes3(char * name, struct RangeStruct * range)
{
  int x,y,z;
  int counter = 0;
  struct CellStruct c;
  
  FILE * fd = fopen(name, "r");
  if (fd==NULL)
  {
    fprintf(stderr, "No input file %s, abort\n", name);
    return -1;
  }
  while (fscanf(fd, "%d %d %d", &x, &y, &z)==3)
  {
    voxelFromCube(&c, x-2,y-2,z-2);
    if (range != NULL) UpdateRangeFromVoxel(&c, range);
    voxelFromCube(&c, x+2,y+2,z+2);
    if (range != NULL) UpdateRangeFromVoxel(&c, range);
    counter++;
  }
  fclose(fd);
  return counter;
}

int allocMarkingArray(struct RangeStruct * range)
{
#ifdef PARLA
  printf("Init marking arrays for x in[%d,%d] ",range->min_x,range->max_x);
  printf("y in[%d,%d] ",range->min_y,range->max_y);
  printf("z in[%d,%d]\n",range->min_z,range->max_z);
  printf("Init marking arrays for p in[%d,%d] ",range->min_p,range->max_p);
  printf("q in[%d,%d] ",range->min_q,range->max_q);
  printf("r in[%d,%d] ",range->min_r,range->max_r);
  printf("s in[%d,%d]\n",range->min_s,range->max_s);
#endif

  return InitMarkArrayXYZ(range->min_x,range->min_y,range->min_z,
                          range->max_x,range->max_y,range->max_z);
}

/* ------------------------------------------------------------------------ */
