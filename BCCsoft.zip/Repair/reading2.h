#ifndef READING2_INCLUDED
#define READING2_INCLUDED

#include "cells.h"

/*
This file is alternative and not compatible with ../algo/reading.h
*/

/* ------------------------------------------------------------------------ */

/* Fill the p,q,r,s coordinates with the BCC coordinates of
cube centered at (x,y,z). */
extern void voxelFromCube(CellPtr c, int x, int y, int z);

/* ------------------------------------------------------------------------ */

/* Range of Cartesian coordinates of centers of input voxels. */
struct RangeStruct
{
  int max_x, min_x;
  int max_y, min_y;
  int max_z, min_z;
  int max_p, min_p;
  int max_q, min_q;
  int max_r, min_r;
  int max_s, min_s;
  CellPtr min_x_voxel;
};

extern void InitRange(struct RangeStruct * range);

/* Update the range according to voxel (p,q,r,s). */
extern void UpdateRange(int p, int q, int r, int s, 
            struct RangeStruct * range);

/* Open file of given name, which must contain cubic cells.
   Count number of cells; if the range is not NULL, then init
   the extreme coordinates (of the corresponding BCC cells) within it. */
extern int ReadExtremes2(char * name, struct RangeStruct * range);

/* Same as above, but consider as if there was an extra layer of voxels
around the ones specified in the file. */
extern int ReadExtremes3(char * name, struct RangeStruct * range);

/* Allocate marking array based on the given range, return number of
   allocated bytes. */
extern int allocMarkingArray(struct RangeStruct * range);

#endif /* READING2_INCLUDED */
/* ------------------------------------------------------------------------ */
