#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>

/*
Generate a random set of full cubes containing a specified number of cubes
whose coordinates are within a predefined range. 
Cubes in the set are connected by sharing
a face, an edge, or a vertex (26-connected).
Cubes are expressed by integer coordinates (coordinates of the center
assuming that the edge length of the grid is 1).
They are written to a file in format x y z where x y z are integer
numbers expressing the coordinates of the center of a cube.
Command-line parameters:
1) number of cubes to be generated
2) file name to be generated
2a) coordinate range for both x,y,z, or
2b) three coordinate ranges for x,y,z, respectively
Example:
100 cubes.txt
100 cubes.txt 50
100 cubes.txt 100 20
If called without parameters, it will ask the user.
The set of full cubes is obtained by starting from the one centered in 
(0,0,0) and moving randomly in one direction for a fixed number of times.
Moving in a direction means adding a translation vector (dx,dy,dz) where
values of dx,dy,dz belong to set {-1,0,1} and cannot be all = 0.
The set of full cubes is also forced to include the span the entire 
coordinate range by including all diagonal cubes.
*/

/*
Macros controlling the compilation:

PARLA:
  If defined, enable printing of what the algorithm is doing.

WIDTH:
  It must be defined as an integer number >=0, and it defined the
  policy for moving in the search for new empty cubes. 
  If =0, proceed in depth first search; if >=14, proceed in breadth
  first search; intermediate values produce intermediate behaviors.

MIX_NUMBERS:
  If defined, mix numbers in the random generator, so that each
  each execution will give a different result.
  If numbers are not mixed, the output will deterministic and not random.
*/

#ifndef WIDTH
#define WIDTH 0
#endif


/* Type used to represent a cube */
typedef struct CubeStruct { int coord[3]; } * CubePtr;

typedef unsigned char MY_CHAR;

/* Limits for coordinate range */
int max_val, min_val;
int min_x, min_y, min_z, max_x, max_y, max_z;

/* Matrix storing 0 or 1 for a cube, 0=empty and 1=full */
MY_CHAR *** mark;

/* Array used to contain generated full cubes, the ones with all 8
   adjacent cubes full will be deleted as they are found */
CubePtr * visited_array;

/* Number of cubes in previous array */
int visited_size;

/* Array for empty adjacent cubes of given cube */
struct CubeStruct empty_adj[26];

/* conta quante volte ho scartato un adiacente perche'
sconfinava dalla parte marcabile */
int DEBUGsconfina;
/* conta quante volte ho scartato un adiacente perche' era pieno */
int DEBUGpieno;
/* numero di cube da cui non posso proseguire perche' sconfino */
int DEBUGbloccati = 0;
int DEBUGriempiti = 0;
int DEBUGcancellati = 0;

int iter_num;

/* ------------------------ CUBES ----------------------------------------- */

void FillCoord(CubePtr c, int x, int y, int z)
{ c->coord[0] = x; c->coord[1] = y; c->coord[2] = z; }

void CopyCoordFrom(CubePtr c, CubePtr source_c)
{ c->coord[0] = source_c->coord[0];
  c->coord[1] = source_c->coord[1];
  c->coord[2] = source_c->coord[2];
}

void PrintCubePtr(CubePtr c)
{  printf("(%d, %d, %d)", c->coord[0], c->coord[1], c->coord[2]); }

/* ------------------------ MARKING --------------------------------------- */

/* initially all grid is empty, and cubes out of range are considered 
   as full */

void InitMarkArrayXYZ(int rangeX, int rangeY, int rangeZ)
{
  int x,y,z;

  min_x = -rangeX/2+1;
  max_x =  rangeX/2;
  
  min_y = -rangeY/2+1;
  max_y =  rangeY/2;

  min_z = -rangeZ/2+1;
  max_z =  rangeZ/2;

#ifdef PARLA
  fprintf(stderr, "Matrix [%d,%d][%d,%d][%d,%d] i.e. %d x %d x %d\n", 
     min_x,max_x, min_y,max_y, min_z,max_z, rangeX,rangeY,rangeZ);
#endif

/*printf("Alloco %d caselle per x: mark[%d]\n", rangeX,rangeX);*/
  mark = (MY_CHAR ***)malloc(rangeX * sizeof(MY_CHAR **));
  for (x=0; x<rangeX; x++)
  {
/*printf("Alloco %d caselle per y: mark[%d][%d]\n", rangeY,rangeX,rangeY);*/
    mark[x] = (MY_CHAR **)malloc(rangeY * sizeof(MY_CHAR *));
    for (y=0; y<rangeY; y++)
    {
/*printf("Alloco %d caselle per z: mark[%d][%d][%d]\n", rangeZ,rangeX,rangeY,rangeZ);*/
      mark[x][y] = (MY_CHAR *)malloc(rangeZ * sizeof(MY_CHAR));
      for (z=0; z<rangeZ; z++)
         mark[x][y][z] = (MY_CHAR)0;
    }
  }
}  

/* return the status of a cube of center (x,y,z) */
MY_CHAR GetStatus(int x, int y, int z)
{ 
  /* cubes out of range are considered as full */
if ((x<min_x)||(x>max_x)||(y<min_y)||(y>max_y)||(z<min_z)||(z>max_z))
DEBUGsconfina++;
  if ((x<min_x)||(x>max_x)) return 1;
  if ((y<min_y)||(y>max_y)) return 1;
  if ((z<min_z)||(z>max_z)) return 1;
/*printf("Get: accedo casella mark[%d][%d][%d]\n", (-min_x+x),(-min_y+y),(-min_z+z));*/
  /* access the marking matrix */
  return mark[-min_x+x][-min_y+y][-min_z+z];
}

/* return the status of a cube */
MY_CHAR GetCubeStatus(CubePtr c)
{  return GetStatus(c->coord[0], c->coord[1], c->coord[2]); }

/* set the status of a cube of center (x,y,z) */
void SetStatus(int x, int y, int z, int st)
{
/*printf("Set: accedo casella mark[%d][%d][%d]\n", (-min_x+x),(-min_y+y),(-min_z+z));*/
  mark[-min_x+x][-min_y+y][-min_z+z] = (MY_CHAR)st; }

/* set the status of a cube */
void SetCubeStatus(CubePtr c, int st)
{  SetStatus(c->coord[0], c->coord[1], c->coord[2], st); }

/* ------------------------ AUXILIARY FUNCTIONS --------------------------- */

/* Get adjacent in given direction and return complement of its status 
   (0=full, 1=empty), that is, 1 iff we can take it as the next
   cube to be filled, 0 otherwise. */
int AdjacentWithStatus(CubePtr c, int dx, int dy, int dz, CubePtr adj)
{
  adj->coord[0] = c->coord[0]+dx;
  adj->coord[1] = c->coord[1]+dy;
  adj->coord[2] = c->coord[2]+dz;
  if (GetCubeStatus(adj)!=0) DEBUGpieno++;
/*printf("  stato di adiac "); PrintCubePtr(adj); printf(" = %d\n", GetCubeStatus(adj));
printf("  e ritorno %d\n",  ((GetCubeStatus(adj)==0) ? 1 : 0)   );*/
  return ((GetCubeStatus(adj)==0) ? 1 : 0);
}

/* Count the empty adjacent cubes (empty iff status == 0) and put them
   into array */
int GetEmptyAdjacents(CubePtr c)
{
  struct CubeStruct aux;
  DEBUGsconfina = DEBUGpieno = 0;
  int count = 0;
  /* 6 face-adjacent */
   count += AdjacentWithStatus(c, 1,0,0, &empty_adj[count]);
   count += AdjacentWithStatus(c, 0,1,0, &empty_adj[count]);
   count += AdjacentWithStatus(c, 0,0,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,0,0, &empty_adj[count]);
   count += AdjacentWithStatus(c, 0,-1,0, &empty_adj[count]);
   count += AdjacentWithStatus(c, 0,0,-1, &empty_adj[count]);
  /* 12 edge-adjacent */
   count += AdjacentWithStatus(c, 1,1,0, &empty_adj[count]);
   count += AdjacentWithStatus(c, 0,1,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, 1,0,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,-1,0, &empty_adj[count]);
   count += AdjacentWithStatus(c, 0,-1,-1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,0,-1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,1,0, &empty_adj[count]);
   count += AdjacentWithStatus(c, 0,-1,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,0,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, 1,-1,0, &empty_adj[count]);
   count += AdjacentWithStatus(c, 0,1,-1, &empty_adj[count]);
   count += AdjacentWithStatus(c, 1,0,-1, &empty_adj[count]);
  /* 8 vertex-adjacent */
   count += AdjacentWithStatus(c, 1,1,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, 1,1,-1, &empty_adj[count]);
   count += AdjacentWithStatus(c, 1,-1,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,1,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, 1,-1,-1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,1,-1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,-1,1, &empty_adj[count]);
   count += AdjacentWithStatus(c, -1,-1,-1, &empty_adj[count]);
  /* count = 26 - DEBUGpieno - DEBUGsconfina */
  if ((count==0)&&(DEBUGsconfina>0)) DEBUGbloccati++; 
  return count;
}

/* Move to a random adjacent empty cube of given cube.
   Cube c must have at least an empty adjacent cube.
   Return the number of other empty adjacent cubes of c beside
   the one selected here. */
int RandomAdjacent(CubePtr c, CubePtr adj)
{
  /* take a random number from 0 to number of empty adjacent 
     cubes -1, and use it to select the cube to return. */
  int num_empty, num;
  num_empty = GetEmptyAdjacents(c);
/* 23nov */
if (num_empty==0)
{
printf("RandomAdjacent: Error, cerco adiacente di chi non lo ha\n");
PrintCubePtr(c);
} 
  num = rand() % num_empty;
  /* take num-th ampng directions having an empty adjacent cube */
/*printf("   RandomAdjacent num=%d di %d\n", num, num_empty);*/
  CopyCoordFrom(adj, &empty_adj[num]);
/*#ifdef PARLA
  printf("  RandomAdjacent returns "); PrintCubePtr(adj); 
  printf(" having status %d\n", GetCubeStatus(adj));
#endif*/
  return (num_empty-1);
}

/* Find a cube with some empty adjacent. This is picked randomly
   within array visited_array, if we find a cube with all adjacents
   full, then we delete it from the array. */
int PickStart(CubePtr res_c)
{
  int num, go_on = 1;
int DEBUGingresso = visited_size;
  while (go_on)
  {
/* 23nov */
if (visited_size==0)
{
printf("PickStart: Error, visited_size == zero\n");
printf("    in ingresso era %d\n", DEBUGingresso);
printf("Riempiti: %d\n", DEBUGriempiti);
printf("Cancellati: %d\n", DEBUGcancellati);
printf("Bloccati: %d\n", DEBUGbloccati);
return 0;
}

/*Aprile*/
if ((WIDTH==0)&&(iter_num>=1000))
{
  /* cerca di andare verso la fine dell'array, per espandere 
     lungo propaggini */
     if ((rand() %10)>0) num = visited_size-1;
     else num = rand() % visited_size;
}
else
/* fine aprile*/
    num = rand() % visited_size;
    if (GetEmptyAdjacents(visited_array[num]))
    { /* cube is the result */
      CopyCoordFrom(res_c, visited_array[num]);
      go_on = 0;
    }
    else 
    { /* delete cube from array and try again */
/* 23nov
{
printf("PickStart: [cancello posiz %d]", num);
PrintCubePtr(visited_array[num]);
printf("\n   quando riempiti=%d e visited_size= %d\n", DEBUGriempiti,visited_size);
}*/
      /*visited_array[num] = visited_array[--visited_size];*/
      CopyCoordFrom(visited_array[num],visited_array[visited_size-1]);
      visited_size--;/* 23nov */
      DEBUGcancellati++;
    }
  }
  return 1;
}

/* Fill cubes of the diagonal, i.e., those with coordinates
   (x,y,z) = (c,c,c). If this is not enough to span the entire
   coordinate range, because it was not a square, add the necessary ones.
   Write all such cubes to file. Return the number of filled cubes. */
int FillDiagonal(FILE * out_fd)
{
  struct CubeStruct c;
  int count = 0;
  int x,y,z;
  int stop = 0;
  x = y = z = 0;
#ifdef PARLA
  fprintf(stderr, "FillDiagonal fills ");
#endif
  while (!stop)
  {
    FillCoord(&c, x,y,z);
    fprintf(out_fd, "%d %d %d\n", x,y,z);
    SetCubeStatus(&c, 1);
    DEBUGriempiti++;
    count++;
    /* insert full cube (0,0,0) in visited array */
    if ((x==0)&&(y==0)&&(z==0)) 
        CopyCoordFrom(visited_array[visited_size++],&c);
    stop = 1;
    if (x<max_x) {stop=0; x++;}
    if (y<max_y) {stop=0; y++;}
    if (z<max_z) {stop=0; z++;}
  }
#ifdef PARLA
  fprintf(stderr, "%d and ", count);
#endif
  stop = 0;
  x = y = z = 0;
  while (!stop)
  {
    if (!((x==0)&&(y==0)&&(z==0)))
    {
      FillCoord(&c, x,y,z);
      fprintf(out_fd, "%d %d %d\n", x,y,z);
      SetCubeStatus(&c, 1);
      DEBUGriempiti++;
      count++;
      /* insert new full cube in visited array */
    //  CopyCoordFrom(visited_array[visited_size++],&c);
    }
    stop = 1;
    if (x>min_x) {stop=0; x--;}
    if (y>min_y) {stop=0; y--;}
    if (z>min_z) {stop=0; z--;}
  } 
#ifdef PARLA
  fprintf(stderr, "%d\n", count);
#endif
  return count;
}

/* Start from cube (0.0.0), which have been already filled, 
   and loop to a random adjacent cube for the given number of iterations. 
   Fill the visited cube and write them to file.
   Return the number of cubes, which should be equal to the number of
   iterations. */
int RandomLoop(FILE * out_fd, int iterations)
{
  struct CubeStruct c;
  struct CubeStruct old_c;
  int count = 0;
  int num_other_adj = 0;
  int iterations_on_this = 0;
  
  if (iterations==0) return 0;
  
#ifdef PARLA
  fprintf(stderr, "LOOP...\n");
#endif

#ifdef MIX_NUMBERS
  /* reset C random generator */
  srand ( time(NULL) );
#endif

  /* first cube is one of the filled cubes */
  PickStart(&old_c);

  /* loop for the given number of iterations */
  while (iterations--)
  {
/* 23nov */
if (visited_size==0)
{
printf("Errore, finiti i cubi ma non le iterazioni\n");
printf("iterations = %d\n", iterations);
printf("(scritti) count = %d\n", count);
printf("voxel bloccati = %d\n", DEBUGbloccati);
return count; 
}
     if ((iterations_on_this<WIDTH)&&(num_other_adj>0))
     {  /* remain on this voxel old_c */
        iterations_on_this++;
     }
     else
     {  /* get a different voxel old_c */
        iterations_on_this = 0;
        if (!PickStart(&old_c)) return count; /* 23nov */
     }
/*#ifdef PARLA
     printf("Cycle n.%d, old voxel = ", count); PrintCubePtr(&old_c);
     printf(" having %d empty adjacents\n", GetEmptyAdjacents(&old_c));
#endif*/
    /* old_c has some empty adjacent voxels, take one and fill it */
    num_other_adj = RandomAdjacent(&old_c, &c);
    /* the call to RandomAdjacent has also ensured 
       that we do not to go out from marking range */
    fprintf(out_fd, "%d %d %d\n", c.coord[0], c.coord[1], c.coord[2]);
    SetCubeStatus(&c, 1);
    DEBUGriempiti++;
    count++;
    /* insert new full voxel in visited array */
    CopyCoordFrom(visited_array[visited_size++],&c);
  }

  if (iterations>0) fprintf(stderr,"Error\n");
  /* end */
  fprintf(out_fd, "end\n");
  {int q; for (q=0; q<iterations; q++) free(visited_array[q]);}
  free(visited_array);
  return count;
}

/* ------------------------------------------------------------------------ */

int main(int arg_n, char **arg_v)
{
  char file_name[255] = "";
  int x, y, z;
  FILE * fd;
  int aux, voxel_num;
  int coord_range[3] = {-1,-1,-1};
  
  if ((arg_n<=1)||(arg_n>6)||(arg_n==5))
  {
    fprintf(stderr, "Use: %s [cubes_num] [out_file_name]\n", arg_v[0]);
    fprintf(stderr, "or: %s [cubes_num] [out_file_name] [range]\n", arg_v[0]);
    fprintf(stderr, "or: %s [cubes_num] [out_file_name]", arg_v[0]);
    fprintf(stderr, " [rangeX] [rangeY] [rangeZ]\n");
    fprintf(stderr, "where all numeric parameters are positive integers\n");
    return;
  }
  
  /* number of iterations = number of cubes */
  iter_num = -999;
  if (arg_n>1) aux = sscanf(arg_v[1], "%d", &iter_num);
  else aux = 0;
  if (aux!=1) /* no first parameter or not a number */
  {
    while (iter_num<1)
    {
      fprintf(stdout, "Number of iterations? (integer>=1) ");
      scanf("%d", &iter_num);
    } 
  }
  
  /* output file name */
  if (arg_n>2)  strcpy(file_name, arg_v[2]);  /* 2nd arg */
  else if ((arg_n==2)&&(aux!=1))  /* 1st arg was not iteration num */
           strcpy(file_name, arg_v[1]);

  if (strlen(file_name)==0)
  {
    fd = stdout;
    fprintf(stderr,
          "Generate random grid in %d iterations, write it to stdout\n",
          iter_num);
  }
  else
  { 
    fprintf(stderr,
          "Generate random grid of %d voxels, write  it to file %s\n",
          iter_num, file_name);
    fd = fopen(file_name, "w");
    if (fd==NULL)
    {
      fprintf(stderr, "Cannot open file, abort\n");
      return 1;
    }
  }

  /* coordinate range */
  fprintf(stderr, "coordinate range ");
  if (arg_n>3) sscanf(arg_v[3], "%d", &coord_range[0]);
  if (arg_n==6) 
  {  sscanf(arg_v[4], "%d", &coord_range[1]);
     sscanf(arg_v[5], "%d", &coord_range[2]);
  }
  if (coord_range[0]==-1) /* no parameter or not a number */
  {
     /* range is set by default */
     int sqrt_iter = (int) sqrt((double)(iter_num));
     coord_range[0] = iter_num/sqrt_iter; 
     fprintf(stderr, "set by default ");
  }
  if (coord_range[1]==-1)
     coord_range[1] = coord_range[0]; 
  if (coord_range[2]==-1)
  {
    /*if (iter_num<=100000)*/ coord_range[2] = coord_range[0]; 
    /*else coord_range[2] = coord_range[0]/2;*/
  }
  fprintf(stderr, "is %d x %d x %d\n", coord_range[0], coord_range[1], coord_range[2]);
  
  InitMarkArrayXYZ(coord_range[0], coord_range[1], coord_range[2]);
  visited_array = (CubePtr *) malloc(iter_num*sizeof(CubePtr));
  visited_size = 0;
  {int q; for (q=0; q<iter_num; q++) visited_array[q] = (CubePtr)malloc(sizeof(CubePtr));}

  voxel_num = FillDiagonal(fd);
  voxel_num += RandomLoop(fd, iter_num-voxel_num);
  fprintf(stderr, "Generated %d voxels\n", voxel_num);
}
