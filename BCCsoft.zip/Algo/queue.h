#include <stddef.h>
#include <stdio.h>
#include "cells.h"

#ifndef CELL_QUEUE_INCLUDED
#define CELL_QUEUE_INCLUDED

/* ------------------------------------------------------------------------ */
/* CELL QUEUE, STANDARD IMPLEMENTATION OF FIFO QUEUE */
/* ------------------------------------------------------------------------ */

typedef struct QueueNode * QueueNodePtr;

struct QueueNode
{  
  CellPtr info;
  QueueNodePtr next;
};

typedef struct Queue
{
  QueueNodePtr first;
  QueueNodePtr last;
#ifdef COUNTING
  int number;
#endif
} * QueuePtr;

/* Create new queue, initialize it as empty, return it. */
extern QueuePtr NewEmptyQueue();

/* Test if queue is empty. */
extern BOOLEAN IsEmptyQueue(QueuePtr q);

/* Insert given cell at the end of the queue. */
extern void PutInQueue(QueuePtr q, CellPtr c);

/* Insert a copy of the given cell at the end of the queue. */
extern void CopyInQueue(QueuePtr q, CellPtr c);

/* Remove first cell of the queue and return it. */
extern CellPtr GetFromQueue(QueuePtr q);

extern void PrintQueue(QueuePtr q);

/* Delete the queue structure (not the elements) */
extern void DeleteQueue(QueuePtr q);

/* Delete the queue structure and the elements */
extern void DeleteQueueWithContent(QueuePtr q);

#ifdef COUNTING
extern int SizeOfQueue(QueuePtr q);
#endif

/* ------------------------------------------------------------------------ */

#endif /* CELL_QUEUE_INCLUDED */

