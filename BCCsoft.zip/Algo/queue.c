#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

/* ------------------------------------------------------------------------ */
/* CELL QUEUE, STANDARD IMPLEMENTATION OF FIFO QUEUE */
/* ------------------------------------------------------------------------ */

QueuePtr NewEmptyQueue()
{
  QueuePtr aux = (QueuePtr) malloc(sizeof(struct Queue));
  aux->first = aux->last = NULL;
#ifdef COUNTING
  aux->number = 0;
#endif
  return aux;
}

BOOLEAN IsEmptyQueue(QueuePtr q)
{  return (q->first == NULL);  }

void PutInQueue(QueuePtr q, CellPtr c)
{
  QueueNodePtr aux = (QueueNodePtr) malloc(sizeof(struct QueueNode));
  aux->info = c;
  aux->next = NULL;
  if (q->first)
  { /* queue not empty */
    q->last->next = aux;
    q->last = aux;
  }
  else
  { /* queue is empty */
    q->first = q->last = aux;
  }
#ifdef COUNTING
  q->number++;
#endif
}

void CopyInQueue(QueuePtr q, CellPtr c)
{
  CellPtr aux = (CellPtr) malloc(sizeof(struct CellStruct));
  CopyCoordFrom(aux, c);
  PutInQueue(q,aux);
}

CellPtr GetFromQueue(QueuePtr q)
{
  if (q->first)
  { /* queue not empty */
    CellPtr c = q->first->info;
    QueueNodePtr aux = q->first;
    q->first = q->first->next;
    free(aux);
    if (q->first==NULL) q->last = NULL;
#ifdef COUNTING
    q->number--;
#endif
    return c;
  }
  else
  { /* queue is empty */
    return NULL;
  }
}

void DeleteQueue(QueuePtr q)
{
  QueueNodePtr aux = q->first;
  QueueNodePtr aux1;
  while (aux!=NULL)
  {
    aux1 = aux;
    aux = aux->next;
    free(aux1);
  }
}

void DeleteQueueWithContent(QueuePtr q)
{
  QueueNodePtr aux = q->first;
  QueueNodePtr aux1;
  while (aux!=NULL)
  {
    aux1 = aux;
    aux = aux->next;
    free(aux1->info);
    free(aux1);
  }
}

void PrintQueue(QueuePtr q)
{
  printf("Coda: [");
  QueueNodePtr aux = q->first;
  while (aux!=NULL)
  {  PrintCellPtr(aux->info);
     aux = aux->next;
     if (aux!=NULL) printf(", ");
  }
  printf("]\n");
}

#ifdef COUNTING
int SizeOfQueue(QueuePtr q) { return q->number; }
#endif

/* ------------------------------------------------------------------------ */
