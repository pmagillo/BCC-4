#ifndef UTIL_INCLUDED
#define UTIL_INCLUDED

#include "cells.h"

/* Required: c is face. Test if face is on the boundary: 
   the two incident voxels are one full and one empty */
extern int IsBoundaryFace(CellPtr c);

/* Required: c1, c2 are edges. If they have a common vertex,
   put it in p and return 1. Otherwise return 0. */
extern int GetCommonVertex(CellPtr c1, CellPtr c2, CellPtr p);

/* Return the cell, between c1 and c2, which is minimum in
   lexicographic order of (p,q,r,s) coordinates */
extern CellPtr MinInLexOrder2(CellPtr c1, CellPtr c2);

/* Return the cell, within the given array (with n elements), which is
   minimum in lexicographic order of (p,q,r,s) coordinates */
extern CellPtr MinInLexOrderN(CellPtr c_array, int n);

/* The given array (with n elements) contains faces. Return the one
   which is minimum in lexicographic order of (p,q,r,s) coordinates
   among faces belonging to the boundary */
extern CellPtr MinInLexOrderBoundaryN(CellPtr c_array, int n);

#endif /* UTIL_INCLUDED */