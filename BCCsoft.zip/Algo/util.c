#include <stdio.h>
#include "util.h"
#include "relations.h"
#include "marks.h"

int IsBoundaryFace(CellPtr fac)
{
  struct CellStruct inc_voxel1, inc_voxel2;
  GetFaceVoxels(fac, &inc_voxel1, &inc_voxel2);
/*#ifdef PARLA
    printf("IsBoundaryFace: Adj voxels of ");
    PrintCellPtr(fac);
    printf(" are ");
    PrintCellPtr(&inc_voxel1); 
    printf(" %s and ", (GetVoxelStatus(&inc_voxel1)? "full" : "empty"));
    PrintCellPtr(&inc_voxel2);
    printf(" %s\n", (GetVoxelStatus(&inc_voxel2)? "full" : "empty"));
#endif*/
    return (GetVoxelStatus(&inc_voxel1) !=
            GetVoxelStatus(&inc_voxel2));
}


CellPtr MinInLexOrder2(CellPtr c1, CellPtr c2)
{
  if (P_COORD(c1)>P_COORD(c2)) return c2;
  else if (P_COORD(c2)>P_COORD(c1)) return c1;
  /* here p coordinates are equal */
  if (Q_COORD(c1)>Q_COORD(c2)) return c2;
  else if (Q_COORD(c2)>Q_COORD(c1)) return c1;
  /* here p,q coordinates are equal */
  if (R_COORD(c1)>R_COORD(c2)) return c2;
  else if (R_COORD(c2)>R_COORD(c1)) return c1;
  /* here p,q,r coordinates are equal */
  if (S_COORD(c1)>S_COORD(c2)) return c2;
  else if (S_COORD(c2)>S_COORD(c1)) return c1;
  /* here p,q,r,s coordinates are equal: same cell */
  return c1;
}

CellPtr MinInLexOrderN(CellPtr c_array, int n)
{
  int i;
  CellPtr res = &c_array[0];
  for (i=1; i<n; i++)
    res = MinInLexOrder2(res, &c_array[i]);
  return res;
}

CellPtr MinInLexOrderBoundaryN(CellPtr c_array, int n)
{
  int i;
  CellPtr res = NULL;
  for (i=0; i<n; i++)
  {
    if (IsBoundaryFace(&c_array[i]))
    { if (res==NULL) res = &c_array[i];
      else res = MinInLexOrder2(res, &c_array[i]);
#ifdef PARLA
printf(" min faccia bordo in lex, controllato bnd face"); PrintCellPtr(&c_array[i]);
printf("\n");
#endif
    }
  }
#ifdef PARLA
printf(" min faccia bordo in lex, ritorno"); PrintCellPtr(res);
printf("\n");
#endif  
  return res;
}