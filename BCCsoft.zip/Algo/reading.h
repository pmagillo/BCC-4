#ifndef READING_INCLUDED
#define READING_INCLUDED

#include "cells.h"
#include "queue.h"

/* ------------------------------------------------------------------------ */

/* Range of Cartesian coordinates of centers of input voxels. */
struct RangeStruct
{
  int max_x, min_x;
  int max_y, min_y;
  int max_z, min_z;
  int max_p, min_p;
  int max_q, min_q;
  int max_r, min_r;
  int max_s, min_s;
  CellPtr min_x_voxel;
};

extern void InitRange(struct RangeStruct * range);

/* Update the range according to voxel (p,q,r,s). */
extern void UpdateRange(int p, int q, int r, int s, 
            struct RangeStruct * range);

/* Open file of given name, which must contain cells.
   Count number of cells; if the range is not NULL, then
   init the extreme coordinates within it. */
extern int ReadExtremes(char * name, struct RangeStruct * range);

/* Open file of given name, which must contain cells.
   Read the cells and put them into queue.
   If boolean is 1, mark them as voxels.
   Return number of cells. */
extern int readCellsToQueue(char * name, QueuePtr q, BOOLEAN mark_voxels);

/* Allocate marking array based on the given range, return number of
   allocated bytes. */
extern int allocMarkingArray(struct RangeStruct * range);

#endif /* READING_INCLUDED */
/* ------------------------------------------------------------------------ */
