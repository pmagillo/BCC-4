#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "queue.h"
#include "reading.h"
#include "util.h"

/*
Compute Euler characteristic of a computed boundary surface.
Input: set of full voxels and set of boundary faces (in separate files).
Compute number NV of vertices, NE of edges, NF of faces of the 
boundary surface.
Compute NV-NE+NF, this number can be for example:
=2   the surface is homeomorphic to a sphere (no holes)
=0   the surface is homeomorphic to a torus (one hole)
=-2  the surface is homeomorphic to a double torus (two holes)
=-2K the surface has K+1 holes
The file contains more surfaces, read one by one and compute
Euler characteristic of each one separately.
*/

/* ------------------------------------------------------------------------ */


/*
Macros controlling the compilation:

PARLA:
  If defined, enable printing of what the algorithm is doing.

CONTROLLA:
  If defined, enable consistency checks (they take time).

EXEC_TIME:
  Measure execution time.
*/

#ifdef CONTA
extern int calledPF, calledFV;
#endif

#ifdef EXEC_TIME
#include <time.h>

int previous_time = 0;
#endif


/* ------------------------------------------------------------------------ */

/* Date le facce in coda bnd_faces */
void algorithm(QueuePtr bnd_faces, 
       int *vert_count, int *edge_count, int *face_count)
{
  (*vert_count) = 0;
  (*edge_count) = 0;
  (*face_count) = 0;
  int nf; /* number of adjacent faces */
  int ne; /* number of incident edges, nf=2*ne */
  int i;
  CellPtr this_face;
  struct CellStruct curr_face, prev_face;

  struct CellStruct adj_faces[12];
  struct CellStruct inc_faces_v[6];
  struct CellStruct inc_verts[6];
  
#ifdef EXEC_TIME
  clock_t start_time, end_time;
  int spent_time;
  start_time = clock();
#endif 
  
  while (!IsEmptyQueue(bnd_faces))
  {
    this_face = GetFromQueue(bnd_faces);
    /* count this face */
    (*face_count)++;
#ifdef PARLA
    printf("Boundary face %d from queue: ", (*face_count)); 
    PrintCellPtr(this_face); printf("\n");
#endif
    /* adjacent faces are in two sections: [0..ne-1] and [ne..nf-1]
       and nf=2*ne. 
       adj_face[i] and adj_face[i+ne] are adjacent to this face
       along the same edge, one of the two will be on the boundary */
    nf = GetAdjacentFaces(this_face, adj_faces);
    /* i-th vertex is common to i-th and (i+1)-th edge */
    ne = GetFaceVertices(this_face, inc_verts);
#ifdef PARLA
    printf("ha %d facce e %d lati\n", nf, ne);
    for (i=0; i<ne; i++)
    {
      printf(" faccia "); PrintCellPtr(&adj_faces[i]);
      printf(" e "); PrintCellPtr(&adj_faces[i+ne]);
      printf("\n");
    }
#endif
#ifdef CONTROLLA
  for (i=0; i<ne; i++)
  {
    CHECK( (IsBoundaryFace(&adj_faces[i])||IsBoundaryFace(&adj_faces[i+ne])),
       "none of the faces is on the boundary\n");
    CHECK( (!(IsBoundaryFace(&adj_faces[i])&&IsBoundaryFace(&adj_faces[i+ne]))),
       "both faces are on the boundary\n");
  }
#endif

    /* before entering the cycle, init curr_face */
    if (IsBoundaryFace(&adj_faces[ne-1]))
       CopyCoordFrom(&curr_face, &adj_faces[ne-1]);
    else 
       CopyCoordFrom(&curr_face, &adj_faces[nf-1]);

#ifdef PARLA
     printf("Before entering curr face=");
     PrintCellPtr(curr_face); printf("\n");
#endif

    for (i=0; i<ne; i++)
    {
#ifdef PARLA
      printf("Cycle step n. %d of %d around bnd face ", i, ne);
      PrintCellPtr(this_face); printf("\n");
#endif
      /* based on alignment of relations, curr_face is adjacent
         to this_face along i-th edge. */
      CopyCoordFrom(&prev_face, &curr_face);
      /* set new curr_face as the one on the boundary between the
         two face adjacent along i-th edge */
      if (IsBoundaryFace(&adj_faces[i]))
         CopyCoordFrom(&curr_face, &adj_faces[i]);
      else
         CopyCoordFrom(&curr_face, &adj_faces[i+ne]);

#ifdef PARLA
      printf("  curr_face: "); PrintCellPtr(&curr_face);  printf("\n");
      if (this_face == MinInLexOrder2(this_face,&curr_face))
      {printf("  count edge "); printf("\n");}
#endif

      /* count i-th_edge if this_face is smaller than curr_face */
      if (this_face == MinInLexOrder2(this_face,&curr_face)) 
      {
        (*edge_count)++;

      /* count the vertex if this_face is the smallest one among
         all boundary faces incident to the vertex;
         among them there are this_face, curr_face, prev_face */
        if (this_face == MinInLexOrder2(this_face,&prev_face))
        {
           GetVertexFaces(&inc_verts[(i+ne-1)%ne], inc_faces_v);
           if (AreSameCell(this_face,MinInLexOrderBoundaryN(inc_faces_v,6)))
              (*vert_count)++;
#ifdef PARLA
  if (AreSameCell(this_face,MinInLexOrderBoundaryN(inc_faces_v,6)))
     printf(" vertex counted\n"); else printf(" vertex skipped\n");
#endif
        }
      }
    }
    
#ifdef PARLA
    printf("  now counted %d faces, %d edges, %d vertices\n",
           (*face_count), (*edge_count), (*vert_count));
#endif
  }

#ifdef EXEC_TIME
  end_time = clock();
  spent_time = (end_time-start_time)*1000 / CLOCKS_PER_SEC;
  previous_time += spent_time;
  fprintf(stderr, "EU Time (milliseconds): %d\n", spent_time);
  fprintf(stderr, "EU TotTime (milliseconds): %d\n", previous_time);
#endif
  
#ifdef CONTA
  fprintf(stderr, "GetFaceVoxels chiamata %d volte\n", calledFV);
  fprintf(stderr, "GetVertexFaces chiamata %d volte\n", calledPF);
#endif

}

/* ------------------------------------------------------------------------ */

/* Compute Euler characteristic for each connected component of the
   boundary surface separately.
   Parameters are 1) input file containing full voxels,
   and 2) input file containing boundary faces.
   In the second file each surface is terminated by a string that is not
   a number. The output file is stdout. */
int main(int arg_n, char **arg_v)
{
  int nv, ne, nf, n_holes;
  struct CellStruct aux;
  int found_initial = 0;
  QueuePtr aux_queue;
  QueuePtr face_queue;
  int n_voxels, n_faces;
  int go_on = 1, surface_num = 0;
  FILE * fd_faces;
  char aux_string[255];
  
  /* Range of coordinates of input voxels. */
  struct RangeStruct bbox;

  if (arg_n !=3)
  {
    fprintf(stderr, "Use: %s in_file_voxels in_file_faces]\n", arg_v[0]);
    return 1;
  }
  
  /* Get number of voxels and extreme coordinates */
  InitRange(&bbox);
  n_voxels = ReadExtremes(arg_v[1], &bbox);
  if (n_voxels<=0)
  {
    if (n_voxels==-1) fprintf(stderr, "No input voxel file, abort\n");
    if (n_voxels==0) fprintf(stderr, "No full voxels, nothing to do, abort\n");
    return 1;
  }  
  fprintf(stderr, "EU Input full voxels: %d\n", n_voxels);

  /* Allocate marking arrays */
  allocMarkingArray(&bbox);

  /* Read full voxels and mark them */
  ResetVoxelStatus();
  SetDefaultStatus(0); /* voxels out of limits are empty */
  aux_queue = NewEmptyQueue();
  readCellsToQueue(arg_v[1], aux_queue, 1);
  DeleteQueueWithContent(aux_queue);
  
fd_faces = fopen(arg_v[2], "r");
while (go_on)
{
  /* Get faces and their number */
  face_queue = NewEmptyQueue();
  n_faces = readCellsToQueueBis(fd_faces, face_queue, 0);
  if (n_faces<=0)
  {
    if (n_faces==-1) fprintf(stderr, "No input face file %s, abort\n");
    if (n_faces==0) 
       if (surface_num==0) 
          fprintf(stderr, "No faces, nothing to do, abort\n");
       else 
          fprintf(stderr, "No more surfaces, stop\n");
    return 1;
  }
surface_num++;
fprintf(stderr, "EU surface number %d ", surface_num);
if (surface_num==1)fprintf(stderr, "(external bnd)\n");
else fprintf(stderr, "(internal bnd)\n");
  fprintf(stderr, "EU Input boundary faces: %d\n", n_faces);

  /* Compute Euler characteristic of boundary surface */
#ifdef PARLA
  fprintf(stderr, "Start Euler algorithm\n");
#endif
  algorithm(face_queue, &nv, &ne, &nf); 
  fprintf(stderr, "EU Number of vertices: %d\n", nv);
  fprintf(stderr, "EU Number of edges: %d\n", ne);
  fprintf(stderr, "EU Number of faces: %d\n", nf);
  fprintf(stderr, "EU Euler characteristic: %d\n", (nv-ne+nf));
  n_holes = -(nv-ne+nf)/2+1;
  fprintf(stderr, "EU Number of holes: %d\n", n_holes);

#ifdef PUT_SEPARATOR
/* read the separating keyword */
fscanf(fd_faces, "%s", aux_string);
#else
go_on = 0;
#endif

} /* end of while ogo_on */
  
}

/* ------------------------------------------------------------------------ */
