#ifndef RESTART_H_INCLUDED
#define RESTART_H_INCLUDED

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "queue.h"
#include "reading.h"
#include "util.h"

/* Given voxel must be full. Return 1 if it has at least
   one boundary face */
BOOLEAN IsExposedVoxel(CellPtr vox)
{
  struct CellStruct adj[14];
  int j;
  
  GetAdjacentVoxels(vox, adj);
  for (j=0; j<14; j++)
  {  if (GetVoxelStatus(&adj[j])==0) return 1;  }
  return 0;
}

/* Mark the reference face for given voxel: this is its
   face in direction of S axis */
void MarkReferenceFace(CellPtr voxel)
{
  struct CellStruct fac; /* reference face */
  P_COORD(&fac) = P_COORD(voxel)-1;
  Q_COORD(&fac) = Q_COORD(voxel)-1;
  R_COORD(&fac) = R_COORD(voxel)-1;
  S_COORD(&fac) = S_COORD(voxel)+3;
  SetFaceStatus(&fac,1);
}

/* Check if the reference face for given voxel is
   marked: this is its face in direction of S axis */
BOOLEAN ReferenceFaceIsMarked(CellPtr voxel)
{
  struct CellStruct fac; /* reference face */
  P_COORD(&fac) = P_COORD(voxel)-1;
  Q_COORD(&fac) = Q_COORD(voxel)-1;
  R_COORD(&fac) = R_COORD(voxel)-1;
  S_COORD(&fac) = S_COORD(voxel)+3;
  return (GetFaceStatus(&fac)!=0);
}

/*
Start from full voxel one, perform a BFS search on the (connected) 
set of full voxels, find the exposed ones (= having a face on the
boundary) and put them into list exposed. Return their number.
*/
int FormListOfExposedVoxels(CellPtr one, QueuePtr exposed)
{
  int i, j, num = 0;
  struct CellStruct adj[14];
  QueuePtr aux_queue = NewEmptyQueue();
  /* use status of reference face to mark visited voxels */
  ResetFaceStatus();
  
  CopyInQueue(aux_queue, one);
  MarkReferenceFace(one);
  while (!IsEmptyQueue(aux_queue))
  {
    CellPtr curr = GetFromQueue(aux_queue);
    if (IsExposedVoxel(curr)) 
    {  CopyInQueue(exposed, curr); num++;
    }
    GetAdjacentVoxels(curr, adj);
    for (i=0; i<14; i++)
    {
      if ((GetVoxelStatus(&adj[i])==1) && /* adj is full */
          !ReferenceFaceIsMarked(&adj[i])) /* and not visited */
      {
        CopyInQueue(aux_queue, &adj[i]);
        MarkReferenceFace(&adj[i]);
      } /* end if */
    } /* end for i */
  } /* end while */

  /* now aux_queue is empty, exposed voxels have been counted
     and added to exposed, we clear marks and aux queue */
  ResetFaceStatus();
  DeleteQueueWithContent(aux_queue);
  
  return num;
}

BOOLEAN GetNextStartingFace(QueuePtr exposed, CellPtr bnd_face)
{
  CellPtr vox;
  int j;
  struct CellStruct fac[14];

  while (!IsEmptyQueue(exposed))
  {
    vox = GetFromQueue(exposed);
    GetAdjacentFaces(vox, fac);
    for (j=0; j<14; j++)
    {  if ((GetFaceStatus(&fac[j])==0) && /* face not in surface */
           IsBoundaryFace(&fac[j])) /* but on boundary */
       {
         CopyCoordFrom(bnd_face, &fac[j]);
         /* put back vox, it may have other boundary faces
            belonging to different surfaces */
         PutInQueue(exposed, vox);
         return 1;
       }
    }
    /* vox has no starting face, try next voxel */
  }
  /* we have checked all voxels and found no starting face */
  return 0;
}

#endif /* RESTART_H_INCLUDED */
