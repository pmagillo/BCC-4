#ifndef RESTART_H_INCLUDED
#define RESTART_H_INCLUDED

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "queue.h"
#include "util.h"

/*
Start from full voxel one, perform a BFS search on the (connected) 
set of full voxels, find the exposed ones (= having a face on the
boundary) and put them into list exposed. Return their number.
*/
extern int FormListOfExposedVoxels(CellPtr one, QueuePtr exposed);

/* 
Search the list of exposed voxels to find a boundary face that
has not been yet included into an extracted boundary surface.
*/
extern BOOLEAN GetNextStartingFace(QueuePtr exposed, CellPtr bnd_face);

#endif /* RESTART_H_INCLUDED */
