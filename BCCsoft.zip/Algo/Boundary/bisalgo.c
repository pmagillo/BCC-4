#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "queue.h"
#include "reading.h"
#include "util.h"
#include "restart.h"

/*
Read a file containing full voxels.
Compute the faces of the boundary surface of the object formed
by full voxels.
Write the computed faces.

One iteration is guaranteed to find the complete boundary surface only
if this surface is connected, otherwise it will find just one
of the connected components of faces forming the boundary surface.

Therefore we iterate the process until all boundary surfaces have
been found. The first one is the outer boundary surface.
*/

/* ------------------------------------------------------------------------ */

/*
Macros controlling the compilation:

PARLA:
  If defined, enable printing of what the algorithm is doing.

COUNTING:
  Record and print (maximum) queue size. Print size of allocated 
  marking array.

EXEC_TIME:
  Measure execution time.
  
WITH_EULER:
  Compute Euler characteristic of the surface as well.
  STILL TO BE TESTED!!!!
*/

#ifdef CONTA
extern int calledPF, calledFV;
#endif

#ifdef EXEC_TIME
#include <time.h>

int previous_time = 0;
#endif


/* ------------------------------------------------------------------------ */

#ifdef COUNTING
  int max_queue_size = 0;
  int array_size;
#endif 

#ifdef WITH_EULER
int vert_count, edge_count, face_count;
#endif

int algorithm(CellPtr initial_face, FILE * fd_out)
{
  int counter = 0;
  int nf, i;
  struct CellStruct curr_face;
  struct CellStruct adj_faces[12];
/*  ResetFaceStatus(); now moved out to allow remembering previous surfaces */

#ifdef WITH_EULER
  int ne;
  struct CellStruct prev_face;
  struct CellStruct inc_faces_v[6];
  struct CellStruct inc_verts[6];
  vert_count = edge_count = face_count = 0;
#endif

#ifdef EXEC_TIME
  clock_t start_time, end_time;
  int spent_time;
  start_time = clock();
#endif 

  QueuePtr my_queue = NewEmptyQueue();
  CopyInQueue(my_queue, initial_face);
  SetFaceStatus(initial_face, 1);
  while (!IsEmptyQueue(my_queue))
  {
#ifdef COUNTING
    if (SizeOfQueue(my_queue)>max_queue_size)
              max_queue_size = SizeOfQueue(my_queue);
#endif
    CellPtr this_face = GetFromQueue(my_queue);
#ifdef PARLA
    printf("Boundary face from queue: "); 
    PrintCellPtr(this_face); printf("\n");
#endif
    fprintf(fd_out, "%d %d %d %d\n", 
            P_COORD(this_face), Q_COORD(this_face), 
            R_COORD(this_face), S_COORD(this_face));
    counter++;
    nf = GetAdjacentFaces(this_face, adj_faces);
#ifdef WITH_EULER
    /* before entering the cycle, init curr_face */
    ne = GetFaceVertices(this_face, inc_verts);
    curr_face = adj_faces[ne-1];
    if (!IsBoundaryFace(&curr_face))
         curr_face = adj_faces[nf-1];
#endif
    for (i=0; i<(nf/2); i++)
    {
#ifdef WITH_EULER
      CopyCoordFrom(&prev_face, &curr_face);
#endif
      /* set new curr_face as the one on the boundary between the
         two face adjacent along i-th edge */
      curr_face = adj_faces[i];
      if (!IsBoundaryFace(&curr_face))
         curr_face =  adj_faces[i+(nf/2)];      
#ifdef PARLA
      printf("   adiacent face n. %d of %d; ", i, nf);
      PrintCellPtr(&curr_face);
      if (GetFaceStatus(&curr_face)!=0) printf("   visited, skip.");
/*      else if (!IsBoundaryFace(adj_faces[i]) printf("   not boundary, skip.");*/
      printf("\n");
#endif

      /* consider face only if not yet visited and on boundary*/      
      if ( (GetFaceStatus(&curr_face)==0) )
      {
         CopyInQueue(my_queue, &curr_face);
         SetFaceStatus(&curr_face,1);
      }
#ifdef WITH_EULER
      if (
          (this_face == MinInLexOrder2(this_face,&curr_face)) )
      {
        /* count common edge of this face and current adjacent face */
        edge_count++;
if (this_face == MinInLexOrder2(this_face,&prev_face))
{
BOOLEAN to_be_counted = 1; int j;/*7dic*/
        /* examine vertex */
        if (i<(nf/2)) GetVertexFaces(&inc_verts[(i+ne-1)%ne], inc_faces_v);
        else GetVertexFaces(&inc_verts[(i+ne-1)%ne-(nf/2)], inc_faces_v);
/*        if (AreSameCell(this_face,MinInLexOrderBoundaryN(inc_faces_v,6)))*/
for (j=0;to_be_counted&&(j<6);j++)/*7dic*/
{ to_be_counted = !
  ((MinInLexOrder2(this_face,&inc_faces_v[j])!=this_face)&&
   (IsBoundaryFace(&inc_faces_v[j])));}/*7dic*/
if (to_be_counted)/*7dic*/
           vert_count++;
#ifdef PARLA
 printf("Esamino vertice ");PrintCellPtr(&inc_verts[i]);
 if (AreSameCell(this_face,MinInLexOrderBoundaryN(inc_faces_v,6)))
 printf("  contato\n"); else printf("  scartato\n");
#endif
      }
}
#endif
    }
#ifdef WITH_EULER
    face_count++;
#endif    
    free(this_face);
  }

#ifdef CONTA
  fprintf(stderr, "GetFaceVoxels chiamata %d volte\n", calledFV);
  fprintf(stderr, "GetVertexFaces chiamata %d volte\n", calledPF);
#endif

#ifdef EXEC_TIME
  end_time = clock();
  spent_time = (end_time-start_time)*1000 / CLOCKS_PER_SEC;
#ifdef WITH_EULER
  fprintf(stderr, "(FB+EU) Time (milliseconds): %d\n", spent_time);
#else
  previous_time += spent_time;
  fprintf(stderr, "FB Time (milliseconds): %d\n", spent_time);
  fprintf(stderr, "FB TotTime (milliseconds): %d\n", previous_time);
#endif
#endif

  /* queue is empty, free the pointer */
  free(my_queue);
#ifdef PARLA
  fprintf(fd_out, "end\n");
#endif

#ifdef COUNTING
#ifdef WITH_EULER
    fprintf(stderr, "(FB+EU) Queue (faces): %d\n", max_queue_size);
    fprintf(stderr, "(FB+EU) Queue (bytes): %d\n", max_queue_size * (sizeof(CellPtr)+sizeof(QueueNodePtr)+sizeof(struct CellStruct)));
#else
    fprintf(stderr, "FB Queue (faces): %d\n", max_queue_size);
    fprintf(stderr, "FB Queue (bytes): %d\n", max_queue_size * (sizeof(CellPtr)+sizeof(QueueNodePtr)+sizeof(struct CellStruct)));
/*  sizeof(unsigned char) == 1 byte */
#endif
#endif

#ifdef WITH_EULER
{
  int euler_c = vert_count-edge_count+face_count;
  fprintf(stderr, "(FB+EU) Number of vertices: %d\n", vert_count);
  fprintf(stderr, "(FB+EU) Number of edges: %d\n", edge_count);
  fprintf(stderr, "(FB+EU) Number of faces: %d\n", face_count);
  fprintf(stderr, "(FB+EU) Euler characteristic: %d\n", euler_c);
  fprintf(stderr, "(FB+EU) Number of holes: %d\n",  (-euler_c/2+1));
}
#endif

  return counter;
}

/* ------------------------------------------------------------------------ */

/* Used in function findBoundaryFace below. It is global so we
   can allocate it just once. */
static CellPtr aux_adj[14] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                              NULL,NULL,NULL,NULL,NULL,NULL,NULL};

/* Search for a boundary face of c (which must be a full voxel)
   that is adjacent to an empty voxel. If found, initialize the face
   and return 1. Otherwise return 0. */
int FindBoundaryFace(CellPtr c, CellPtr fac)
{
  int i;
  
  /* allocate aux_adj if not yet done */
  if (aux_adj[0]==NULL)
  {
    for (i=0; i<14;i++)
       aux_adj[i] = (CellPtr) malloc(sizeof(struct CellStruct));
  }
  
  /* consider all adjacent voxels, if one of them is empty */
  GetAdjacentVoxels(c, aux_adj);
  for (i=0; i<14;i++)
  {  if (GetVoxelStatus(&aux_adj[i])==0) 
     { GetCommonFace (c, &aux_adj[i], fac); return 1; }
  }
  return 0;
}

/* ------------------------------------------------------------------------ */

/* Parameters are the input and the output file.
   Output file is optional; if missing, the output file is stdout. */
int main(int arg_n, char **arg_v)
{
  int p, q, r, s;
  struct CellStruct aux;
  int found_initial = 0;
  struct CellStruct aux_face;
  QueuePtr aux_queue, exposed_voxels;
  int counter = 0;
  int num_faces, total_faces = 0, num_surfaces = 0;
  FILE * fd_out = NULL;
  BOOLEAN found = 0;
  /* Range of coordinates of input voxels. */
  struct RangeStruct bbox;
  
  if ((arg_n!=2) && (arg_n!=3))
  {
    fprintf(stderr, "Use: %s in_file_name [out_file_name]\n", arg_v[0]);
    return 1;
  }

  /* set output file */
  fd_out = stdout;
  if (arg_n>2)
  {
    fd_out = fopen(arg_v[2], "w");
  }
  if (fd_out==NULL)
  {
    fprintf(stderr, "No output file, using stdout\n");
    fd_out = stdout;
  }  

  /* Get number of voxels and extreme coordinates */
  /* We also store the voxel with minimum x-coordinate,
     this must be an exposed voxel */ 
  InitRange(&bbox);
  counter = ReadExtremes(arg_v[1], &bbox);
  if (counter<=0)
  {
    if (counter==-1) fprintf(stderr, "No input file, abort\n");
    if (counter==0) fprintf(stderr, "No full voxels, nothing to do, abort\n");
    return 1;
  }  
#ifdef WITH_EULER
  fprintf(stderr, "(FB+EU) Input full voxels: %d\n", counter);
#else
  fprintf(stderr, "FB Input full voxels: %d\n", counter);
#endif

  /* Allocate marking arrays */
#ifdef COUNTING
  array_size = allocMarkingArray(&bbox);
#else
  allocMarkingArray(&bbox);
#endif

  /* Read full voxels and mark them */
  ResetVoxelStatus();
  SetDefaultStatus(0); /* voxels out of limits are empty */
  aux_queue = NewEmptyQueue();
  readCellsToQueue(arg_v[1], aux_queue, 1);

exposed_voxels = NewEmptyQueue();
FormListOfExposedVoxels(bbox.min_x_voxel, exposed_voxels);
ResetFaceStatus();
while (GetNextStartingFace(exposed_voxels, &aux_face))
{
  /* Reconstruct boundary surface containing the 
     initial face aux_face */

  /* Compute boundary faces and write them to output file  */
#ifdef PARLA
  fprintf(stderr, "Surface number %d. Start algorithm from boundary face: ", (num_surfaces+1));
  PrintCellPtr(&aux_face);
  fprintf(stderr, "\n");  
#endif
  num_faces = algorithm(&aux_face, fd_out); 
  total_faces += num_faces;
  num_surfaces++;
#ifdef PUT_SEPARATOR
  fprintf(fd_out, "\nend\n");
#else
  fprintf(fd_out, "\n\n");
#endif

#ifdef WITH_EULER
  fprintf(stderr, "(FB+EU) Output boundary faces: %d\n", num_faces);
#else
  fprintf(stderr, "FB Output boundary faces: %d\n", num_faces);
#endif
}
#ifdef WITH_EULER
  fprintf(stderr, "(FB+EU) Total boundary faces: %d\n", total_faces);
  fprintf(stderr, "(FB+EU) Number of surfaces: %d\n", num_surfaces);
#else
  fprintf(stderr, "FB Total boundary faces: %d\n", total_faces);
  fprintf(stderr, "FB Number of surfaces: %d\n", num_surfaces);
#endif

#ifdef COUNTING
#ifdef WITH_EULER
    fprintf(stderr, "(FB+EU) Marking arrays (bytes): %d\n", array_size);
#else
    fprintf(stderr, "FB Marking arrays (bytes): %d\n", array_size);
/*  sizeof(unsigned char) == 1 byte */
#endif
#endif



/* we have found all boundary surfaces */

  DeleteQueueWithContent(aux_queue);

}

/* ------------------------------------------------------------------------ */
